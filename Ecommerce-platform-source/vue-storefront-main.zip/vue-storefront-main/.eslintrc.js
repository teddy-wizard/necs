module.exports = {
  extends: "@vue-storefront/eslint-config-integrations",
};
