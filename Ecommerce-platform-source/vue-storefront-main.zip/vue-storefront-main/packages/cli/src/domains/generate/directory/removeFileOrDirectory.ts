import { rimraf } from "rimraf";

const removeFileOrDirectory = rimraf;

export default removeFileOrDirectory;
