export { default as wait } from "./wait";
