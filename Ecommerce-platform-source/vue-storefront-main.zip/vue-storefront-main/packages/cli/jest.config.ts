import { baseConfig } from "@vue-storefront/jest-config";

export default {
  ...baseConfig,
};
