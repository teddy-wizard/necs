export { createMultistoreExtension } from "./extension";
export type * from "./types";
