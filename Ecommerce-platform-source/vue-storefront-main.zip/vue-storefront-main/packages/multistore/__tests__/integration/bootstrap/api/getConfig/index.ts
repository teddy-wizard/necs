export const getConfig = async (context) => {
  return {
    config: context.config,
  };
};
