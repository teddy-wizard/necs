export { getConfig } from "./getConfig";
