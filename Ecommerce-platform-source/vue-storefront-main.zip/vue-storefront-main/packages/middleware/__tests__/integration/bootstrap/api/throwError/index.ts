export const throwError = () => {
  throw new Error("some error");
};
