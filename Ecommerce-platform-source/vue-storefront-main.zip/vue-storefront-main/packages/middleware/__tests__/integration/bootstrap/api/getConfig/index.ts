export const getConfig = (context) => {
  return context.config;
};
