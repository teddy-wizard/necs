import { ClientComponentUsingSdk } from "./ClientComponent";

export default function ClientSidePage() {
  return (
    <main>
      <h1>Client Side Page</h1>
      <ClientComponentUsingSdk />
    </main>
  );
}
