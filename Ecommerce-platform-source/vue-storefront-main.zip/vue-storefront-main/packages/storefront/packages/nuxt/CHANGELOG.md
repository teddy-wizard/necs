# Change log

## 3.0.2

- **[FIXED]** Multi-store URL calculation, now working correctly in the browser.

## 3.0.1

- **[CHANGED]** Set `@vue-storefront/sdk` as a dependency instead of a peer dependency

## 3.0.0

- **[BREAKING]** Rewritten from scratch. Now the package exports a Nuxt module which allows to initialize the Vue Storefront SDK.
