import { baseConfig } from "@vue-storefront/jest-config";

export default {
  ...baseConfig,
  // globalSetup: "./__tests__/integration/__config__/jest.setup.global.ts",
  // globalTeardown: "./__tests__/integration/__config__/jest.teardown.global.ts",
  // setupFilesAfterEnv: ["./__tests__/integration/__config__/jest.setup.ts"],
};
