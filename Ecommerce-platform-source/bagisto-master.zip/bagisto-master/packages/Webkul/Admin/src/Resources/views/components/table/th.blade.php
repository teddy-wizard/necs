<th {{ $attributes->merge(['scope' => 'col', 'class' => 'px-6 py-4 whitespace-nowrap font-semibold']) }}>
    {{ $slot }}
</th>
