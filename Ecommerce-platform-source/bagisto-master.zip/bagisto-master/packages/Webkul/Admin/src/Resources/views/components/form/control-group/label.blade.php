<label {{ $attributes->merge(['class' => 'flex gap-1 items-center mb-1.5 text-xs text-gray-800 dark:text-white font-medium']) }}>
    {{ $slot }}
</label>
