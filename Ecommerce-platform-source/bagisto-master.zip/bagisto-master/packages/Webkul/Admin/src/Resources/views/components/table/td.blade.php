<td {{ $attributes->merge(['scope' => 'row', 'class' => 'px-6 py-4 whitespace-nowrap text-gray-600']) }}>
    {{ $slot }}
</td>
