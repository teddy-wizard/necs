<li {{ $attributes->merge(['class' => 'text-sm text-gray-600 dark:text-gray-300 px-5 py-2 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-950 ']) }}>
    {{ $slot }}
</li>
