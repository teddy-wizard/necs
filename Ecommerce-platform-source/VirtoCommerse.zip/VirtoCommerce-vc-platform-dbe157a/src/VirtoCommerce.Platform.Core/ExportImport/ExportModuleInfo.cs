using VirtoCommerce.Platform.Core.Modularity;

namespace VirtoCommerce.Platform.Core.ExportImport
{
    public class ExportModuleInfo : ManifestDependency
    {
        public string PartUri { get; set; }
    }
}
