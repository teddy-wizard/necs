namespace VirtoCommerce.Platform.Core.Jobs
{
    public static class JobPriority
    {
        public const string High = "high";
        public const string Normal = "default";
        public const string Low = "low";
    }
}
