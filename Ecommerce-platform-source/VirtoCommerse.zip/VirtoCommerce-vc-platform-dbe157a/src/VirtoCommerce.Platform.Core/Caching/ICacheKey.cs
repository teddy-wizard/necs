namespace VirtoCommerce.Platform.Core.Caching
{
    public interface ICacheKey
    {
        string GetCacheKey();
    }
}
