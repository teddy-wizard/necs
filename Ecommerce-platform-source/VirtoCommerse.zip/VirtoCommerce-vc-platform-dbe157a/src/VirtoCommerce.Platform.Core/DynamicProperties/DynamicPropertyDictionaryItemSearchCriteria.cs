using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.DynamicProperties
{
    public class DynamicPropertyDictionaryItemSearchCriteria : SearchCriteriaBase
    {
        public string PropertyId { get; set; }
    }
}
