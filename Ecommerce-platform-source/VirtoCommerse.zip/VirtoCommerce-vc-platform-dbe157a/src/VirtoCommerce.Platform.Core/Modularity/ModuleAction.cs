namespace VirtoCommerce.Platform.Core.Modularity
{
    public enum ModuleAction
    {
        Install,
        Uninstall
    }
}
