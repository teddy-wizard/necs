namespace VirtoCommerce.Platform.Core.Modularity
{
    public interface IPlatformRestarter
    {
        void Restart();
    }
}
