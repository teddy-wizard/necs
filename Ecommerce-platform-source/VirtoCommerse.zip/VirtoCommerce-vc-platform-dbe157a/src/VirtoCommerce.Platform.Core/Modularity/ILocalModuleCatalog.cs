namespace VirtoCommerce.Platform.Core.Modularity
{
    public interface ILocalModuleCatalog : IModuleCatalog
    {
    }
}
