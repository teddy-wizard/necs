namespace VirtoCommerce.Platform.Core.Settings
{
    public class FixedSettings
    {
        public ObjectSettingEntry[] Settings { get; set; }
    }
}
