﻿using System;

namespace VirtoCommerce.Platform.Core.Common
{
    [AttributeUsage(AttributeTargets.Parameter, Inherited = false)]
    public class SwaggerOptionalAttribute : Attribute
    {
    }
}
