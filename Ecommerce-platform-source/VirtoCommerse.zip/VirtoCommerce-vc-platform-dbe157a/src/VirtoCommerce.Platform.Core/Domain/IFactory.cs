namespace VirtoCommerce.Platform.Core.Common
{
    /// <summary>
    /// Abstraction for any factories
    /// </summary>
    public interface IFactory
    {
    }
}
