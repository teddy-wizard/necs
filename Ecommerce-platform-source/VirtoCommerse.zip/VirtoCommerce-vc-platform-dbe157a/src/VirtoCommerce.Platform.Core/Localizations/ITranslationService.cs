namespace VirtoCommerce.Platform.Core.Localizations
{
    public interface ITranslationService : ITranslationDataProvider
    {
    }
}
