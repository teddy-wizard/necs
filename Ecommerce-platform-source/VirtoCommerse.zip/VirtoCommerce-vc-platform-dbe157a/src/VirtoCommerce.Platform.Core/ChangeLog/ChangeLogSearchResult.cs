using VirtoCommerce.Platform.Core.Common;

namespace VirtoCommerce.Platform.Core.ChangeLog
{
    public class ChangeLogSearchResult : GenericSearchResult<OperationLog>
    {
    }
}
