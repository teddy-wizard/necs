using VirtoCommerce.Platform.Core.Caching;

namespace VirtoCommerce.Platform.Data.ChangeLog
{
    public class LastChangesCacheRegion : CancellableCacheRegion<LastChangesCacheRegion>
    {
    }
}
