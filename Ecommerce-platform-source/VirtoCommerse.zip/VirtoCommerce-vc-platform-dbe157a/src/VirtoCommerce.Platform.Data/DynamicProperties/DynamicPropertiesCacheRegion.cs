using VirtoCommerce.Platform.Core.Caching;

namespace VirtoCommerce.Platform.Data.DynamicProperties
{
    public class DynamicPropertiesCacheRegion : CancellableCacheRegion<DynamicPropertiesCacheRegion>
    {
    }
}
