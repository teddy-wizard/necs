namespace VirtoCommerce.Platform.Data.Constants
{
    public static class DefaultEntityNames
    {
        public const string UNKNOWN_USERNAME = "unknown";
    }
}
