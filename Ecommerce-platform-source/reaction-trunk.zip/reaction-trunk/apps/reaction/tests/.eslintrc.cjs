module.exports = {
  rules: {
    "require-jsdoc": "off"
  }
};
