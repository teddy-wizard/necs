---
name: Core Work
about: Mailchimp Open Commerce team development work ticket tracker
labels: 'core work'
---

<!--
Core work template is only for tracking work for the internal development cycles of the Reaction team. If you want to report a bug please use the bug report template. 

Are you looking for help with getting started on Mailchimp Open Commerce? Please visit our [Mailchimp Open Commerce documentation](https://mailchimp.com/developer/open-commerce/).
-->


