---
name: ❓ Questions/Help
about: If you have questions, please check our Discord server
labels: 'questions'
---

## ❓ Questions and Help

### Please note that this issue tracker is not a help form and this issue will be closed.

Please contact us instead. We are active on Discord:

- [Discord](https://discord.gg/Bwm63tBcQY)
