import register from "./src/index.js";

export { default as migrations } from "./migrations/index.js";

export default register;
