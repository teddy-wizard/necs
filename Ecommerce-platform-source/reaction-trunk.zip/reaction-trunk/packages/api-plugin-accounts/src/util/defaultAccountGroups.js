// Default group slugs
export const defaultOwnerGroupSlug = "owner";
export const defaultShopManagerGroupSlug = "shop manager";

export default [
  defaultOwnerGroupSlug,
  defaultShopManagerGroupSlug
];
