export const migrationsNamespace = "accounts";
