# @reactioncommerce/api-plugin-address-validation-test

## 2.0.0

### Major Changes

- [#6740](https://github.com/reactioncommerce/reaction/pull/6740) [`fee4dbe95`](https://github.com/reactioncommerce/reaction/commit/fee4dbe952e557db8ca658dc08283ba6c7343af9) Thanks [@sujithvn](https://github.com/sujithvn)! - Node18 upgrade includes assert json

### Patch Changes

- Updated dependencies [[`a50a7b359`](https://github.com/reactioncommerce/reaction/commit/a50a7b359bbb546b7abab0e0bfed4c5d8b5ad759), [`315bb97ab`](https://github.com/reactioncommerce/reaction/commit/315bb97abc3e70dcb1a89da8adca5468302b24be), [`fee4dbe95`](https://github.com/reactioncommerce/reaction/commit/fee4dbe952e557db8ca658dc08283ba6c7343af9)]:
  - @reactioncommerce/api-utils@2.0.0
