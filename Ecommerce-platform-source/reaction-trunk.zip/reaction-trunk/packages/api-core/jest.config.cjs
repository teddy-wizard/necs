module.exports = require("@reactioncommerce/api-utils/lib/configs/jest.config.cjs");
