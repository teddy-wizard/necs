/*
 * <FUNAMBOLCOPYRIGHT>
 * Copyright (C) 2003-2004 Funambol.
 * All Rights Reserved.  No use, copying or distribution of this
 * work may be made except in accordance with a valid license
 * agreement from Funambol.  This notice must be
 * included on all copies, modifications and derivatives of this
 * work.
 *
 * Funambol MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. Funambol SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 * </FUNAMBOLCOPYRIGHT>
 */

#include "common/fscapi.h"
#include "common/Log.h"
#include "spds/common/Config.h"
#include "spds/common/Utils.h"
#include "spds/common/Constants.h"
#include "spds/common/SyncMap.h"
#include "spds/common/SyncItem.h"
#include "spds/common/SyncManager.h"
#include "spds/common/SyncManagerFactory.h"

#define APPLICATION_URI TEXT("Funambol/examples/dummy")

#define MAP_SIZE            10
#define ALL_ITEMS_COUNT      4
#define DELETED_ITEMS_COUNT  1
#define UPDATED_ITEMS_COUNT  2
#define NEW_ITEMS_COUNT      1

static SyncMap*  mappings     [MAP_SIZE           ];
static SyncItem* newItems     [NEW_ITEMS_COUNT    ];
static SyncItem* updatedItems [UPDATED_ITEMS_COUNT];
static SyncItem* deletedItems [DELETED_ITEMS_COUNT];
static SyncItem* allItems     [ALL_ITEMS_COUNT    ];


void error() {
    wsprintf(logmsg, TEXT("Error!\nerror code: %d\nerror message: %s"), lastErrorCode, lastErrorMsg);
    LOG.error(logmsg);
}

void setAllItems(SyncSource& s) {
    allItems[0] = new SyncItem(TEXT("item1"));
    allItems[1] = new SyncItem(TEXT("item2"));
    allItems[2] = new SyncItem(TEXT("item3"));
    allItems[3] = new SyncItem(TEXT("item4"));

    //
    // NOTE: keep into account the terminator
    //
    allItems[0]->setData(TEXT("This is item One")  , 17*sizeof(wchar_t));
    allItems[1]->setData(TEXT("This is item Two")  , 17*sizeof(wchar_t));
    allItems[2]->setData(TEXT("This is item Three"), 19*sizeof(wchar_t));
    allItems[3]->setData(TEXT("This is item Four") , 18*sizeof(wchar_t));

    s.setAllSyncItems(allItems, 4);
}

void setModifiedItems(SyncSource& s) {
    newItems    [0] = new SyncItem(TEXT("item4"));
    deletedItems[0] = new SyncItem(TEXT("item5"));
    updatedItems[0] = new SyncItem(TEXT("item1"));
    updatedItems[1] = new SyncItem(TEXT("item3"));

    newItems[0]->setData(TEXT("This is a new item Four")  , 24*sizeof(wchar_t));
    updatedItems[0]->setData(TEXT("This is the updated item One")  , 29*sizeof(wchar_t));
    updatedItems[1]->setData(TEXT("This is the updated item Three"), 31*sizeof(wchar_t));

    s.setNewSyncItems(newItems,         NEW_ITEMS_COUNT    );
    s.setDeletedSyncItems(deletedItems, DELETED_ITEMS_COUNT);
    s.setUpdatedSyncItems(updatedItems, UPDATED_ITEMS_COUNT);
}

void displayItems(SyncSource& s) {
    unsigned int n, i = 0;
    SyncItem** items;

    n = s.getNewSyncItemsCount();
    items = s.getNewSyncItems();

    LOG.info(TEXT("New items"));
    LOG.info(TEXT("========="));
    for (i=0; i<n; ++i) {
        wsprintf(logmsg, TEXT("key: %s, data: %s"), items[i]->getKey(NULL), items[i]->getData());
        LOG.info(logmsg);
    }

    n = s.getUpdatedSyncItemsCount();
    items = s.getUpdatedSyncItems();

    LOG.info(TEXT("Updated items"));
    LOG.info(TEXT("============="));
    for (i=0; i<n; ++i) {
        wsprintf(logmsg, TEXT("key: %s, data: %s"), items[i]->getKey(NULL), items[i]->getData());
        LOG.info(logmsg);
    }

    n = s.getDeletedSyncItemsCount();
    items = s.getDeletedSyncItems();

    LOG.info(TEXT("Deleted items"));
    LOG.info(TEXT("============="));
    for (i=0; i<n; ++i) {
        wsprintf(logmsg, TEXT("key: %s"), items[i]->getKey(NULL), items[i]->getData());
        LOG.info(logmsg);
    }

}

void displayMappings(SyncSource& s) {
    unsigned int n;
    SyncMap** map;

    n = s.getMapSize();
    map = s.getLUIDGUIDMapping();

    LOG.info(TEXT("Mappings"));
    LOG.info(TEXT("========"));
    for (unsigned int i=0; i<n; ++i) {
        wsprintf(logmsg, TEXT("luid: %s, guid: %s"), map[i]->getLUID(NULL), map[i]->getGUID(NULL));
        LOG.info(logmsg);
    }
}


void setMappings(SyncSource& s) {
    //
    // For the purpose of this example, LUIDs are created prepending
    // the string "C - " to the GUIDs
    //
    unsigned int n;
    wchar_t luid[DIM_KEY];
    SyncItem** items;

    n = s.getNewSyncItemsCount();
    items = s.getNewSyncItems();

    for (unsigned int i = 0; i<n; ++i) {
        wsprintf(luid, TEXT("C - %s"), items[i]->getKey(NULL));
        mappings[i] = new SyncMap(items[i]->getKey(NULL), luid);
    }

    s.setLUIDGUIDMapping(mappings, n);
}

#ifdef _WIN32_WCE
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPWSTR lpCmdLine, int nShowCmd ) {
#else
int main(int argc, char** argv) {
#endif
    unsigned int n, i, ret;

    #ifdef DEBUG
        Log::debugEnabled = TRUE;
    #else
        Log::debugEnabled = FALSE;
    #endif

    SyncManagerFactory factory = SyncManagerFactory();
    SyncManager* syncManager = factory.getSyncManager(APPLICATION_URI);
    SyncSource source = SyncSource(TEXT("dummy"));

    if (syncManager == NULL) {
        error();
        goto finally;
    }

    //
    // Initializations
    //
    for (i=0; i<10; ++i) {
        mappings[i] = NULL;
    }

    LOG.info(TEXT("Preparing sync..."));
    ret = syncManager->prepareSync(source);

    if (ret != 0) {
        switch (ret) {
            case ERR_PROTOCOL_ERROR:
                LOG.error(TEXT("Protocol error"));
                break;

            case ERR_AUTH_NOT_AUTHORIZED:
            case ERR_AUTH_REQUIRED:
                LOG.error(TEXT("Not authorized"));
                break;

            case ERR_AUTH_EXPIRED:
                LOG.error(TEXT("Account expired; required payment"));
                break;

            case ERR_SRV_FAULT:
                LOG.error(TEXT("Server error"));
                break;

            case ERR_NOT_FOUND:
                wsprintf(logmsg, TEXT("Server returned NOT FOUND for SyncSource %s"), source.getName(NULL, 0));
                LOG.error(logmsg);
                break;

            default:
                error();
                break;
        }

        goto finally;
    }

    switch (source.getSyncMode()) {
        case SYNC_SLOW:
            setAllItems(source);
            break;

        case SYNC_TWO_WAY:
            setModifiedItems(source);
            break;

        default:
            break;
    }

    LOG.info(TEXT("Starting sync..."));
    if (syncManager->sync(source) != 0) {
        error();
        goto finally;
    }

    displayItems(source);
    setMappings(source);
    displayMappings(source);

    LOG.info(TEXT("Ending sync..."));
    if (syncManager->endSync(source) != 0) {
        error();
        goto finally;
    }

    lastErrorCode = 0;

finally:

    LOG.info(TEXT("Finalyzing..."));

    //
    // Release initial items
    //
    safeDelete((void**)allItems, ALL_ITEMS_COUNT);
    safeDelete((void**)deletedItems, DELETED_ITEMS_COUNT);
    safeDelete((void**)updatedItems, UPDATED_ITEMS_COUNT);
    safeDelete((void**)newItems, NEW_ITEMS_COUNT);

    //
    // Release server items
    //

    SyncItem **p;
    p = source.getNewSyncItems();
    safeDelete((void**)p, source.getNewSyncItemsCount());
    if (p != NULL) {
        delete [] p;
    }
    p = source.getUpdatedSyncItems();
    safeDelete((void**)p, source.getUpdatedSyncItemsCount());
    if (p != NULL) {
        delete [] p;
    }
    p = source.getDeletedSyncItems();
    safeDelete((void**)p, source.getDeletedSyncItemsCount());
    if (p != NULL) {
        delete [] p;
    }

    //
    // Release mapping
    //
    n = source.getMapSize();
    safeDelete((void**)mappings, n);

    delete syncManager;
    LOG.info(TEXT("Sync ended."));

    return lastErrorCode;
 }

