--
-- Initialization data for the Sync4j engine
--
-- @author Stefano Fornari
-- @version $Id: init_engine.sql,v 1.10 2004/04/15 15:23:23 luigia Exp $
--


--
-- SYNC4J_USER
--
insert into sync4j_user (username, password, email, first_name, last_name, internal_user)
  values('guest', 'guest', 'guest@sync4j.org', 'guest', 'guest', 'N');
  
insert into sync4j_user (username, password, email, first_name, last_name, internal_user)
  values('syncserver', 'syncserver', 'syncserver@sync4j.org', 'SyncServer', 'User', 'N');

insert into sync4j_user (username, password, email, first_name, last_name, internal_user)
  values('syncadmin', 'sa', 'syncadmin@sync4j.org', 'syncadmin', 'syncadmin', 'N');

insert into sync4j_user (username, password, email, first_name, last_name, internal_user)
  values('supersa', 'ass194amb', 'ssyncadmin@sync4j.org', 'ssyncadmin', 'ssyncadmin', 'Y');

insert into sync4j_user (username, password, email, first_name, last_name, internal_user)
  values('sync4j', 'sync4j', 'sync4j@sync4j.org', 'Sync4j', 'User', 'N');
 
--
-- SYNC4J_DEVICE
--
insert into sync4j_device (id, description, type)
  values('Sync4jTest', 'Testing SyncML client agent', 'J2SE');

insert into sync4j_device (id, description, type)
  values('sc2', 'Funambol SyncClient Command Line Edition for Sync4j', 'J2SE');

insert into sync4j_device (id, description, type) 
  values ('sc-j2me-1.0','Sync4j SyncClient MIDlet for Sync4j', 'J2ME');

insert into sync4j_device (id, description, type) 
  values ('sc-oe-1.0','Sync4j SyncClient OutLook for Sync4j', 'CPP');
  
insert into sync4j_device (id, description, type) 
  values ('sc-conduit-1.3','Sync4j SyncClient Conduit for Sync4j', 'J2SE');


--
-- SYNC4J_PRINCIPAL
--
insert into sync4j_principal (id, username, device)
  values('1', 'guest', 'Sync4jTest');
  
insert into sync4j_principal (id, username, device)
  values('2', 'syncserver', 'Sync4jTest');

insert into sync4j_principal (id, username, device)
  values('3', 'sync4j', 'Sync4jTest');
  
insert into sync4j_principal (id, username, device)
  values('4', 'guest', 'sc2');
  
insert into sync4j_principal (id, username, device)
  values('5', 'syncserver', 'sc2');

insert into sync4j_principal (id, username, device)
  values('6', 'sync4j', 'sc2');

insert into sync4j_principal (id, username, device)
  values('7', 'guest','sc-j2me-1.0');

insert into sync4j_principal (id, username, device)
  values('8', 'syncserver','sc-j2me-1.0');

insert into sync4j_principal (id, username, device)
  values('9', 'sync4j','sc-j2me-1.0');

insert into sync4j_principal (id, username, device)
  values('10', 'guest','sc-oe-1.0');

insert into sync4j_principal (id, username, device)
  values('11', 'syncserver','sc-oe-1.0');

insert into sync4j_principal (id, username, device)
  values('12', 'sync4j','sc-oe-1.0');

insert into sync4j_principal (id, username, device)
  values('13', 'guest','sc-conduit-1.3');

insert into sync4j_principal (id, username, device)
  values('14', 'syncserver','sc-conduit-1.3');

insert into sync4j_principal (id, username, device)
  values('15', 'sync4j','sc-conduit-1.3');


--
-- SYNC4J_ID
--
insert into sync4j_id values('device',0);

insert into sync4j_id values('principal',15);

insert into sync4j_id values('module',0);

insert into sync4j_id values('sourcetype',1);

insert into sync4j_id values('connector',0);

--
-- SYNC4J_ROLE
--
insert into sync4j_role values('sync_user','Sync User');

insert into sync4j_role values('sync_administrator','Sync Administrator');

insert into sync4j_role values('special_sync_admin','Special Internal Sync Administrator');

--
-- SYNC4J_USER_ROLE
--
insert into sync4j_user_role values('guest','sync_user');

insert into sync4j_user_role values('syncserver','sync_user');

insert into sync4j_user_role values('syncserver','sync_administrator');

insert into sync4j_user_role values('syncadmin','sync_administrator');

insert into sync4j_user_role values('supersa','special_sync_admin');

insert into sync4j_user_role values('sync4j','sync_user');

insert into sync4j_user_role values('sync4j','sync_administrator');
