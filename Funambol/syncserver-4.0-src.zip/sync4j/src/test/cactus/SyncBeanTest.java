/*
 
 $Id: SyncBeanTest.java,v 1.7 2002/10/07 21:47:11 stefano_fornari Exp $
 
 Copyright (c) 2001-2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows
    these conditions in the documentation and/or other materials
    provided with the distribution.
 
 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the
 end-user documentation provided with the redistribution and/or in the
 software itself an acknowledgement equivalent to the following:
 
     "This product includes software developed by the
      sync4j project."
 
 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 
 */

package cactus;

import java.rmi.*;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.rmi.*;
import javax.ejb.*;
import javax.naming.*;

import junit.framework.*;
import org.apache.cactus.*;

import sync4j.framework.core.*;
import sync4j.tests.*;
import sync4j.server.syncbean.*;
import sync4j.framework.server.*;

import sync4j.framework.tools.Base64;

/**
 * Tests of the <code>SyncBean</code>, the Sync4j EJB.  This is to show
 * how the client can obtain SyncBean's remote interface and invoke its
 * business methods, <code>processMessage()</code>, with different
 * message types.
 *
 * @author	<a href="mailto:sso@users.sourceforge.net">Simon So</a>
 * @see		sync4j.server.syncbean.SyncRemote
 * 
 */
public class SyncBeanTest extends ServletTestCase {
    /**
     *	A reference to the SyncEJB remote interface.  It is an entry point
     *	of all the business logic.
     */
    private SyncRemote sync;
    
    /**
     *	A request message, in XML format.
     */
    private byte[] requestXmlMsg;
    
    /**
     *	A request message, in WB XML format.
     */
    private byte[] requestWbXmlMsg;
    
    /**
     *	A message of unknown type to test the error handling.
     */
    private byte[] requestUnknownMsg;
    
    /**
     *	A reference to the response received from the SyncEJB business
     *	method.
     */
    private SyncResponse response;
    
    /**
     * Defines the testcase name for JUnit.
     *
     * @param theName the testcase's name.
     */
    public SyncBeanTest(String theName) {
        super(theName);
    }
    
    /**
     *	An aggregrate of all the tests.
     *
     *	@return a test suite (<code>TestSuite</code>) that includes all methods
     *			starting with "test"
     */
    public static Test suite() {
        return new TestSuite(SyncBeanTest.class);
    }
    
    /**
     *	Sets up every test by obtaining the SyncEJB by its remote interface,
     *	<code>SyncHomeRemote</code> and <code>SyncRemote</code>, and
     *	initializes different types of message for testing.
     *
     */
    protected void setUp() {
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            long        timestamp = System.currentTimeMillis();
            
            Context ic = new InitialContext();
            Object ref = ic.lookup("java:comp/env/ejb/SyncEJB");
            System.out.println(ref);
            SyncHomeRemote home = (SyncHomeRemote)
            PortableRemoteObject.narrow(ref, SyncHomeRemote.class);
            
            String sessionId = new String(localhost.getAddress()) + '-' + timestamp;
            sync = (SyncRemote)home.create(
                new String(Base64.encode(sessionId.getBytes()))
            );
        }
        catch (NamingException ne) {
            ne.printStackTrace();
        }
        catch (RemoteException re) {
            re.printStackTrace();
        }
        catch (CreateException ce) {
            ce.printStackTrace();
        }
        catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Verifies that we can process XML message.
     */
    public void testProcessXMLMessage() throws Exception {
        String xml = "<SyncML> <SyncHdr> <VerDTD>1.0</VerDTD>"+
        "<VerProto>SyncML/1.0</VerProto>"+
        "<SessionID>1234</SessionID> <MsgID>CBA54322</MsgID> <Target>"+
        "<LocURI>http://www.target.bar/</LocURI><LocName>"+
        "Target.bar is a nice place</LocName></Target> "+
        "<Source><LocURI>http://www.source.bar/</LocURI>"+
        "<LocName>Source.bar is a nicer place</LocName></Source></SyncHdr> "+
        "<SyncBody> <Atomic> <CmdID>atomiccmd123</CmdID> "+
        "<Add><CmdID>addcmd123</CmdID> <NoResp/> "+
        "<Cred><Meta><Type>syncml:auth-md5</Type>"+
        "<Format>b64</Format></Meta><Data>creddata</Data></Cred> "+
        "<Meta>AddMeta</Meta> <Item>itemA</Item> <Item>itemB</Item> </Add>"+
        "</Atomic> </SyncBody> </SyncML>";
        requestXmlMsg = xml.getBytes();
        response = sync.processMessage(requestXmlMsg, Constants.MIMETYPE_SYNCML_XML);
        assertTrue(response != null);
    }
    
    /**
     * Verifies that we can process WBXML message.
     */
    public void testProcessWBXMLMessage() throws Exception {
        requestWbXmlMsg = "6D 01".getBytes();
        
        response = sync.processMessage(requestWbXmlMsg,
        Constants.MIMETYPE_SYNCML_WBXML);
        assertTrue(response != null);
    }
    
    /**
     * Verifies that we can handle Unknown (neither XML nor WBXML) message
     * without any problems.
     */
    public void testProcessUnknownMessage() throws Exception {
        requestUnknownMsg = "Whatever".getBytes();
        
        response = null;
        //response = sync.processMessage(requestUnknownMsg, "UnknownType");
        // should have failed at this point.
        assertTrue(response == null);
    }
}
