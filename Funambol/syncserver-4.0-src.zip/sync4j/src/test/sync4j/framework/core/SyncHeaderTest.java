/*

 $Id: SyncHeaderTest.java,v 1.7 2002/10/07 21:47:11 stefano_fornari Exp $

 Copyright (c) 2001, 2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.  
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:

     "This product includes software developed by the
      sync4j project."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */


package sync4j.framework.core;

import sync4j.framework.core.*;
import junit.framework.*;
import java.io.*;

/**
  *
  *  unit test code for the SyncHeader class
  *
  *  @see sync4j.framework.core.SyncHeader
  *  @author Sean C. Sullivan
  *
  */
public class SyncHeaderTest 
	extends junit.framework.TestCase
{

	public SyncHeaderTest(final String strName)
	{
		super(strName);
	}

        public void testConstructor_exceptions()
        {
		final DTDVersion verdtd = new DTDVersion("3.859");
		final ProtocolVersion verproto = new ProtocolVersion("SyncML/1.0");
		final SyncSessionIdentifier ssi = new SyncSessionIdentifier("xyz123");
		final String strMsgID = "msgID123abc";
		final Target t = new Target("a", "b");
		final Source s = new Source("c", "d");
		final String responseURI = "foobar/xyzpdqbgl";
		final boolean bNoResponse = false;
		final BasicAuthentication auth = new BasicAuthentication("user", "pass");
		final Credential cred = new Credential(auth);
		final Meta m = new Meta(new StringMetaContent("My meta text"));

		SyncHeader header = null;


		boolean bCaughtException = false;

		try
		{
			// null DTDVersion
			header = new SyncHeader(
				null,
				verproto,
				ssi,
				strMsgID,
				t,
				s,
				responseURI,
				bNoResponse,
				cred,
				m);
		}
		catch (NullPointerException ex)
		{
			bCaughtException = true;
		}


		assertTrue( bCaughtException == true );

		bCaughtException = false;
		try
		{
			// null ProtocolVersion 
			header = new SyncHeader(
				verdtd,
				null,
				ssi,
				strMsgID,
				t,
				s,
				responseURI,
				bNoResponse,
				cred,
				m);
		}
		catch (NullPointerException ex)
		{
			bCaughtException = true;
		}


		assertTrue( bCaughtException == true );

		bCaughtException = false;
		try
		{
			// null SyncSessionIdentifier
			header = new SyncHeader(
				verdtd,
				verproto,
				null,
				strMsgID,
				t,
				s,
				responseURI,
				bNoResponse,
				cred,
				m);
		}
		catch (NullPointerException ex)
		{
			bCaughtException = true;
		}


		assertTrue( bCaughtException == true );


		bCaughtException = false;
		try
		{
			// null MsgID
			header = new SyncHeader(
				verdtd,
				verproto,
				ssi,
				null,
				t,
				s,
				responseURI,
				bNoResponse,
				cred,
				m);
		}
		catch (NullPointerException ex)
		{
			bCaughtException = true;
		}


		assertTrue( bCaughtException == true );

        }

	public void testConstructor()
	{

		final DTDVersion verdtd = new DTDVersion("3.859");
		final ProtocolVersion verproto = new ProtocolVersion("SyncML/1.0");
		final SyncSessionIdentifier ssi = new SyncSessionIdentifier("xyz123");
		final String strMsgID = "msgID123abc";
		final Target t = new Target("a", "b");
		final Source s = new Source("c", "d");
		final String responseURI = "foobar/xyzpdqbgl";
		final boolean bNoResponse = false;
		final BasicAuthentication auth = new BasicAuthentication("user", "pass");
		final Credential cred = new Credential(auth);
		final Meta m = new Meta(new StringMetaContent("My meta text"));

		SyncHeader header = null;


		header = new SyncHeader(
				verdtd,
				verproto,
				ssi,
				strMsgID,
				t,
				s,
				responseURI,
				bNoResponse,
				cred,
				m);

		assertTrue( header != null );

		assertTrue( header.getDTDVersion().getValue().equals(verdtd.getValue()) );

		assertTrue( header.getProtocolVersion().getValue().equals(verproto.getValue()) );

		assertTrue( header.getSyncSessionIdentifier().getValue().equals(ssi.getValue()) );

		assertTrue( header.getMeta().getValue().equals(m.getValue()) );
	}

}
