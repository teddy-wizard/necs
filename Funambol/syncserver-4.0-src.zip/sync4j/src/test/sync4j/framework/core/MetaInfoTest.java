/*

 $Id: MetaInfoTest.java,v 1.13 2002/08/09 15:16:33 stefano_fornari Exp $

 Copyright (c) 2001, 2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.  
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:

     "This product includes software developed by the
      sync4j project."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */


package sync4j.framework.core;

import sync4j.framework.core.*;
import junit.framework.*;
import java.io.*;

/**
  *
  *  unit test code for the MetaInfo class
  *
  *  @see sync4j.framework.core.MetaInfo
  *  @author Sean C. Sullivan
  *
  */
public class MetaInfoTest 
	extends junit.framework.TestCase
{

	public MetaInfoTest(String strName)
	{
		super(strName);
	}

	public void testConstructor()
	{
		MetaInfo mi = null;
		final String strEncodingFormat = "int";
		final String strType = "text/plain";
		final String strMark = Mark.FINAL;
		final long lDataSizeInBytes = 15;
		final String last = "lastfoo";
		final String next = "nextfoo";
		final SyncAnchor anchor = new SyncAnchor(last, next);
		final String strDataVersion = "3.14";
		final NextNonce nonce = new NextNonce("abc", true);
		final long lMaxMsgSize = 1024;
		final ExperimentalMetaInfo[] aEMI = new ExperimentalMetaInfo[3];
		aEMI[0] = new ExperimentalMetaInfo("emi0");
		aEMI[1] = new ExperimentalMetaInfo("emi1");
		aEMI[2] = new ExperimentalMetaInfo("emi2");
		final boolean bMemoryIsShared = true;
		final long lFreeMemoryInBytes = 2048;
		final long lFreeItemIdentifierCount = 20;
		final MemoryInfo memInfo = new MemoryInfo(
				bMemoryIsShared,
				lFreeMemoryInBytes,
				lFreeItemIdentifierCount);
		
		try
		{
			mi = new MetaInfo(
				strEncodingFormat,
				strType,
				strMark,
				lDataSizeInBytes,
				anchor,
				strDataVersion,
				nonce,
				lMaxMsgSize,
				aEMI,
				memInfo);
		}
		catch (Throwable t)
		{
			assertTrue( false );
		}

		assertTrue( mi != null );

		final String strXML1 = mi.toXML();
		final String strXML2 = mi.toXML();

		assertTrue( strXML1 != null );
		assertTrue( strXML1.equals(strXML2) );

		assertTrue( mi.getEncodingFormat().equals(strEncodingFormat) );
		assertTrue( mi.getType().equals(strType) );

		MetaInfo mi2 = null;

		try
		{
			mi2 = new MetaInfo(mi.toXML());
		}
		catch (XMLSyntaxException ex)
		{
			System.out.println(ex);
			assertTrue(false);
		}
		catch (InvalidMarkupException ex)
		{
			System.out.println(ex);
			assertTrue(false);
		}

		// todo : assertTrue(mi2.toXML().equals(mi.toXML()));
	}

        public void test_emptyMetaInfoDocument()
	{
		final String strInput = TestUtil.getXMLString("valid/MetaInfo-empty.xml");

		MetaInfo mi = null;

		boolean bCaughtException = false;

		try
		{
			mi = new MetaInfo(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}

		assertTrue( bCaughtException == false );
		assertTrue( mi != null );
		assertTrue( mi.getDataSizeInBytes() == -1 );
		assertTrue( mi.getMaxMessageSize() == -1 );
		assertTrue( mi.getEncodingFormat() == null );
		assertTrue( mi.getType() == null );
		assertTrue( mi.getMark() == null );
		assertTrue( mi.getSyncAnchor() == null );
		assertTrue( mi.getDataVersion() == null );
		assertTrue( mi.getNextNonce() == null );
		assertTrue( mi.getExperimentalMetaInfo() != null );
		assertTrue( mi.getExperimentalMetaInfo().length == 0 );
		assertTrue( mi.getMemoryInfo() == null );
		assertTrue( mi.toXML() != null );

	}

       public void testBadMetaInfo_nullXMLString()
	{
		
		MetaInfo mi = null;

		boolean bCaughtNPE = false;

		try
		{
			String strNull = null;
			mi = new MetaInfo(strNull);
			assertTrue(false);
		}
		catch (NullPointerException ex)
		{
			bCaughtNPE = true;
		}
		catch (XMLSyntaxException ex)
		{
		}
		catch (InvalidMarkupException ex)
		{
		}

		assertTrue(bCaughtNPE);
	
	}

       public void testValidMetaInfoDocument_basic()
	{
		final String strInput = TestUtil.getXMLString("valid/MetaInfo-basic.xml");

		MetaInfo mi = null;

		boolean bCaughtException = false;

		try
		{
			mi = new MetaInfo(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}

		assertTrue( bCaughtException == false );
		assertTrue( mi != null );
		assertTrue( mi.getDataSizeInBytes() == 12 );
		assertTrue( mi.getMaxMessageSize() == 1023 );
		assertTrue( mi.getEncodingFormat().equals("chr") );
		assertTrue( mi.getType().equals("text/calendar") );
		assertTrue( mi.getMark().equals("final") );

		final SyncAnchor anchor = mi.getSyncAnchor();

		assertTrue( anchor != null );
		assertTrue( anchor.getLast().equals("10234") );
		assertTrue( anchor.getNext().equals("10235") );

		assertTrue( mi.getDataVersion().equals("502194") );
		assertTrue( mi.getNextNonce() != null );
		assertTrue( mi.getNextNonce().getValue() != null );

		// todo : add assert for the nextnonce value String

		assertTrue( mi.getExperimentalMetaInfo() != null );
		assertTrue( mi.getExperimentalMetaInfo().length == 2 );
		assertTrue( mi.getExperimentalMetaInfo()[0].getValue().equals("emidata0") );
		assertTrue( mi.getExperimentalMetaInfo()[1].getValue().equals("emidata1") );

		assertTrue( mi.getMemoryInfo() != null );
		assertTrue( mi.getMemoryInfo().isMemoryShared() == true );
		assertTrue( mi.getMemoryInfo().getFreeMemoryInBytes() == 4069 );
		assertTrue( mi.getMemoryInfo().getFreeItemIdentifierCount() == 93 );

		assertTrue( mi.toXML() != null );

	}


}
