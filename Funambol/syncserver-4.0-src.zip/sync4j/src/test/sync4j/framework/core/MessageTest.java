/*

 $Id: MessageTest.java,v 1.8 2002/10/07 21:47:11 stefano_fornari Exp $

 Copyright (c) 2001, 2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.  
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:

     "This product includes software developed by the
      sync4j project."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */


package sync4j.framework.core;

import sync4j.framework.core.*;
import junit.framework.*;

/**
  *
  *  unit test code for the Message class
  *
  *  @see sync4j.framework.core.Message
  *  @author Sean C. Sullivan
  *
  */
public class MessageTest 
	extends junit.framework.TestCase
{

	public MessageTest(String strName)
	{
		super(strName);
	}

	public void testAlertCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/AlertCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof AlertCommand );
	}

	public void testAddCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/AddCommand-basic.xml");
		Message msg = null;

		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		final AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof AtomicCommand );
		
		final AtomicCommand atomiccmd = (AtomicCommand) cmds[0];
		final AbstractCommand[] innerCommands = atomiccmd.getCommands();

		assertTrue( innerCommands.length == 1);
		assertTrue( innerCommands[0] instanceof AddCommand);

	}


	public void testBadSyncML_EmptySyncHeader()
	{
		final String strInput = TestUtil.getXMLString("invalid/EmptySyncHeader.xml");
		Message msg = null;

		boolean bCaughtInvalidMarkupException = false;

		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			bCaughtInvalidMarkupException = true;
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}

		assertTrue( bCaughtInvalidMarkupException );
	}

	public void testBadSyncML_MissingSyncHeader()
	{
		final String strInput = TestUtil.getXMLString("invalid/MissingSyncHeader.xml");
		Message msg = null;

		boolean bCaughtInvalidMarkupException = false;

		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			bCaughtInvalidMarkupException = true;
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}

		assertTrue( bCaughtInvalidMarkupException );
	}

	public void testBadSyncML_MissingSyncBody()
	{
		final String strInput = TestUtil.getXMLString("invalid/MissingSyncBody.xml");
		Message msg = null;

		boolean bCaughtInvalidMarkupException = false;

		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			bCaughtInvalidMarkupException = true;
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}

		assertTrue( bCaughtInvalidMarkupException );
	}

        public void testBadSyncML_OpenSyncMLElement()
        {
		final String strInput = TestUtil.getXMLString("invalid/OpenSyncMLElement.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

        public void testBadSyncML_OverlappingElements()
        {
		final String strInput = TestUtil.getXMLString("invalid/OverlappingElements.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

        public void testBadSyncML_InvalidCommand()
        {
		final String strInput = TestUtil.getXMLString("invalid/InvalidCommand.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			assertTrue( false );
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

        public void testBadSyncML_EmptySyncMLDocument()
        {
		final String strInput = TestUtil.getXMLString("invalid/EmptySyncMLDocument.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

        public void testBadSyncML_InvalidOuterElement()
        {
		final String strInput = TestUtil.getXMLString("invalid/InvalidOuterElement.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			assertTrue( false );
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

        public void testBadSyncML_EmptyDocument()
        {
		final String strInput = TestUtil.getXMLString("invalid/EmptyDocument.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

        public void testBadSyncML_PlainText()
        {
		final String strInput = TestUtil.getXMLString("invalid/PlainText.xml");
		Message msg = null;
		boolean bCaughtException = false;
		try
		{
			msg = new Message(strInput);
		}
		catch (XMLSyntaxException e)
		{
			bCaughtException = true;
		}
		catch (InvalidMarkupException e)
		{
			bCaughtException = true;
		}
		assertTrue( bCaughtException );
	}

	public void testAtomicCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/AtomicCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof AtomicCommand );
	}


	public void testCopyCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/CopyCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof CopyCommand );
	}

	public void testDeleteCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/DeleteCommand-basic.xml");

		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof AtomicCommand );

		final AtomicCommand atomiccmd = (AtomicCommand) cmds[0];
		final AbstractCommand[] innercmds = atomiccmd.getCommands();

		assertTrue( innercmds.length == 1 );
		assertTrue( innercmds[0] instanceof DeleteCommand );

	}

	public void testExecCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/ExecCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof ExecCommand );
	}

	public void testGetCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/GetCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof GetCommand );
	}

	public void testMapCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/MapCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof MapCommand );
	}

	public void testPutCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/PutCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof PutCommand );
	}

	public void testReplaceCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/ReplaceCommand-basic.xml");

		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof AtomicCommand );

		final AtomicCommand atomiccmd = (AtomicCommand) cmds[0];
		final AbstractCommand[] innercmds = atomiccmd.getCommands();

		assertTrue( innercmds.length == 1 );
		assertTrue( innercmds[0] instanceof ReplaceCommand );

	}

	public void testResultsCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/ResultsCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds != null );
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof ResultsCommand );
	}

	public void testSearchCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/SearchCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof SearchCommand );
	}

	public void testSequenceCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/SequenceCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof SequenceCommand );
	}

	public void testSyncCommand()
	{
		final String strInput = TestUtil.getXMLString("valid/SyncCommand-basic.xml");
		Message msg = null;
		try
		{
			msg = new Message(strInput);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}
		AbstractCommand[] cmds = msg.getBody().getCommands();
		assertTrue( cmds.length == 1 );
		assertTrue( cmds[0] instanceof SyncCommand );
	}

	public void test_toXML()
	{
		Item[] addItems = new Item[1];
		addItems[0] = new Item(
			new Target("targettext", "targetname"),
			new Source("sourcetext", "sourcename"),
			new Meta(new StringMetaContent("metatext")),
			new Data("datatext"));

		AddCommand addcmd;
		addcmd = new AddCommand(
			new CommandIdentifier("cmd99"),
			false,
			new Credential(new BasicAuthentication("user", "pass")),
			new Meta(new StringMetaContent("addcommandmeta")),
			addItems);

		Item[] alertItems = new Item[1];
		alertItems[0] = new Item(
			new Target("targettext", "targetname"),
			new Source("sourcetext", "sourcename"),
			new Meta(new StringMetaContent("metatext")),
			new Data("datatext"));
		AlertCommand alertcmd;
		alertcmd = new AlertCommand(
			new CommandIdentifier("cmd100"),
			false,
			null,
			AlertCode.DISPLAY,
			alertItems);

		AbstractCommand[] atomicrequestcommands;
		atomicrequestcommands = new AbstractCommand[2];
		atomicrequestcommands[0] = addcmd;
		atomicrequestcommands[1] = addcmd;
		AtomicCommand atomiccmd;
		atomiccmd = new AtomicCommand(
			new CommandIdentifier("atomiccmd999"),
			false,
			null,
			atomicrequestcommands);

		Item[] copyItems = new Item[1];
		copyItems[0] = new Item(
			new Target("abctargettext", "targetname"),
			new Source("abcsourcetext", "sourcename"),
			new Meta(new StringMetaContent("abcmetatext")),
			new Data("abcdatatext"));
		CopyCommand copycmd;
		copycmd = new CopyCommand(
			new CommandIdentifier("cmd101"),
			false,
			null,
			new Meta(new StringMetaContent("metatext")),
			copyItems);

		Item[] deleteItems = new Item[1];
		deleteItems[0] = new Item(
			new Target("deftargettext", "targetname"),
			new Source("defsourcetext", "sourcename"),
			new Meta(new StringMetaContent("defmetatext")),
			new Data("defdatatext"));
		DeleteCommand deletecmd;
		deletecmd = new DeleteCommand(
			new CommandIdentifier("deletecmd999"),
			false,
			true,
			true,
			null /* credential */,
			null /* meta */,
			deleteItems);

		Item execItem = new Item(
			new Target("exectargettext", "targetname"),
			new Source("execsourcetext", "sourcename"),
			new Meta(new StringMetaContent("execmetatext")),
			new Data("execdatatext"));
		ExecCommand execcmd;
		execcmd = new ExecCommand(
			new CommandIdentifier("execcmd123"),
			true,
			null /* credential */,
			execItem);

		Item[] getItems = new Item[1];
		getItems[0] = new Item(
			new Target("deftargettext", "targetname"),
			new Source("defsourcetext", "sourcename"),
			new Meta(new StringMetaContent("defmetatext")),
			new Data("defdatatext"));
		GetCommand getcmd;
		getcmd = new GetCommand(
			new CommandIdentifier("getcmd123"),
			false,
			"English",
			null /* credential */,
			null /* meta */,
			getItems);

		MapItem[] mapItems = new MapItem[2];
		mapItems[0] = new MapItem(
			new Target("targettext0", "targetname"),
			new Source("sourcetext0", "sourcename"));
		mapItems[1] = new MapItem(
			new Target("targettext1", "targetname"),
			new Source("sourcetext1", "sourcename"));

		MapCommand mapcmd;
		mapcmd = new MapCommand(
			new CommandIdentifier("mapcmd123"),
			new Target("deftargettext", "targetname"),
			new Source("defsourcetext", "sourcename"),
			null /* credential */,
			null /* meta */,
			mapItems);

		Item[] putItems = new Item[1];
		putItems[0] = new Item(
			new Target("deftargettext", "targetname"),
			new Source("defsourcetext", "sourcename"),
			new Meta(new StringMetaContent("defmetatext")),
			new Data("defdatatext"));
		PutCommand putcmd;
		putcmd = new PutCommand(
			new CommandIdentifier("putcmd123"),
			false,
			"French",
			null /* credential */,
			null /* meta */,
			putItems);

		Item[] replaceItems = new Item[2];
		replaceItems[0] = new Item(
			new Target("deftargettext", "targetname"),
			new Source("defsourcetext", "sourcename"),
			new Meta(new StringMetaContent("defmetatext")),
			new Data("defdatatext"));
		replaceItems[1] = new Item(
			new Target("xeftargettext", "targetname"),
			new Source("xefsourcetext", "sourcename"),
			new Meta(new StringMetaContent("xefmetatext")),
			new Data("xefdatatext"));
		ReplaceCommand replacecmd;
		replacecmd = new ReplaceCommand(
			new CommandIdentifier("replacecmd123"),
			false,
			null /* credential */,
			null /* meta */,
			replaceItems);

		Item[] resultsItems = new Item[1];
		resultsItems[0] = new Item(
			new Target("deftargettext", "targetname"),
			new Source("defsourcetext", "sourcename"),
			new Meta(new StringMetaContent("defmetatext")),
			new Data("defdatatext"));
		ResultsCommand resultscmd;
		resultscmd = new ResultsCommand(
			new CommandIdentifier("resultscmd123"),
			"resultsmsgref123",
			"resultscmdref123",
			null /* meta */,
			null /* targetref */,
			null /* sourceref */,
			resultsItems);

		Source[] searchSources = new Source[1];
		searchSources[0] = 
			new Source("xyzsourcetext", "sourcename");
		SearchCommand searchcmd;
		searchcmd = new SearchCommand(
			new CommandIdentifier("searchcmd123"),
			false,
			true /* true == no results */,
			null /* credential */,
			null /* target */,
			searchSources,
			"German",
			new Meta(new StringMetaContent("searchmetatext")),
			new Data("searchdatatext"));

		AbstractCommand[] sequenceRequestCmds;
		sequenceRequestCmds = new AbstractCommand[1];
		sequenceRequestCmds[0] = deletecmd;
		SequenceCommand sequencecmd;
		sequencecmd = new SequenceCommand(
			new CommandIdentifier("sequencecmd123"),
			false,
			new Meta(new StringMetaContent("sequencemetatext")),
			sequenceRequestCmds);

		StatusCommand statuscmd;
		statuscmd = new StatusCommand(
			new CommandIdentifier("statuscmd123"),
			"refmsgid123",
			"cmdref123",
			"Copy" /* Cmd */,
			new TargetRef[0],
			new SourceRef[0],
			null /* credential */,
			null /* chal */,
			new Data("401"),
			new Item[0] /* items */);

		AbstractCommand[] syncRequestCmds;
		syncRequestCmds = new AbstractCommand[2];
		syncRequestCmds[0] = deletecmd;
		syncRequestCmds[1] = copycmd;

		final SyncCommand synccmd;
		synccmd = new SyncCommand(
			new CommandIdentifier("synccmd123"),
			false,
			null /* credential */,
			null /* target */,
			null /* source */,
			null /* meta */,
			syncRequestCmds);

		Message msg = null;
		final AbstractCommand[] cmds = new AbstractCommand[12];
		cmds[0] = alertcmd;
		cmds[1] = atomiccmd;
		cmds[2] = copycmd;
		cmds[3] = execcmd;
		cmds[4] = getcmd;
		cmds[5] = mapcmd;
		cmds[6] = putcmd;
		cmds[7] = resultscmd;
		cmds[8] = searchcmd;
		cmds[9] = sequencecmd;
		cmds[10] = statuscmd;
		cmds[11] = synccmd;

		SyncHeader header;
		header = new SyncHeader(
			new DTDVersion("1.0"),
			new ProtocolVersion("1.0"),
			new SyncSessionIdentifier("ssid123"),
			"msgid123",
			new Target("turi", "targetname"),
			new Source("suri", "sourcename"),
			"theresponseuri",
			true,
			null,
			null
			);

		SyncBody body;
		final boolean bFinal = true;
		body = new SyncBody(cmds, bFinal);

		msg = new Message(header, body);

		final String strXML = msg.toXML();

		Message msg2 = null;
		try
		{
			msg2 = new Message(strXML);
		}
		catch (InvalidMarkupException ex)
		{
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			assertTrue( false );
		}

		assertTrue( msg.getBody().getCommands().length == msg2.getBody().getCommands().length );

		assertTrue( msg.getBody().isFinal() == msg2.getBody().isFinal() );

		for (int i = 0; i < cmds.length; i++)
		{
			final AbstractCommand cmd;
			cmd = (msg2.getBody().getCommands())[i];
			final Class c = (cmds[i]).getClass();
			assertTrue( cmd.getClass().equals(c) );
		}

		final String strXML2 = msg2.toXML();

		assertTrue( strXML.equals(strXML2) );
	}

        public void testConstructor_NullSyncBody()
	{
		boolean bCaughtNullPointerException = false;

		final SyncHeader header = new SyncHeader(
			new DTDVersion("1.0"),
			new ProtocolVersion("1.0"),
			new SyncSessionIdentifier("ssid123"),
			"msgid123",
			new Target("turi", "targetname"),
			new Source("suri", "sourcename"),
			"theresponseuri",
			true,
			null,
			null
			);

		final SyncBody nullBody = null;


		Message msg = null;

		try
		{
			msg = new Message(header, nullBody);
		}
		catch (Throwable t)
		{
			if ( t instanceof NullPointerException ) 
			{
				bCaughtNullPointerException = true;
			}
			else
			{
				System.out.println(t);
				assertTrue( false );
			}
		}
		assertTrue(bCaughtNullPointerException);
		assertTrue(msg == null);

	}


        public void testConstructor_NullSyncHeader()
	{
		boolean bCaughtNullPointerException = false;

		final SyncHeader nullHeader = null;

		Item[] alertItems = new Item[1];
		alertItems[0] = new Item(
			new Target("targettext", "targetname"),
			new Source("sourcetext", "sourcename"),
			new Meta(new StringMetaContent("metatext")),
			new Data("datatext"));
		AlertCommand alertcmd;
		alertcmd = new AlertCommand(
			new CommandIdentifier("cmd100"),
			false,
			null,
			AlertCode.DISPLAY,
			alertItems);

		final AbstractCommand[] cmds = new AbstractCommand[1];
		cmds[0] = alertcmd;

		final SyncBody body = new SyncBody(cmds, false);

		Message msg = null;

		try
		{
			msg = new Message(nullHeader, body);
		}
		catch (Throwable t)
		{
			if ( t instanceof NullPointerException ) 
			{
				bCaughtNullPointerException = true;
			}
			else
			{
				System.out.println(t);
				assertTrue( false );
			}
		}
		assertTrue(bCaughtNullPointerException);
		assertTrue(msg == null);

	}

}
