/*

$Id: DeviceInfoTest.java,v 1.14 2002/08/09 15:16:33 stefano_fornari Exp $

Copyright (c) 2001-2002 sync4j project
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
notice, this list of conditions, and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions, and the disclaimer that follows
these conditions in the documentation and/or other materials
provided with the distribution.

3. The name "sync4j" must not be used to endorse or promote products
derived from this software without prior written permission.

4. Products derived from this software may not be called "sync4j", nor
may "sync4j" appear in their name, without prior written permission.

In addition, we request (but do not require) that you include in the
end-user documentation provided with the redistribution and/or in the
software itself an acknowledgement equivalent to the following:

 "This product includes software developed by the
  sync4j project."

THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.

*/


package sync4j.framework.core;

import sync4j.framework.core.*;
import junit.framework.*;

import java.io.*;

/**
*
*  unit test code for the {@link sync4j.framework.core.DeviceInfo} class
*
*  @see sync4j.framework.core.DeviceInfo
*  @author Sean C. Sullivan
*
*/
public class DeviceInfoTest
	extends junit.framework.TestCase
{

private static final DTDVersion goodDTDVersion = new DTDVersion("foodtd/1.0");
private static final String strGoodManufacturer = "Foo Corp";
private static final String strGoodModelName = "modelABC";
private static final String strGoodOEM = "OEM_OKCorp";
private static final String strGoodFirmwareVersion = "1.89";
private static final String strGoodSoftwareVersion = "2.92";
private static final String strGoodHardwareVersion = "3.189";
private static final String strGoodDeviceIdentifier = "devID12345";
private static final String strGoodDeviceType = DeviceType.HANDHELD;

// these next 3 arrays are initialized in the static initializer
private static final DataStore[] goodDataStores = new DataStore[1];
private static final ContentTypeCapability[] goodCapabilities = new ContentTypeCapability[1];
private static final Extension[] goodExtensions = new Extension[2];


/**
 *
 *    static initializer
 *
 */
static
{

	final ContentTypeInfo cti = new ContentTypeInfo(
			"text/plain",
			"2.65");
	final ContentTypeInfo[] aCTI = new ContentTypeInfo[1];
	aCTI[0] = cti;
	final DataStoreMemoryInfo dsmi = new DataStoreMemoryInfo(
			true,
			4096,
			50);
	final SyncType[] aSyncTypes = new SyncType[2];
	aSyncTypes[0] = SyncType.TWO_WAY;
	aSyncTypes[1] = SyncType.SLOW;
	final SyncCapabilities syncCap = new SyncCapabilities(
			aSyncTypes);
	goodDataStores[0] = new DataStore(
			new SourceRef("sourceRefXYZ"),
			"DataStore display name",
			500 /* max guid size */,
			cti,
			aCTI,
			cti,
			aCTI,
			dsmi,
			syncCap);

	final String[] aPropValues = new String[2];
	aPropValues[0] = "propValue0";
	aPropValues[1] = "propValue1";
	final String[] aParamValues = new String[2];
	aParamValues[0] = "paramValue0";
	aParamValues[1] = "paramValue1";
	final ContentTypeParameter[] ctparams =
			new ContentTypeParameter[1];
	ctparams[0] = new ContentTypeParameter(
			"ContentTypeParamName",
			aParamValues,
			"content type param display name");
	final ContentTypeProperty[] aContentTypeProperty =
			new ContentTypeProperty[1];
	aContentTypeProperty[0] = new ContentTypeProperty(
			"PropName",
			aPropValues,
			"Property display name",
			ctparams);
	final ContentTypeCapabilityItem[] aContentTypeCapabilityItems =
			new ContentTypeCapabilityItem[1];
	aContentTypeCapabilityItems[0] = new ContentTypeCapabilityItem(
			"application/foo",
			aContentTypeProperty);
	goodCapabilities[0] = new ContentTypeCapability(
			aContentTypeCapabilityItems);

	final String[] aExtValues =
			{
				"extValue1",
				"extValue2",
				"extValue3"
			};

	DeviceInfoTest.goodExtensions[0] = new Extension(
			"ExtensionNameYYY",
			aExtValues);
	DeviceInfoTest.goodExtensions[1] = new Extension(
			"ExtensionNameZZZ",
			aExtValues);
}

public DeviceInfoTest(String strName)
{
	super(strName);
}

public void testConstructor_xml()
{
	final String strXML = TestUtil.getXMLString("valid/DeviceInfo-basic.xml");

	DeviceInfo di = null;

	try
	{
		di = new DeviceInfo(strXML);
	}
	catch (InvalidMarkupException ex)
	{
		ex.printStackTrace();
		assertTrue(false);
	}
	catch (XMLSyntaxException ex)
	{
		ex.printStackTrace();
		assertTrue(false);
	}

	assertTrue(di != null);

	assertTrue(di.toXML() != null);

	// todo : add more assertions

	DeviceInfo di2 = null;

	try
	{
		di2 = new DeviceInfo(di.toXML());
	}
	catch (InvalidMarkupException ex)
	{
		ex.printStackTrace();
		assertTrue(false);
	}
	catch (XMLSyntaxException ex)
	{
		ex.printStackTrace();
		assertTrue(false);
	}

	assertTrue(di2 != null);

	assertTrue(di.toXML().equals(di2.toXML()));

	// todo : add more assertions
}

public void testConstructor_primary()
{
	DeviceInfo di = null;

	final DTDVersion verdtd = new DTDVersion("1.0");
	final String strManufacturer = "Advanced Computer Devices";
	final String strModelName = "Model2001";
	final String strOEM = "OEM123";
	final String strFirmwareVersion = "1.23";
	final String strSoftwareVersion = "2.34";
	final String strHardwareVersion = "3.45";
	final String strGoodDeviceIdentifier = "devID123";
	final String strDeviceType = DeviceType.SMARTPHONE;
	final ContentTypeInfo cti = new ContentTypeInfo(
			"text/plain",
			"2.65");
	final ContentTypeInfo[] aCTI = new ContentTypeInfo[1];
	aCTI[0] = cti;
	final DataStoreMemoryInfo dsmi = new DataStoreMemoryInfo(
			true,
			4096,
			50);
	final SyncType[] aSyncTypes = new SyncType[2];
	aSyncTypes[0] = SyncType.TWO_WAY;
	aSyncTypes[1] = SyncType.SLOW;
	final SyncCapabilities syncCap = new SyncCapabilities(
			aSyncTypes);
	final DataStore[] aDatastores = new DataStore[1];
	aDatastores[0] = new DataStore(
			new SourceRef("sourceRefXYZ"),
			"DataStore display name",
			500 /* max guid size */,
			cti,
			aCTI,
			cti,
			aCTI,
			dsmi,
			syncCap);
	final String[] aPropValues = new String[2];
	aPropValues[0] = "propValue0";
	aPropValues[1] = "propValue1";
	final String[] aParamValues = new String[2];
	aParamValues[0] = "paramValue0";
	aParamValues[1] = "paramValue1";
	final ContentTypeParameter[] ctparams =
			new ContentTypeParameter[1];
	ctparams[0] = new ContentTypeParameter(
			"ContentTypeParamName",
			aParamValues,
			"content type param display name");
	final ContentTypeProperty[] aContentTypeProperty =
			new ContentTypeProperty[1];
	aContentTypeProperty[0] = new ContentTypeProperty(
			"PropName",
			aPropValues,
			"Property display name",
			ctparams);
	final ContentTypeCapabilityItem[] aContentTypeCapabilityItems =
			new ContentTypeCapabilityItem[1];
	aContentTypeCapabilityItems[0] = new ContentTypeCapabilityItem(
			"application/foo",
			aContentTypeProperty);
	final ContentTypeCapability[] aContentTypeCapability = new ContentTypeCapability[1];
	aContentTypeCapability[0] = new ContentTypeCapability(
			aContentTypeCapabilityItems);
	final String[] aExtValues =
			{
				"extValue1",
				"extValue2",
				"extValue3"
			};
	final Extension[] aExtensions = new Extension[1];
	aExtensions[0] = new Extension(
			"ExtensionName",
			aExtValues);

	try
	{
		di = new DeviceInfo(
				verdtd,
				strManufacturer,
				strModelName,
				strOEM,
				strFirmwareVersion,
				strSoftwareVersion,
				strHardwareVersion,
				strGoodDeviceIdentifier,
				strDeviceType,
				aDatastores,
				aContentTypeCapability,
				aExtensions);
	}
	catch (Throwable t)
	{
		assertTrue(false);
	}

	assertTrue(di != null);

	final String strXML1 = di.toXML();
	final String strXML2 = di.toXML();

	assertTrue(strXML1 != null);
	assertTrue(strXML1.equals(strXML2));

	assertTrue(di.getDeviceType().equals(strDeviceType));

	// todo : add more assertions
	assertTrue(di.getDTDVersion().getValue().equals(verdtd.toString()));
	assertTrue(di.getManufacturer().equals(strManufacturer));
	assertTrue(di.getOEM().equals(strOEM));
	assertTrue(di.getFirmwareVersion().equals(strFirmwareVersion));
	assertTrue(di.getSoftwareVersion().equals(strSoftwareVersion));
	assertTrue(di.getHardwareVersion().equals(strHardwareVersion));
	assertTrue(di.getDeviceIdentifier().equals(strGoodDeviceIdentifier));
}

public void testConstructor_invalidDTDVersion()
{
	boolean bCaughtException;

	DeviceInfo di = null;

	// first, let's attempt a null DTDVersion parameter
	bCaughtException = false;

	try
	{
		di = new DeviceInfo(
				null /* DTDVersion parameter */,
				strGoodManufacturer,
				strGoodModelName,
				strGoodOEM,
				strGoodFirmwareVersion,
				strGoodSoftwareVersion,
				strGoodHardwareVersion,
				strGoodDeviceIdentifier,
				strGoodDeviceType,
				goodDataStores,
				goodCapabilities,
				goodExtensions);
	}
	catch (java.lang.NullPointerException ex)
	{
		bCaughtException = true;
	}

	assertTrue(bCaughtException);
}

public void testConstructor_invalidDeviceIdentifier()
{
	DeviceInfo di = null;

	// next, let's attempt a null strGoodDeviceIdentifier parameter
	boolean bCaughtException = false;

	try
	{
		di = new DeviceInfo(
				goodDTDVersion,
				strGoodManufacturer,
				strGoodModelName,
				strGoodOEM,
				strGoodFirmwareVersion,
				strGoodSoftwareVersion,
				strGoodHardwareVersion,
				null  /* device identifier parameter */,
				strGoodDeviceType,
				goodDataStores,
				goodCapabilities,
				goodExtensions);
	}
	catch (java.lang.NullPointerException ex)
	{
		bCaughtException = true;
	}

	assertTrue(bCaughtException);
}

public void testConstructor_zeroLengthDeviceIdentifier()
{
	DeviceInfo di = null;

	// next, let's attempt a zero length strGoodDeviceIdentifier parameter
	boolean bCaughtException = false;

	try
	{
		di = new DeviceInfo(
				goodDTDVersion,
				strGoodManufacturer,
				strGoodModelName,
				strGoodOEM,
				strGoodFirmwareVersion,
				strGoodSoftwareVersion,
				strGoodHardwareVersion,
				"" /* device identifier parameter */,
				strGoodDeviceType,
				goodDataStores,
				goodCapabilities,
				goodExtensions);
	}
	catch (java.lang.IllegalArgumentException ex)
	{
		bCaughtException = true;
	}

	assertTrue(bCaughtException);
}

public void testConstructor_invalidDataStore() 
{
	DeviceInfo di = null;

	// next, let's attempt a null datastore parameter
	boolean bCaughtException = false;

	try
	{
		di = new DeviceInfo(
				goodDTDVersion,
				strGoodManufacturer,
				strGoodModelName,
				strGoodOEM,
				strGoodFirmwareVersion,
				strGoodSoftwareVersion,
				strGoodHardwareVersion,
				strGoodDeviceIdentifier,
				strGoodDeviceType,
				null /* datastores */,
				goodCapabilities,
				goodExtensions);
	}
	catch (java.lang.NullPointerException ex)
	{
		bCaughtException = true;
	}

	assertTrue(bCaughtException);
}

public void testConstructor_invalidCapability()
{
	DeviceInfo di = null;

	// next, let's attempt a null capability parameter
	boolean bCaughtException = false;

	try
	{
		di = new DeviceInfo(
				goodDTDVersion,
				strGoodManufacturer,
				strGoodModelName,
				strGoodOEM,
				strGoodFirmwareVersion,
				strGoodSoftwareVersion,
				strGoodHardwareVersion,
				strGoodDeviceIdentifier,
				strGoodDeviceType,
				goodDataStores,
				null /* Capabilities */,
				goodExtensions);
	}
	catch (java.lang.NullPointerException ex)
	{
		bCaughtException = true;
	}

	assertTrue(bCaughtException);		
}

public void testConstructor_invalidExtension()
{
	DeviceInfo di = null;

	// next, let's attempt a null extension parameter
	boolean bCaughtException = false;

	try
	{
		di = new DeviceInfo(
				goodDTDVersion,
				strGoodManufacturer,
				strGoodModelName,
				strGoodOEM,
				strGoodFirmwareVersion,
				strGoodSoftwareVersion,
				strGoodHardwareVersion,
				strGoodDeviceIdentifier,
				strGoodDeviceType,
				goodDataStores,
				goodCapabilities,
				null /* Extensions */);
	}
	catch (java.lang.NullPointerException ex)
	{
		bCaughtException = true;
	}

	assertTrue(bCaughtException);		
}

public void testBadDeviceInfo_EmptyDeviceInfoDocument()
{
	final String strInput = TestUtil.getXMLString("invalid/EmptyDeviceInfoDocument.xml");
	DeviceInfo di = null;
	boolean bCaughtException = false;
	try
	{
		di = new DeviceInfo(strInput);
	}
	catch (XMLSyntaxException e)
	{
		bCaughtException = true;
	}
	catch (InvalidMarkupException e)
	{
		bCaughtException = true;
	}
	assertTrue(bCaughtException);
}

}
