/*
 
 $Id: MgmtTreeTest.java,v 1.2 2002/08/09 15:16:33 stefano_fornari Exp $
 
 Copyright (c) 2001-2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows
    these conditions in the documentation and/or other materials
    provided with the distribution.
 
 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the
 end-user documentation provided with the redistribution and/or in the
 software itself an acknowledgement equivalent to the following:
 
     "This product includes software developed by the
      sync4j project."
 
 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.
 
 */

package sync4j.framework.dm;

import junit.framework.*;

import sync4j.framework.core.*;
import sync4j.framework.dm.*;

import java.util.*;
import java.io.*;

/**
 * Tests the <code>MgmtTree</code>.
 *
 * @author	<a href="mailto:sso@users.sourceforge.net">Simon So</a>
 * @see		sync4j.dm.MgmtTree
 * 
 */
public class MgmtTreeTest extends TestCase
{
    private MgmtTree mt;
    
    /**
     * Defines the testcase name for JUnit.
     *
     * @param theName the testcase's name.
     */
    public MgmtTreeTest(String theName)
    {
	super(theName);
	mt = null;
    }
    
    /**
     * @return a test suite (<code>TestSuite</code>) that includes all methods
     *         starting with "test"
     */
    public static Test suite()
    {
	return new TestSuite(MgmtTreeTest.class);
    }
    
    /**
     *
     */
    protected void setUp() throws Exception
    {
	String t = TestUtil.getXMLString("valid/DMObject.xml");
	mt = new MgmtTree(t);	
    }
            
    /**
     *	Tests the DM XML doc.  The input string and the output
     *	XML doc will not be the same.  It is because in the input, some
     *	of the NodeName will be empty.  Internally according to the spec
     *	the engine has to resolve the name.
     */
    public void testDMObject() throws Exception
    {
	String xml = mt.toXML();
	assertTrue(xml != null);
    }
    
    /**
     * Tests resolving the name of a node.
     */
    public void testResolveName() throws Exception
    {
	String name = "./SyncML/DMAcc/x/Key";
	UriNode n = (UriNode)mt.resolveName(name);
	assertTrue(name.equals(
		    n.getPath() + n.PATH_SEPARATOR + n.getNodeName()));
    }
    
    /**
     * Tests adding a node to an interior object.  The more appropriate way
     * is to create that node instead of pulling one out from the tree.
     */
    public void testAddToInteriorObject() throws Exception
    {
	String name = "./SyncML/DMAcc/x";
	UriNode n = (UriNode)mt.resolveName(name);
	
	// add yy, a sibling to x
	n.setNodeName("yy");
	mt.add(n);
	name = "./SyncML/DMAcc/yy";
	n = (UriNode)mt.resolveName(name);
	assertTrue(name.equals(
		n.getPath() + n.PATH_SEPARATOR + n.getNodeName()));
	
	// sibling should still be here
	name = "./SyncML/DMAcc/x";
	n = (UriNode)mt.resolveName(name);
	assertTrue(n != null);
    }

    /**
    * Tests adding a node to a leaf.  The more appropriate way
    * is to create that node instead of pulling one out from the tree.
    */   
    public void testAddToLeaf() throws Exception
    {
	String t = TestUtil.getXMLString("valid/DMObject.xml");
	MgmtTree mt = new MgmtTree(t);
	String name = "./SyncML/DMAcc/x/Nonce";
	Node n = (Node)mt.resolveName(name);
	
	assertTrue(mt.add(new Node("Whatever",
				    name,
				    n.getRTProperties(),
				    n.getDFProperties(),
				    null,
				    "Some value")));
	
	name = "./SyncML/DMAcc/x/Nonce/Whatever";
	n = (Node)mt.resolveName(name);
	assertTrue(name.equals(
	n.getPath() + n.PATH_SEPARATOR + n.getNodeName()));
    }

    /**
    * Tests removing an interior object.  
    */       
    public void testRemoveInteriorObject() throws Exception
    {
	String name = "./SyncML/DMAcc/x";
	UriNode n = (UriNode)mt.resolveName(name);
	
	assertTrue(mt.remove(n));
	
	// its children should not be found
	name = "./SyncML/DMAcc/x/Addr";
	n = (UriNode)mt.resolveName(name);
	assertTrue(n == null);
	
	// its parents should still be here
	name = "./SyncML/DMAcc/";
	n = (UriNode)mt.resolveName(name);
	assertTrue(n != null);
    }
    
    /**
     * Tests removing a leaf.
     */
    public void testRemoveLeaf() throws Exception
    {
	String name = "./SyncML/DMAcc/x/Nonce";
	Node n = (Node)mt.resolveName(name);
	
	assertTrue(mt.remove(n));

	// should no longer be found.
	n = (Node)mt.resolveName(name);
	assertTrue(n == null);
	
	// but its parent should still be here.
	name = "./SyncML/DMAcc/x/";
	n = (Node)mt.resolveName(name);
	assertTrue(n != null);
    }

}
