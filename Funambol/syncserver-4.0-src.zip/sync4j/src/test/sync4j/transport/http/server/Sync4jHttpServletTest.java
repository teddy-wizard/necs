/*

 $Id: Sync4jHttpServletTest.java,v 1.14 2002/08/09 15:16:33 stefano_fornari Exp $

 Copyright (c) 2001, 2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.  
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:

     "This product includes software developed by the
      sync4j project."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */


package sync4j.transport.http.server;

import sync4j.framework.core.*;
import junit.framework.*;
import java.io.*;
import java.net.*;

/**
  *
  *  unit test code for the Sync4jHttpServlet class
  *
  *  @see sync4j.transport.http.server.Sync4jHttpServlet
  *  @author Sean C. Sullivan
  *
  */
public class Sync4jHttpServletTest 
	extends junit.framework.TestCase
{

	public Sync4jHttpServletTest(final String strName)
	{
		super(strName);
	}

        public void test_simpleHttpClient_XML() throws Exception
        {
		String strXML;
		strXML = TestUtil.getXMLString("valid/AddCommand-basic.xml");

		byte[] yaData = strXML.getBytes();

		final URL u = new URL("http://localhost:8000/sync4j/sync");

		HttpURLConnection conn;
		conn = (HttpURLConnection) u.openConnection();
		conn.setDoOutput(true);
		conn.setDoInput(true);
		conn.setAllowUserInteraction(false);
		conn.setRequestMethod("POST");
		conn.setUseCaches(false);
		conn.setRequestProperty("User-Agent", this.getClass().toString());
		conn.setRequestProperty("Content-Type", Constants.MIMETYPE_SYNCML_XML);
		conn.setRequestProperty("Content-Length", "" + yaData.length);

		OutputStream out = conn.getOutputStream();

		out.write(yaData);
		out.flush();

		InputStream in = conn.getInputStream();

		int iResponseCode = conn.getResponseCode();

		assertEquals(iResponseCode, HttpURLConnection.HTTP_OK);

		String strResponseContentType = conn.getContentType();

		assertTrue( strResponseContentType != null );

		assertTrue( strResponseContentType.equals(Constants.MIMETYPE_SYNCML_XML) );
			
		int iResponseContentLength = conn.getContentLength();

		assertTrue(iResponseContentLength > 0);

		byte[] yaResponse = new byte[iResponseContentLength];

		int n = 0;
		int iBytesRead = 0;
		do
		{
			n = in.read(yaResponse, 
				iBytesRead, 
				yaResponse.length - iBytesRead);
			if (n > 0)
			{
				iBytesRead += n;
			}
		}
		while (n != -1);

		assertEquals( iBytesRead, iResponseContentLength );


		String strResponse = new String(yaResponse);
		Message msg = null;
		try
		{
			msg = new Message(strResponse);
		}
		catch (InvalidMarkupException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		catch (XMLSyntaxException ex)
		{
			System.out.println(ex);
			assertTrue( false );
		}
		assertTrue( msg != null );

		in.close();
		out.close();

		conn.disconnect();

		in = null;
		out = null;
		conn = null;

        }

	// todo : send a SyncML message in WBXML format
}
