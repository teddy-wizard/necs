/*

 $Id: Base64Test.java,v 1.6 2002/08/09 15:16:33 stefano_fornari Exp $

 Copyright (c) 2001, 2002 sync4j project
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The name "sync4j" must not be used to endorse or promote products
    derived from this software without prior written permission.  
 
 4. Products derived from this software may not be called "sync4j", nor
    may "sync4j" appear in their name, without prior written permission.
 
 In addition, we request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:

     "This product includes software developed by the
      sync4j project."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE SYNC4J AUTHORS OR THE PROJECT
 CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 SUCH DAMAGE.

 */


package org.bouncycastle.util.encoders;

/* Use readily made Bounty Castle Crypto API instead... 
import sync4j.framework.core.Util;
*/
import org.bouncycastle.util.encoders.Base64;

import junit.framework.*;

import java.util.Random;
import java.util.Arrays;

/**
  *
  * Unit test code for Base64 encoding and decoding. 
  * Test code inherited from Bounty Castle Crypto API.
  *
  *  @author Sean C. Sullivan
  *
  */
public class Base64Test extends junit.framework.TestCase
{
    private Random _r = null;
    
	public Base64Test(String strName)
	{
		super(strName);
	}

    protected void setUp() {
        _r = new Random();
    }
    
    /*
    Copyright (c) 2000 The Legion Of The Bouncy Castle
    (http://www.bouncycastle.org)
    
    Permission is hereby granted, free of charge, to any person obtaining
    a copy of this software and associated documentation files (the "Software"),
    to deal in the Software without restriction, including without limitation
    the rights to use, copy, modify, merge, publish, distribute, sublicense,
    and/or sell copies of the Software, and to permit persons to whom the Software
    is furnished to do so, subject to the following conditions:
    
    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software. 
    
    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN 
    THE SOFTWARE. 
    */    
	public void testPowerOf2()
	{
        byte[] _orig1024 = new byte[1024];
        _r.nextBytes(_orig1024);
        
        byte[] _orig2048 = new byte[2048];
        _r.nextBytes(_orig2048);
        
        byte[] _orig4096 = new byte[4096];
        _r.nextBytes(_orig4096);
        
        byte[] _orig8192 = new byte[8192];
        _r.nextBytes(_orig8192);
        
        byte[] _enc1024 = Base64.encode(_orig1024);
        byte[] _enc2048 = Base64.encode(_orig2048);
        byte[] _enc4096 = Base64.encode(_orig4096);
        byte[] _enc8192 = Base64.encode(_orig8192);
        
        byte[] _dec1024 = Base64.decode(_enc1024);
        byte[] _dec2048 = Base64.decode(_enc2048);
        byte[] _dec4096 = Base64.decode(_enc4096);
        byte[] _dec8192 = Base64.decode(_enc8192);
        
        assertTrue(Arrays.equals(_orig1024, _dec1024));
        
        assertTrue(Arrays.equals(_orig2048, _dec2048));
        
        assertTrue(Arrays.equals(_orig4096, _dec4096));
        
        assertTrue(Arrays.equals(_orig8192, _dec8192));
    }

    public void testPowerOf2Plus1() {
        byte[] _orig1025 = new byte[1025];
        _r.nextBytes(_orig1025);
        
        byte[] _orig2049 = new byte[2049];
        _r.nextBytes(_orig2049);
        
        byte[] _orig4097 = new byte[4097];
        _r.nextBytes(_orig4097);
        
        byte[] _orig8193 = new byte[8193];
        _r.nextBytes(_orig8193);
        
        byte[] _enc1025 = Base64.encode(_orig1025);
        byte[] _enc2049 = Base64.encode(_orig2049);
        byte[] _enc4097 = Base64.encode(_orig4097);
        byte[] _enc8193 = Base64.encode(_orig8193);
        
        byte[] _dec1025 = Base64.decode(_enc1025);
        byte[] _dec2049 = Base64.decode(_enc2049);
        byte[] _dec4097 = Base64.decode(_enc4097);
        byte[] _dec8193 = Base64.decode(_enc8193);
        
        assertTrue(Arrays.equals(_orig1025, _dec1025));
        
        assertTrue(Arrays.equals(_orig2049, _dec2049));
        
        assertTrue(Arrays.equals(_orig4097, _dec4097));
        
        assertTrue(Arrays.equals(_orig8193, _dec8193));
	}
}
