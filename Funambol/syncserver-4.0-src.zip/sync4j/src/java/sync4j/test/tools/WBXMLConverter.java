/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.test.tools;

import sync4j.framework.tools.IOTools;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.tools.WBXMLTools;

/**
 * <p>Title: </p>
 * <p>Description: A utility to convert XML files to WBXML and vice versa.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 *
 * @author Tyson Norris
 *
 * @version $Id: WBXMLConverter.java,v 1.4 2004/04/13 09:35:13 luigia Exp $
 */

public class WBXMLConverter {
    private static boolean xmlToWbxml = false;
    private static boolean wbxmlToXml = false;
    
    public WBXMLConverter() {
    }

    public static void main(String args[])
    throws Exception {
        try {
            checkArguments(args);
        } catch (IllegalArgumentException e) {
            System.out.println("usage:" );
            System.out.println(WBXMLConverter.class.getName() + " [-xml|-wbxml] <xml dir>");
            return;
        }
        
        convert((args.length == 1) ? args[0] : args[1]);
    }
    
    private static void checkArguments(String[] args) 
    throws IllegalArgumentException {
        switch (args.length) {
            case 0:
                throw new IllegalArgumentException();
            
            case 1:
                wbxmlToXml = false;
                xmlToWbxml = true ;
                break;
            
            case 2:
                wbxmlToXml = "-wbxml".equalsIgnoreCase(args[0]);
                xmlToWbxml = "-xml".equalsIgnoreCase(args[0]);
                
                if (!wbxmlToXml && !xmlToWbxml) {
                    throw new IllegalArgumentException();
                }
                break;
            
            default:
                throw new IllegalArgumentException();
        }
    }
    
    private static void convert(String xmlPath) 
    throws IOException, Sync4jException {
        System.out.println("converting xmlPath:" + xmlPath);
        
        File xmlDir = new File(xmlPath);
        List filesToConvert = getFilesInDir(xmlDir);
        for (Iterator it=filesToConvert.iterator();it.hasNext();){
            try {
                File file = (File)it.next();
                System.out.println("file:" + file.getAbsolutePath());
                
                if (xmlToWbxml) {
                    xmlToWbxml(file);
                }
                if (wbxmlToXml) {
                    wbxmlToXml(file);
                }

            } catch (Exception ex){
                ex.printStackTrace();
            }
        }
    }
    
    private static void xmlToWbxml(File file) 
    throws IOException, Sync4jException {
        String xml = IOTools.readFileString(file);
        
        byte[] wbxml = WBXMLTools.toWBXML(xml);

        String xmlFileName = file.getAbsolutePath();
        String wbxmlFileName = xmlFileName.substring(0, xmlFileName.lastIndexOf("."));
        wbxmlFileName = wbxmlFileName + ".wbxml";
        
        //now write the wbxml to a file
        System.out.println("Writing to: " + wbxmlFileName);
        IOTools.writeFile(wbxml, wbxmlFileName);
    }
    
    private static void wbxmlToXml(File file) 
    throws IOException, Sync4jException {
        byte[] wbxml = IOTools.readFileBytes(file);
        
        String xml = WBXMLTools.wbxmlToXml(wbxml);

        String wbxmlFileName = file.getAbsolutePath();
        String xmlFileName = wbxmlFileName.substring(0, wbxmlFileName.lastIndexOf("."));
        xmlFileName = xmlFileName + ".xml";
        
        //now write the xml to a file
        System.out.println("Writing to: " + xmlFileName);
        IOTools.writeFile(xml, xmlFileName);
    }

    private static List getFilesInDir(File dir){
        List files = new ArrayList();
        File[] dirFiles = dir.listFiles();
        for (int i=0; ((dirFiles != null) && (i<dirFiles.length)); i++){
            File file = dirFiles[i];
            if (file.isFile()){
                if (xmlToWbxml) {
                    if (file.getName().toUpperCase().endsWith(".XML")){
                        files.add(file);
                    }
                } else {
                    if (file.getName().toUpperCase().endsWith(".WBXML")){
                        files.add(file);
                    }
                }
            } else {
                files.addAll(getFilesInDir(file));
            }
        }
        return files;
    }

    
    public static String readWbxmlAsXml(File wbxmlFile) 
    throws IOException, Sync4jException {
        FileInputStream fis = new FileInputStream(wbxmlFile);
        byte[] byteArray = new byte[(int)wbxmlFile.length()];
        int count = fis.read(byteArray);
        fis.close();

        return WBXMLTools.wbxmlToXml(byteArray);
    }
}