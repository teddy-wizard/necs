/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.test.tools.ant;

import java.io.*;
import java.util.ArrayList;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.types.PatternSet;

import sync4j.framework.tools.IOTools;
import sync4j.test.TestFailedException;
import sync4j.test.tools.PostWBXMLSyncML;


/**
 * This is an Ant task that executes the protocol level tests.
 * <p>
 * @see sync4j.test.tools.PostSyncML
 * @see sync4j.test.tools.CompareXml
 * <p
 * It can be used in the following manner:
 *
 * <pre>
 * &lt;task name="test-syncml" ...&gt;
 *   &lt;testsyncml url="{initial URL}" test="{test name}"&gt;
 *     &lt;patternset&gt;
          &lt;exclude name="/SyncML/SyncHdr/SessionID/self::node()[1]"/&gt;
          &lt;exclude name="/SyncML/SyncHdr/RespURI/self::node()[1]"/&gt;
        &lt;/patternset&gt;
 *   &lt;/testsyncml&gt;
 * &lt;/task&gt;
 * </pre>
 *
 * @author Stefano Fornari
 * @version $Id: TestSyncMLWBXMLTask.java,v 1.3 2004/04/13 09:35:13 luigia Exp $
 */
public class TestSyncMLWBXMLTask extends org.apache.tools.ant.Task {

    // -------------------------------------------------------------- Properties

    protected String url = null;
    public void setUrl(String url) {
        this.url = url;
    }

    protected String test = null;
    public void setTest(String test) {
        this.test = test;
    }

    protected ArrayList xpathPatterns = new ArrayList();

    public void addPatternset(PatternSet set) {
        xpathPatterns.add(set);
    }

    // ----------------------------------------------------- Task Implementation

    public void execute() throws BuildException {
        //
        // make sure we don't have an illegal set of options
        //
        validateAttributes();

        //
        // Deal with the specified XPath to exclude from the comparison of
        // the XML messages. They are specified through one or more inner
        // <patternset> elements.
        //
        ArrayList allExcludeXPaths = new ArrayList();

        PatternSet ps = null;
        String[] xpaths = null;
        for (int i = 0; i < xpathPatterns.size(); i++) {
            ps = (PatternSet) xpathPatterns.get(i);
            xpaths = ps.getExcludePatterns(project);
            for (int j = 0; j < xpaths.length; ++j) {
                allExcludeXPaths.add(xpaths[j]);
            }
        }  // next i

        log("Initial URL: "    + url             );
        log("Test: "           + test            );
        log("Ignored XPaths: " + allExcludeXPaths);

        xpaths = (String[])allExcludeXPaths.toArray(new String[0]);

        //
        // Execute the tests now
        //
        FilenameFilter filter = IOTools.getFileTypeFilter("wbxml");

        String[] msgFiles = new File(test).list(filter);

        try {
            new PostWBXMLSyncML(
                url                                 ,
                new File(project.getBaseDir(), test),
                msgFiles                            ,
                xpaths
            ).syncAndTest();

            log("Test " + test + " passed!");
        } catch (IOException e) {
            log(e.getMessage(), Project.MSG_ERR);
            throw new BuildException("Error executing PostSyncMLTask", e);
        } catch (TestFailedException e) {
            log("Test " + test + " failed: " + e.getMessage(), Project.MSG_INFO);
        }
    }

    // ------------------------------------------------------- Protected methods

    protected void validateAttributes() throws BuildException {
        try {
            new java.net.URL(url);
        } catch (Exception e) {
            new BuildException("Malformed url exception: " + url);
        }
    }

}