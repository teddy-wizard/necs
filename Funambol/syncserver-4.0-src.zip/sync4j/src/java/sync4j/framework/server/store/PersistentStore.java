/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server.store;

import java.util.Map;

import sync4j.framework.server.store.Clause;
import sync4j.framework.server.store.ConfigPersistentStoreException;
import sync4j.framework.server.store.PersistentStoreException;

/**
 * A <i>PersistentStore</i> is a class that stores objects in a persistent media
 * such as a database. The work of saving and reading data to and from the store 
 * is delegated to the store() and read() methods that can take the appropriate
 * actions based on the type of the object that has to be written or read.
 * <p>
 * To store an object just call <i>store(obj)</i>.<br>
 * To read an object call read(obj).
 * <p>
 * Note that those two methods return true if they know how to deal with the 
 * given object; that return value is not intended to be a success indicator. It 
 * just tells the caller that the <i>PersistentStore</i> knew how to process the
 * given object.
 * <p>
 * A <i>PersistentStore</i> can be configured calling <i>configure()</i> with a 
 * <i>java.util.Map</i> parameter containing configuration information. The 
 * content of the map is implementation specific.
 * 
 * @author  Stefano Fornari @ Funambol
 *
 * @version $Id: PersistentStore.java,v 1.7 2004/04/13 09:37:34 luigia Exp $
 */
public interface PersistentStore {
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Configure the persistent store
     * 
     * @param config an <i>Map</i> containing configuration parameters.
     *
     * @throws ConfigPersistentStoreException
     */
    public void configure(Map config) throws ConfigPersistentStoreException;
    
    /**
     * Store the given object to the persistent media.
     *
     * @param o object to be stored
     *
     * @return true if this <i>PersistentStore</i> processed the given object,
     *         false otherwise
     *
     * @throws PersistentStoreException
     */
    public boolean store(Object o) throws PersistentStoreException;
    
    /**
     * Read from the persistent media the given object.
     *
     * @param o object to be read
     *
     * @return true if this <i>PersistentStore</i> processed the given object,
     *         false otherwise
     *
     * @throws PersistentStoreException
     */
    public boolean read(Object o) throws PersistentStoreException;
    
    /**
     * Read all objects stored the persistent media.
     *
     * @param objClass the object class handled by the persistent store
     *
     * @return an array containing the objects read. If no objects are found an
     *         empty array is returned. If the persistent store has not 
     *         processed the quest, null is returned.
     *
     * @throws PersistentStoreException
     */
    public Object[] read(Class objClass) throws PersistentStoreException;
    
    /**
     * Delete the given object to the persistent media
     *
     * @param o object to be deleted
     *
     * @return true if this <i>PersistentStore</i> processed the given object,
     *         false otherwise
     *
     * @throws PersistentStoreException
     */
    public boolean delete(Object o) throws PersistentStoreException;
    
    /**
     * Read all objects stored the persistent media.
     *
     * @param objClass the object class handled by the persistent store
     * @param clause the array of select conditions
     *
     * @return an array containing the objects read. If no objects are found an
     *         empty array is returned. If the persistent store has not 
     *         processed the quest, null is returned.
     *
     * @throws PersistentStoreException
     */
    public Object[] read(Object o, Clause clause) throws PersistentStoreException;
    
    /**
     * Store the given object to the persistent media.
     *
     * @param id the id of the object
     * @param o object to be stored
     * @param operation the operation to execute on the object (insert or update)
     *
     * @return true if this <i>PersistentStore</i> processed the given object,
     *         false otherwise
     *
     * @throws PersistentStoreException
     */
    public boolean store(String id, Object o, String operation) throws PersistentStoreException;    
    
}