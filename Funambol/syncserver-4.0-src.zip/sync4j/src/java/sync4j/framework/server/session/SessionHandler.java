/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server.session;

/**
 * This class represents the handler for a SyncML session. It coordinates and
 * handles the packages and messages as dictated by the protocol.
 * <p>
 * The entry point is <i>processMessage()</i>, which determines which message is
 * expected and what processing has to be done (depending on the value of
 * <i>currentState</i>).
 * <p>
 * In the current implementation separate initialization is required. 
 * <p>
 * <i>SessionHandler</i> makes use of a <i>SyncEngine</i> for all 
 * tasks not related to the handling of the protocol.
 * See <i>sync4j.framework.engine.SyncEngine</i> for more information.
 *
 * @see sync4j.framework.engine.SyncEngine
 *
 * @author  Stefano Fornari @ Funambol
 */

import sync4j.framework.core.*;
import sync4j.framework.protocol.*;
import sync4j.framework.server.error.InvalidCredentialsException;
import sync4j.framework.engine.SyncEngine;
import sync4j.framework.engine.SyncEngineFactory;

/**
 * This interface represent the functionality a session object must provide.
 * Different implementations can provide their own policy, but they have to be
 * compliant at least to this contract.
 */
public interface SessionHandler {
    
    public String getSessionId();
   
    /**
     * Sets the property <i> syncEngineFactory</i> and creates the instance of
     * the <i>SyncEngine</i> objects.
     *
     * @param syncEngineFactory the factory
     */
    public void setSyncEngineFactory(SyncEngineFactory syncEngineFactory);
    
    public SyncEngineFactory getSyncEngineFactory();
    
    public SyncEngine getSyncEngine();
    
    /**
     * The session a new session?
     *
     * @return true if the session is new, false otherwise
     */
    public boolean isNew();
    
    public void setNew(boolean newSession);
       
    /**
     * Returns true if the sessione has been authenticated.
     *
     * @return true if the sessione has been authenticated, false otherwise
     */
    public boolean isAuthenticated();
    
    /**
     * Processes the given message. See the class description for more 
     * information.
     *
     * @param message the message to be processed
     *
     * @return the response message
     *
     * @throws ProtocolException
     */
    public SyncML processMessage(SyncML message) throws ProtocolException, InvalidCredentialsException;
    
    /**
     * Called by the <i>SessionManager</i> when the session is expired.
     * It logs out the credential and release aquired resources.
     */
    public void expire();
    
    /**
     * Gets the creation timestamp of the session
     */
    public long getCreationTimestamp();
    
    /**
     * Indicates that the current session successfully ended. The synch-
     * ronization can be finalized and committed.
     */
    public void commit();
    
    /**
     * Indicates that the current session must be forced to end without 
     * commiting the work (note that this does not automatically mean that the
     * synchronization is rolled back).
     *
     * @param statusCode the reason for the aborting
     */
    public void abort(int statusCode);
    
    public SyncState getSyncState();
}