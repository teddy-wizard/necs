/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server;

import java.io.Serializable;

import sync4j.framework.server.Sync4jSourceType;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * This class represents a connector.
 *
 * @author Luigia Fassina @ Funambol
 *
 * @version $Id: Sync4jConnector.java,v 1.2 2004/04/13 09:37:33 luigia Exp $
 *
 */
public class Sync4jConnector implements Serializable {

	private String connectorId;
    private String connectorName;
    private String description;
    private String adminClass;
    private Sync4jSourceType[] syncSourceType;

    /** Creates a new instance of SyncConnector */
    public Sync4jConnector() {
        this(null,null,null,null);
    }

    public Sync4jConnector(String connectorId  , 
                           String connectorName, 
                           String description  , 
                           String adminClass   ) {
        this.connectorId   = connectorId;
        this.connectorName = connectorName;
        this.description   = description;
        this.adminClass    = adminClass;
    }

    /** Getter for property connectorId.
     * @return Value of property connectorId.
     *
     */
    public String getConnectorId() {
        return connectorId;
    }

    /** Setter for property connectorId.
     * @param name New value of property connectorId.
     *
     */
    public void setConnectorId(String connectorId) {
        this.connectorId = connectorId;
    }

    /** Getter for property connectorName.
     * @return Value of property connectorName.
     *
     */
    public String getConnectorName() {
        return connectorName;
    }

    /** Setter for property connectorName.
     * @param name New value of property connectorName.
     *
     */
    public void setConnectorName(String connectorName) {
        this.connectorName = connectorName;
    }

    /** Getter for property desciption.
     * @return Value of property description.
     *
     */
    public String getDescription() {
        return description;
    }

    /** Setter for property description.
     * @param name New value of property description.
     *
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /** Getter for property adminClass.
     * @return Value of property adminClass.
     *
     */
    public String getAdminClass() {
        return adminClass;
    }

    /** Setter for property adminClass.
     * @param name New value of property adminClass.
     *
     */
    public void setAdminClass(String adminClass) {
        this.adminClass = adminClass;
    }

    public void setSourceTypes(Sync4jSourceType[] syncSourceType) {
        this.syncSourceType = syncSourceType;
    }
    public Sync4jSourceType[] getSourceTypes() {
        return this.syncSourceType;
    }

    public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("IdConnector  :" + this.connectorId);
		sb.append("ConnectorName:" + this.connectorName);
		sb.append("Description  :" + this.description);
		sb.append("AdminClass   :" + this.adminClass);
		return sb.toString();
    }

}