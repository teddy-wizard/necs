/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server;

import java.io.Serializable;

/**
 * This class represents a Sync4j module.
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: Sync4jModule.java,v 1.3 2004/04/13 09:37:33 luigia Exp $
 *
 */
public class Sync4jModule implements Serializable {

    private String            moduleId     ;
    private String            moduleName   ;
    private String            description  ;
    private Sync4jConnector[] connectors   ;

    /** Creates a new instance of Sync4jModule */
    public Sync4jModule() {
        this(null,null,null);
    }

    public Sync4jModule(String moduleId   , 
                        String moduleName , 
                        String description) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.description = description;
    }

    /** Getter for property moduleId.
     * @return Value of property moduleId.
     *
     */
    public String getModuleId() {
        return moduleId;
    }

    /** Setter for property moduleId.
     * @param name New value of property moduleId.
     *
     */
    public void setModuleId(String moduleId) {
        this.moduleId = moduleId;
    }

    /** Getter for property moduleName.
     * @return Value of property moduleName.
     *
     */
    public String getModuleName() {
        return moduleName;
    }

    /** Setter for property moduleName.
     * @param name New value of property moduleName.
     *
     */
    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    /** Getter for property desciption.
     * @return Value of property description.
     *
     */
    public String getDescription() {
        return description;
    }

    /** Setter for property description.
     * @param name New value of property description.
     *
     */
    public void setDescription(String description) {
        this.description = description;
    }

    public void setConnectors(Sync4jConnector[] connectors) {
        this.connectors = connectors;
    }

    public Sync4jConnector[] getConnectors() {
        return connectors;
    }

    public String toString() {
		StringBuffer sb = new StringBuffer();
		
		sb.append("ModuleId: ").append(moduleId).append(", ")
          .append("ModuleName: ").append(moduleName).append(", ")
		  .append("Description: ").append(description);
		  
		return sb.toString();
    }

}