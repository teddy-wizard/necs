/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.server.session;

import java.util.ArrayList;

import sync4j.framework.core.AbstractCommand;
import sync4j.framework.core.Alert;
import sync4j.framework.core.Map;
import sync4j.framework.core.Sync;

/** 
 * This class represents the state of the Syncronization process because cache 
 * all informations that could be used in that process.
 * It is set during the Initialization process.
 *
 * @author Luigia Fassina @ funambol.com
 * @version $Id: SyncState.java,v 1.6 2004/04/13 09:37:34 luigia Exp $
 */
public class SyncState {
    
    // ---------------------------------------------------------- Public Methods
    
    /**
     * Cache all AbstractCommand (Alert, Put, Get)
     */
    private ArrayList listClientCommands = new ArrayList();
   
    public void addClientCommands(AbstractCommand[] clientCommands) {
        for (int i=0; ((clientCommands != null) && (i<clientCommands.length)); i++) {
            listClientCommands.add(clientCommands[i]);
        }
    }
    
    public AbstractCommand[] getClientCommands() {
        return (AbstractCommand[])listClientCommands.toArray(new AbstractCommand[listClientCommands.size()]);
    }

    /**
     * Cache the AlertCommand
     */
    private ArrayList listClientAlerts = new ArrayList();
   
    public void addClientAlerts(Alert[] clientAlerts) {
        for (int i=0; ((clientAlerts != null) && (i<clientAlerts.length)); i++) {
            listClientAlerts.add(clientAlerts[i]);
        }
    }
    
    public void resetClientAlerts() {
        listClientAlerts = new ArrayList();
    }
    
    public Alert[] getClientAlerts() {
        return (Alert[])listClientAlerts.toArray(new Alert[listClientAlerts.size()]);
    }
    
    /**
     * Cache the MapCommand
     */
    private ArrayList listMapCommands = new ArrayList();
    
    public void addMapCommands(Map[] mapCommands) {
        for (int i=0; ((mapCommands != null) && (i<mapCommands.length)); i++) {
            listMapCommands.add(mapCommands[i]);
        }
    }
    
    public Map[] getMapCommands() {
        return (Map[])listMapCommands.toArray(new Map[listMapCommands.size()]);
    }
    
    /**
     * Cache the SyncCommand
     */
    private ArrayList listSyncCommands = new ArrayList();
    
    public void addSyncCommands(Sync[] syncCommands) {
        for (int i=0; ((syncCommands != null) && (i<syncCommands.length)); i++) {
            listSyncCommands.add(syncCommands[i]);
        }
    }
    
    public Sync[] getSyncCommands() {
        return (Sync[])listSyncCommands.toArray(new Sync[listSyncCommands.size()]);
    }
}