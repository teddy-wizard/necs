/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server.store;

import java.util.Map;
import java.util.logging.Logger;

import java.sql.*;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import sync4j.framework.server.store.PersistentStoreException;
import sync4j.framework.logging.Sync4jLogger;

import org.apache.commons.lang.StringUtils;

/**
 * This is a base class for <i>PersistenStore</i> objects. It does not persist
 * any object, but it provides services common to concrete implementations.
 *
 * @author  Stefano Fornari @ Funambol
 *
 * @version $Id: BasePersistentStore.java,v 1.5 2004/04/13 09:37:34 luigia Exp $
 *
 */
public abstract class BasePersistentStore {
    
    // --------------------------------------------------------------- Constants
    
    public static final String
    CONFIG_JNDI_DATA_SOURCE_NAME = "jndi-data-source-name";
    
    /**
     * Logger
     */
    protected transient final Logger log = Sync4jLogger.getLogger();
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The JNDI name of the datasource to be used
     */
    protected String jndiDataSourceName = null;
    
    public String getJndiDataSourceName() {
        return this.jndiDataSourceName;
    }
    
    public void setJndiDataSourceName(String jndiDataSourceName) throws PersistentStoreException {
        this.jndiDataSourceName = jndiDataSourceName;
        
        if (jndiDataSourceName == null) {
            dataSource = null;
        }
        
        try {
            InitialContext ctx = new InitialContext();
            dataSource = (DataSource) ctx.lookup(jndiDataSourceName);
        } catch (NamingException e) {
            throw new PersistentStoreException("Data source "
            + jndiDataSourceName
            + " not found"
            , e
            );
        }
    }
    
    // ---------------------------------------------------------- Protected data
    
    protected transient DataSource dataSource = null;
    
    // ------------------------------------------------------------ Constructors
    
    // ---------------------------------------------------------- Public methods

    /** Configures the persistent store
     *
     * @param config an <i>Map</i> containing configuration parameters.
     *
     * @throws ConfigPersistentStoreException
     *
     */
    public void configure(Map config) throws ConfigPersistentStoreException {
        
        checkConfigParams(config);
        
        try {
            setJndiDataSourceName((String) config.get(CONFIG_JNDI_DATA_SOURCE_NAME));
        } catch (PersistentStoreException e) {
            throw new ConfigPersistentStoreException( "Error creating the datasource: "
                                                    + e.getMessage()
                                                    , e
                                                    );
        }
    }
        
    // ------------------------------------------------------- Protected methods
        
    // ------------------------------------------------------- Protected methods
        
    // --------------------------------------------------------- Private methods
    
    /**
     * Checks if the given configuration parameters contain all required
     * parameters. If not a <i>ConfigPersistentStoreException</i> is thrown.
     *
     * @param config the <i>Map</i> containing the configuration parameters
     *
     * @throws ConfigPersistentStoreException in case of missing parameters
     */
    private void checkConfigParams(Map config)
    throws ConfigPersistentStoreException {
        StringBuffer sb = new StringBuffer();
        
        if (StringUtils.isEmpty((String) config.get(CONFIG_JNDI_DATA_SOURCE_NAME))) {
            sb.append(CONFIG_JNDI_DATA_SOURCE_NAME);
        }
    }
}