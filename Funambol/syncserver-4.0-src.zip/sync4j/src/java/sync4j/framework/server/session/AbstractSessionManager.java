/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server.session;

import java.io.Serializable;

import java.util.Collection;
import java.util.logging.Logger;
import java.util.logging.Level;

import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.server.session.SessionHandler;
import sync4j.framework.server.session.SessionExpiredException;

/**
 * This is a basic implementation of a session manager. Subclasses have to 
 * extend it in order to get and create sessions.
 *
 * @author  Stefano Fornari @ Funambol.com
 */
public abstract class AbstractSessionManager implements Serializable {
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The lifetime of a session in minutes
     */
    private int lifeTime = 5;
    
    /** Getter for property lifeTime.
     * @return Value of property lifeTime.
     */
    public int getLifeTime() {
        return lifeTime;
    }
    
    /** Setter for property lifeTime.
     * @param lifeTime New value of property lifeTime.
     */
    public void setLifeTime(int lifeTime) {
        this.lifeTime = lifeTime;
    }

    
    // ------------------------------------------------------------ Private data
    
    /**
     * The logger
     */
    private static final Logger log = Sync4jLogger.getLogger();
        
    // ---------------------------------------------------------- Public methods
    
    public SessionHandler getSessionHandler(String sessionId) 
    throws SessionExpiredException {
        log.finest("Looking for session " + sessionId);
        
        SessionHandler handler = getSessionFromBag(sessionId);
        
        if (handler == null) {
            handler  = createNewSession(sessionId);
            putSessionInBag(sessionId, handler);
        } else {
            if (handler.isNew()) {
                handler.setNew(false);
                putSessionInBag(sessionId, handler);
            }
        }
        
        return handler;
    }
    
    public void removeSession(String sessionId) {
        log.fine("Removing session " + sessionId);
        
        try {
            SessionHandler oldSession = getSessionFromBag(sessionId);
            oldSession.expire();
            removeSessionFromBag(sessionId);
        } catch (SessionExpiredException e) {
            log.finest("Session already expired");
        }
        
        if (log.isLoggable(Level.FINEST)) {
            log.finest("Remaining sessions: " + getSessionBag());
        }
    }
    
    public void removeSession(SessionHandler handler) {
        log.fine("Removing session " + ((handler!=null) ? handler.getSessionId() : "null"));
        
        handler.expire();
        removeSessionFromBag(handler.getSessionId());
        
        if (log.isLoggable(Level.FINEST)) {
            log.finest("Remaining sessions: " + getSessionBag());
        }
    }
    
    public void storeSessionHandler(SessionHandler handler) {
        log.fine("Storing session " + handler);
        
        putSessionInBag(handler.getSessionId(), handler);
    }
    
    
    // -------------------------------------------------------- Abstract methods
    
    abstract protected SessionHandler createNewSession(String sessionId);
    abstract protected SessionHandler getSessionFromBag(String sessionId) throws SessionExpiredException;
    abstract protected void putSessionInBag(String sessionId, SessionHandler handler);
    abstract protected void removeSessionFromBag(String sessionId);
    abstract protected Collection getSessionBag();
}