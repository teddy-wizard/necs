/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * This class represents a user with username and password and a list of roles.
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: SyncUser.java,v 1.2 2004/04/13 09:37:33 luigia Exp $
 *
 */
public class SyncUser implements Serializable {

    private String username;
    private String password;
    private String email;
    private String firstname;
    private String lastname;
    private String[] roles;

    /** Creates a new instance of SyncUser */
    public SyncUser() {
        this(null, null, null, null, null, null);
    }

    public SyncUser(String username, String password, String email, String firstname, String lastname, String[] roles) {
        this.username  = username;
        this.password  = password;
        this.email     = email;
        this.firstname = firstname;
        this.lastname  = lastname;
        this.roles  = roles;
    }

    /** Getter for property username.
     * @return Value of property username.
     *
     */
    public String getUsername() {
        return username;
    }

    /** Setter for property username.
     * @param name New value of property username.
     *
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /** Getter for property password.
     * @return Value of property password.
     *
     */
    public String getPassword() {
        return password;
    }

    /** Setter for property password.
     * @param name New value of property password.
     *
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /** Getter for property email.
     * @return Value of property email.
     *
     */
    public String getEmail() {
        return email;
    }

    /** Setter for property email.
     * @param name New value of property email.
     *
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /** Getter for property firstname.
     * @return Value of property firstname.
     *
     */
    public String getFirstname() {
        return firstname;
    }

    /** Setter for property firstname.
     * @param name New value of property firstname.
     *
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /** Getter for property lastname.
     * @return Value of property lastname.
     *
     */
    public String getLastname() {
        return lastname;
    }

    /** Setter for property lastname.
     * @param name New value of property lastname.
     *
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /** Getter for property roles.
     * @return Value of property roles.
     *
     */
    public String[] getRoles() {
        return roles;
    }

    /** Setter for property roles.
     * @param name New value of property roles.
     *
     */
    public void setRoles(String[] roles) {
        this.roles = roles;
    }

    public String toString() {
        ToStringBuilder sb = new ToStringBuilder(this);

        sb.append("username:",  username);
        sb.append("password:",  password);
        sb.append("email:",     email);
        sb.append("firstname:", firstname);
        sb.append("lastname:",  lastname);

        return sb.toString();
    }

}