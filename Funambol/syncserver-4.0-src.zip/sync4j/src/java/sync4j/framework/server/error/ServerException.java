/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server.error;

import sync4j.framework.core.StatusCode;
import sync4j.framework.core.Sync4jException;

/**
 * @version $Id: ServerException.java,v 1.2 2004/04/13 09:37:33 luigia Exp $
 * @author  Stefano Fornari @ Funambol
 */
public class ServerException extends Sync4jException {
    
    // --------------------------------------------------------------- Constants
    
    public static int UNKNOWN = -1;
    
    // ------------------------------------------------------------ Private data
    
    private int statusCode = UNKNOWN;
    
    // ------------------------------------------------------------ Constructors

    /**
     * @param strMsg  human readable String that describes the cause of the
     *      exception
     */
    public ServerException(final String strMsg) {
        super(strMsg);
    }

    /**
     * Constructor for the ServerException object
     *
     * @param statusCode  Description of the Parameter
     * @param strMsg      Description of the Parameter
     */
    public ServerException(final int statusCode, final String strMsg) {
        this(statusCode, strMsg, null);
    }

    public ServerException(final String strMsg, final Throwable cause) {
        this(UNKNOWN, strMsg, cause);
    }
    
    public ServerException(final int statusCode, final String strMsg, final Throwable cause) {
        super(strMsg, cause);
        
        this.statusCode = statusCode;
    }
    
    public ServerException(final Throwable cause) {
        this(UNKNOWN, "", cause);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Gets the statusCode attribute of the ServerException object
     *
     * @return   The statusCode value
     */
    public int getStatusCode() {
        return statusCode;
    }

    
    /**
     * Returns the SyncML message associated to the status code of this exception
     *
     * @return the SyncML message associated to the status code of this exception
     */
    public String getSyncMLMessage() {
        int code = getStatusCode();
        
        String msg = StatusCode.getStatusDescription(code);
        
        return (msg == null) ? "" : msg;
    }
    
    /**
     * Redefines the standard <i>getMessage()</i> method.
     *
     * @return <status code> <status description> - <message description>
     */
    public String getMessage() {
        return statusCode
             + " "
             + getSyncMLMessage()
             + " - "
             + super.getMessage()
             ;
    }
}