/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server;

import org.apache.commons.lang.builder.ToStringBuilder;

import sync4j.framework.server.SyncTimestamp;


/**
 * This class specializes a <i>SyncTimestamp</i> to represent a last sync
 * timestamp as retrieved from the database. It associates a sync timestamp with
 * a particular principal and database.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: LastTimestamp.java,v 1.5 2004/04/13 09:37:33 luigia Exp $
 */
public class LastTimestamp extends SyncTimestamp {
    
    // ------------------------------------------------------------- Public data
    
    public String principal = null;  // the id of the principal
    public String database  = null;
    
    // ------------------------------------------------------------ Constructors
    
    /** Creates a new instance of LastTimestamp */
    public LastTimestamp(final String principal, final String database) {
        super();
        this.principal = principal ;
        this.database  = database  ;
    }
    
    /** Creates a new instance of LastTimestamp */
    public LastTimestamp(final String principal, final String database, final String tag, final long start, final long end) {
        this(principal, database);
        this.tag      = tag      ;
        this.start    = start    ;
        this.end      = end      ;
    }
    
    // ---------------------------------------------------------- Public methods
    
    public String toString() {
        ToStringBuilder sb = new ToStringBuilder(this);
        
        sb.append("principal", principal).
           append("database" , database).
           append("tag"      , tag).
           append("start"    , new java.sql.Timestamp(start)).
           append("end"      , new java.sql.Timestamp(end)  );
        
        return sb.toString();
    }
}