/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * This class represents a Sync4j device.
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: Sync4jDevice.java,v 1.2 2004/04/13 09:37:33 luigia Exp $
 *
 */
public class Sync4jDevice implements Serializable {

    private String deviceId;
    private String description;
    private String type;

    /** Creates a new instance of Sync4jDevice */
    public Sync4jDevice() {
        this(null, null, null);
    }

    public Sync4jDevice(String deviceId, String description, String type) {
        this.deviceId    = deviceId;
        this.description = description;
        this.type        = type;
    }

    /** Getter for property deviceId.
     * @return Value of property deviceId.
     *
     */
    public String getDeviceId() {
        return deviceId;
    }

    /** Setter for property deviceId.
     * @param name New value of property deviceId.
     *
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    /** Getter for property description.
     * @return Value of property description.
     *
     */
    public String getDescription() {
        return description;
    }

    /** Setter for property description.
     * @param name New value of property description.
     *
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /** Getter for property type.
     * @return Value of property type.
     *
     */
    public String getType() {
        return type;
    }

    /** Setter for property type.
     * @param name New value of property type.
     *
     */
    public void setType(String type) {
        this.type = type;
    }

    public String toString() {
        ToStringBuilder sb = new ToStringBuilder(this);

         sb.append("deviceId",    deviceId);
         sb.append("description", description);
         sb.append("type",        type);

         return sb.toString();
    }

}