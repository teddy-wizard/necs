/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server.store;

import org.apache.commons.lang.builder.ToStringBuilder;
import java.io.Serializable;

/**
 * This class represents selection clause of a query.
 *
 * @author  Luigia Fassina @ Funambol
 * @version $Id: WhereClause.java,v 1.5 2004/04/13 09:37:34 luigia Exp $
 *
 */
public class WhereClause 
extends Clause 
implements Serializable {

    // -------------------------------------------------------- Public constants
	public static final String OPT_START_WITH = "START_WITH";
	public static final String OPT_END_WITH   = "END_WITH"  ;
	public static final String OPT_CONTAINS   = "CONTAINS"  ;
	public static final String OPT_EQ         = "EQ"        ;
	public static final String OPT_GT         = "GT"        ;
	public static final String OPT_LT 		  = "LT"        ;
	public static final String OPT_BETWEEN    = "BETWEEN"   ;
	public static final String OPT_GE         = "GE"        ;
	public static final String OPT_LE         = "LE"        ;

    // ------------------------------------------------------------ Private data
    private static final String OPT_UPPER      = "upper("    ;

    private String property;
    private String[] value;
    private String operator;
    private boolean caseSensitive;

    /**
     * The default constructor is not intended to be used.
     */
    protected WhereClause() {
        this(null, null, null, false);
    }

    public WhereClause(String property, String[] value, String operator, boolean caseSensitive) {
        this.property      = property;
        this.value         = value;
        this.operator      = operator;
        this.caseSensitive = caseSensitive;
    }

    /** Getter for property property.
     * @return Value of property property.
     *
     */
    public String getProperty() {
        return property;
    }

    /** Setter for property property.
     * @param name New value of property property.
     *
     */
    public void setProperty(String property) {
        this.property = property;
    }

    /** Getter for property value.
     * @return Value of property value.
     *
     */
    public String[] getvalue() {
        return value;
    }

    /** Setter for property value.
     * @param name New value of property value.
     *
     */
    public void setValue(String[] value) {
        this.value = value;
    }

    /** Setter for property parameter.
     * @param name New value of property value.
     *
     */
    public void setParameter(String[] value) {
        this.value = value;
    }

    /** Getter for property operator.
     * @return Value of property operator.
     *
     */
    public String getOperator() {
        return operator;
    }

    /** Setter for property operator.
     * @param name New value of property operator.
     *
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /** Getter for property caseSensitive.
     * @return Value of property caseSensitive.
     *
     */
    public boolean isCaseSensitive() {
        return caseSensitive;
    }

    /** Setter for property caseSensitive.
     * @param name New value of property caseSensitive.
     *
     */
    public void setCaseSensitive(boolean caseSensitive) {
        this.caseSensitive = caseSensitive;
    }

    // ------------------------------------------------ Implementation of Clause
    
    public PreparedWhere getPreparedWhere() {
        String property = getProperty();
        String operator = getOperator();
        String[] values = getvalue();
        boolean caseSensitive = isCaseSensitive();

        StringBuffer query = new StringBuffer();
        
        assert (values != null);
        
        PreparedWhere where = new PreparedWhere();
        where.parameters = new Object[values.length];
        
        String uprOpen     = ""      ;
        String uprClose    = ""      ;
        String uprProperty = property;
        
        if (!caseSensitive) {
            uprOpen  = OPT_UPPER;
            uprClose = ")";
            uprProperty = " UPPER("+property+")";
        }

        if (OPT_START_WITH.equalsIgnoreCase(operator)) {        
            query.append(uprProperty).append(" LIKE ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0] + '%';
        } else if (OPT_END_WITH.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" LIKE ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = '%' + values[0];
        } else if (OPT_CONTAINS.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" LIKE ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = '%' + values[0] + '%';
        } else if (OPT_EQ.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" = ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0];
        } else if (OPT_GT.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" > ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0];
        } else if (OPT_LT.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" < ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0];
        } else if (OPT_BETWEEN.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(' ').append(OPT_BETWEEN).append(' ').append(uprOpen).append('?').append(uprClose)
                .append(" AND ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0];
            where.parameters[1] = values[1];
        } else if (OPT_GE.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" >= ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0];
        } else if (OPT_LE.equalsIgnoreCase(operator)) {
            query.append(uprProperty).append(" <= ").append(uprOpen).append('?').append(uprClose);
            where.sql = query.toString();
            where.parameters[0] = values[0];
        }
        
        where.sql = '(' + where.sql + ')';
        return where;
    }
    
    // -------------------------------------------------------------------------

    public String toString() {
        ToStringBuilder sb = new ToStringBuilder(this);
        sb.append("operator:",  operator);
        sb.append("property:",  property);
        for (int i=0; i<value.length; i++) {
            sb.append("value:",  value[i]);
        }
        sb.append("caseSensitive:",  caseSensitive);

        return sb.toString();
    }
}