/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.server.store;

/**
 * This class represents a where clause with PreparedStatement-like parameters.
 * The where clause is stored in the <i>where</i> property; parameters are 
 * stored in the <i>parameters</i> property.
 * This is just an helper class, thus no getter/setter methods are provided.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: PreparedWhere.java,v 1.2 2004/04/13 09:37:34 luigia Exp $
 */
public class PreparedWhere {
    
    public String sql = null;
    public Object[] parameters = null;
    
}