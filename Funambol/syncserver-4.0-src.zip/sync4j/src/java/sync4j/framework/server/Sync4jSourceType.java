/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.server;

import java.io.Serializable;
import org.apache.commons.lang.builder.ToStringBuilder;

import sync4j.framework.engine.source.SyncSource;
import sync4j.framework.engine.source.SyncSourceException;

/**
 * This class represents a Sync4j source type with a list of SyncSource
 * with the same type.
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: Sync4jSourceType.java,v 1.3 2004/04/13 09:37:33 luigia Exp $
 *
 */
public class Sync4jSourceType implements Serializable {

    private String sourceTypeId;
    private String description;
    private String config;
    private String adminClass;
    private SyncSource[] syncSource;
    private SyncSourceException[] syncSourceFailed;

    /** Creates a new instance of SyncSourceType */
    public Sync4jSourceType() {
        this(null, null, null,null);
    }

    public Sync4jSourceType(String sourceTypeId, String description, String config, String adminClass) {
        this.sourceTypeId  = sourceTypeId;
        this.description   = description;
        this.config		   = config;
        this.adminClass   = adminClass;
    }

    /** Getter for property sourceTypeId.
     * @return Value of property sourceTypeId.
     *
     */
    public String getSourceTypeId() {
        return sourceTypeId;
    }

    /** Setter for property sourceTypeId.
     * @param name New value of property sourceTypeId.
     *
     */
    public void setSourceTypeId(String sourceTypeId) {
        this.sourceTypeId = sourceTypeId;
    }

    /** Getter for property description.
     * @return Value of property description.
     *
     */
    public String getDescription() {
        return description;
    }

    /** Setter for property description.
     * @param name New value of property description.
     *
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /** Getter for property config.
     * @return Value of property config.
     *
     */
    public String getConfig() {
        return config;
    }

    /** Setter for property config.
     * @param name New value of property config.
     *
     */
    public void setConfig(String config) {
        this.config = config;
    }

    /** Getter for property adminClass.
     * @return Value of property adminClass.
     *
     */
    public String getAdminClass() {
        return adminClass;
    }

    /** Setter for property adminClass.
     * @param name New value of property adminClass.
     *
     */
    public void setAdminClass(String adminClass) {
        this.adminClass = adminClass;
    }

    /**
     * Set an array of instances of SyncSource
     */
    public void setSyncSources(SyncSource[] syncSource) {
        this.syncSource = syncSource;
    }
    public SyncSource[] getSyncSources() {
        return this.syncSource;
    }

    /**
     * Set an array of SyncSourceException with the uri of SyncSource with
     * creations failed
     */
    public void setSyncSourcesFailed(SyncSourceException[] syncSourceFailed) {
        this.syncSourceFailed = syncSourceFailed;
    }
    public SyncSourceException[] getSyncSourcesFailed() {
        return this.syncSourceFailed;
    }
    
    public String toString() {
        ToStringBuilder sb = new ToStringBuilder(this);

         sb.append("sourceTypeId", sourceTypeId);
         sb.append("description" , description);
         sb.append("config"      , config);
         sb.append("adminClass"  , adminClass);

         return sb.toString();
    }

}