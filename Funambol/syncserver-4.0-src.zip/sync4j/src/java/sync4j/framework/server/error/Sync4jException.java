/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.server.error;

import java.text.MessageFormat;

/**
 * Base exception. 
 *
 * @author    Sean C. Sullivan, Stefano Fornari
 */
public class Sync4jException extends Exception {

   /**
     * @param strMsg  human readable String that describes the cause of the
     *      exception
     */
    public Sync4jException(final String strMsg) {
        super(strMsg);
    }
    
    /**
     * Constructor for the ServerException object
     *
     * @param strMsg    Description of the Parameter
     * @param aobjArgs  Description of the Parameter
     */
    public Sync4jException(final String strMsg, final Object[] aobjArgs) {
         super(MessageFormat.format(strMsg, aobjArgs));
    }
    
    public Sync4jException(final String strMsg, final Throwable cause) {
        super(strMsg, cause);
    }
     
    public Sync4jException(final Throwable cause) {
        super(cause);
    }
}