/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.server;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;

import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.server.error.MappingException;

import java.util.logging.Logger;
import java.util.logging.Level;

import sync4j.framework.security.Sync4jPrincipal;

//
// This is a two-way map so that can be accessed by key or by value.
//
import org.apache.commons.collections.DoubleOrderedMap;


import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Represent the mapping between the LUID from the client Items and
 * the GUID from the server Items.
 *
 * @author Richard Wafer
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: ClientMapping.java,v 1.15 2004/04/13 09:37:33 luigia Exp $
 */
public class ClientMapping {

    //Contain LUID -> GUID for each client
    ///private DoubleOrderedMap clientMapping = new DoubleOrderedMap();
    private java.util.HashMap clientMapping = new java.util.HashMap();
    
    //Contain the principal of the client device
    private Sync4jPrincipal principal = null;

    // the requested database
    private String dbURI;

    //When the Client Mapping are modified or added
    private boolean modified = false;
    private ArrayList modifiedKeys = new ArrayList();

    //When entries in the Mapping are deleted
    private boolean deleted = false;
    private ArrayList deletedKeys = new ArrayList();

    //Sync4j Logging faciiy
    //Transient keyword will disable serialisation for this member
    private transient Logger log = Sync4jLogger.getLogger();

    // ------------------------------------------------------------- Contructors

    /**
     * Construct a client Mapping to a device Id the Mapping must be populate
     * with data from the persistence store by calling
     * PersistenceStoreManager.read.
     *
     */
    public ClientMapping(Sync4jPrincipal principal, String dbURI) {
        this.principal = principal;
        this.dbURI     = dbURI    ;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * @return true if the mapping where modified or added since initialization
     */
    public boolean isModified() {
        return modified;
    }

    /**
     * @return true if item where deleted since the initialisation
     */
    public boolean isDeleted() {
        return deleted;
    }

    /**
     * Initialize the client Mapping with data from the Persistence Store
     * @param mapping A structure that contain LUID -> GUID
     */
    public void initializeFromMapping(Map mapping) {
        resetMapping();
        clientMapping.putAll(mapping);
    }

    /**
     * Get the deleted Entries from the client Mapping
     * @return A map that contain a mapping of LUID -> GUID
     */
    public Map getDeletedEntries() {
        HashMap result = null;
        if (deleted) {
            result = new HashMap();
            for (int i = 0; i < deletedKeys.size(); i++) {
                String item = (String) deletedKeys.get(i);
                result.put(item, clientMapping.get(item));
            }
        }
        return result;
    }

    /**
     * Get the modified entries from the client Mapping
     * @return A map with only the modified entries LUID -> GUID
     */
    public Map getModifiedEntries() {
        HashMap result = null;
        if (modified) {
            result = new HashMap();
            for (int i = 0; i < modifiedKeys.size(); i++) {
                String item = (String) modifiedKeys.get(i);
                result.put(item, clientMapping.get(item));
            }
        }
        return result;
    }

    /**
     * Get the current mapping.
     *
     * @return the current mapping as a Map
     */
    public Map getMapping() {
        Map ret = new HashMap();

        ret.putAll(clientMapping);

        return ret;
    }

    /**
     * Get the Client Device Id that correspond to that Client
     * @return The Device Id
     */
    public String getClientDeviceId() {
        return principal.getDeviceId();
    }

    /**
     * Get the principal
     *
     * @return the principal
     */
    public Sync4jPrincipal getPrincipal() {
        return principal;
    }

    /**
     * Get the database uri
     *
     * @return <i>dbURI</i>
     */
    public String getDbURI() {
        return dbURI;
    }

    /**
     * Add a mapping between a LUID and a GUID from the server
     * @param luid The LUID of the client item
     * @param guid The GUID of the server item
     * @throws MappingException
     */
    private void addMapping(String luid, String guid)
    throws MappingException {
        if (clientMapping.containsKey(luid)) {
            throw new MappingException(
            "Mapping already exists for LUID " + luid + " (" + guid +")"
            );
        }
/*
        if (clientMapping.containsValue(guid)) {
            if (log.isLoggable(Level.WARNING)) {
                log.warning("Mapping already exists for GUID " + guid + " (" + luid +")");
            }
            
            //rewrite the mapping with old GUID and new LUID
            String luidOld = (String)clientMapping.getKeyForValue(guid);

            if (log.isLoggable(Level.INFO)) {
                log.info("addMapping new LUID-GUID " + luid +" - " + guid + " ; old LUID " + luidOld);
            }
            
            clientMapping.remove(luidOld);
            modifiedKeys.remove(luidOld);
        }
*/        
        modified = true;
                
        clientMapping.put(luid, guid);
        modifiedKeys.add(luid);

        //
        // If we add an entrie that was considered deleted
        // remove it from the deleted entries.
        //
        removeDeletedKey(luid);
    }

    /**
     * Get the mapped GUID for the given LUID.
     * @param luid The LUID of the client item
     * @return The mapped value for the key in input
     */
    public String getMappedValueForLuid(String luid) {
        String result = null;
        if ((result = (String) clientMapping.get(luid)) == null) {
            log.finest("No mapping found for LUID: " + luid);
        }
        return result;
    }

    /**
     * Get the mapped LUID key for the given GUID value.
     * @param guid The GUID of the client item
     * @return The mapped value for the key in input
     */
    public String getMappedValueForGuid(String guid) {
        String result = null;
                        
        if (clientMapping.containsValue(guid)) {
            java.util.Set keys = clientMapping.keySet();
            java.util.Iterator itKeys = keys.iterator();
            while (itKeys.hasNext()) {
                String key = (String)itKeys.next();
                String value = (String)clientMapping.get(key);
                if (value.equalsIgnoreCase(guid)) {
                    return key;
                }
            }
        }

        log.finest("No mapping found for GUID: " + guid);
        return result;
    }

    /**
     * Remove a mapped values from the cache given a LUID.
     * @param luid The LUID for the item from the client
     */
    public void removeMappedValuesForLuid(String luid) {
        if (clientMapping.remove(luid) == null) {
            if (log.isLoggable(Level.FINEST)) {
                log.warning("Client Mapping not found for LUID " + luid + " when removing");
            }
            return;
        }
        addDeletedKey(luid);
    }

    /**
     * Remove a mapped values from the cache given a GUID
     * @param guid The GUID for the item from the client
     */
    public void removeMappedValuesForGuid(String guid) {
        String luid = getMappedValueForGuid(guid);
        if (luid == null) {
            if (log.isLoggable(Level.FINEST)) {
                log.warning("Client Mapping not found for GUID " + guid + " when removing");
            }
            return;
        } else {
            clientMapping.remove(luid);
        }
        addDeletedKey(luid);
    }

    /**
     * Updates a key value mapping. If the mapping does not exist, it calls
     * <code>addMapping(luid, guid)</code>, otherwise the existing mapping is
     * updated.
     *
     * @param luid The LUID value from the client item
     * @param guid The GUID value from the server item
     *
     * @throws MappingException
     */
    public void updateMapping(String luid, String guid)
    throws MappingException {
        //
        // If new, just call addMapping
        //
        if (clientMapping.containsKey(luid) == false) {
            addMapping(luid, guid);
            return;
        }
        
        clientMapping.remove(luid);
        clientMapping.put(luid, guid);
        deletedKeys.remove(luid);
        modifiedKeys.add(luid);
        modified = true;

        assert (modified == true);
    }
    
    /**
     * Clears these mappings moving the existing and new mappings to deleted.
     * This is used for example to re-initialize the LUID-GUID mapping for a
     * slow sync.
     */
    public void clearMappings() {

        deletedKeys.addAll(clientMapping.values());
        deletedKeys.addAll(modifiedKeys);
        
        clientMapping.clear();
        
        modified = false;
        deleted = true;
    }
    
    public String toString() {
         ToStringBuilder sb = new ToStringBuilder(this);

         sb.append("clientMapping", clientMapping);
         sb.append("modifiedKeys" , modifiedKeys );
         sb.append("deletedKeys"  , deletedKeys  );

         return sb.toString();
    }
    
    // --------------------------------------------------------- Private methods
    
    /**
     * Reset the content of the Client Mapping HashMap and the state
     * of the current mapping.
     */
    private void resetMapping() {
        //We clean the map
        if (!clientMapping.isEmpty()) {
            clientMapping.clear();
        }
        //If we have modified item to the map
        if (modified) {
            modifiedKeys.clear();
            modified = false;
        }
        //If we have deleted item to the map
        if (deleted) {
            deletedKeys.clear();
            deleted = false;
        }
    }
    
    /**
     * Remove LUID from the deleted entries
     * @param luid The LUID for the item from the client
     */
    private void removeDeletedKey(String luid) {
        if (deleted && deletedKeys.contains(luid)) {
            deletedKeys.remove(luid);
            if (deletedKeys.size() == 0) {
                deleted = false;
            }
        }
    }

    /**
     * Remove LUID from the modified entries
     * @param luid The LUID for the item from the client
     */
    private void removeModifiedKey(String luid) {
        if (modified && modifiedKeys.contains(luid)) {
            modifiedKeys.remove(luid);
            if (modifiedKeys.size() == 0) {
                modified = false;
            }
        }
    }
    
    /**
     * Add LUID into the deleted keys.
     * @param luid The LUID for the item from the client
     */
    private void addDeletedKey(String luid) {        
        removeModifiedKey(luid);        
        deleted = true;
        deletedKeys.add(luid);        
    }
}