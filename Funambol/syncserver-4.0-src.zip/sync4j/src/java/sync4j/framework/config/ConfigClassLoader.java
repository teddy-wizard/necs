/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.config;

import java.net.*;

/**
 * This is the class loader to be used to read configuration information and 
 * server-side JavaBeans persisted as XML streams.
 *
 * @author  Stefano Fornari
 */
public class ConfigClassLoader extends java.net.URLClassLoader {
    
    /** 
     * Creates a new instance of ConfigClassLoader.<br>
     */
    public ConfigClassLoader(URL[] urls, ClassLoader parent) {
        super(urls, parent);
    }
    
    public String toString() {
        URL[] urls = getURLs();
        
        StringBuffer sb = new StringBuffer(getClass().getName());
        sb.append(" for: ");
        for (int i=0; ((urls != null) && (i<urls.length)); ++i) {
            sb.append(urls[i].toString()).append(' ');
        }
        
        return sb.toString();
    }
}