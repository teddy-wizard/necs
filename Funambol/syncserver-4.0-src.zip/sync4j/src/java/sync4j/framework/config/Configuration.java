/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.config;

import java.io.InputStream;
import java.io.IOException;

import java.net.URL;

import java.util.Map;
import java.util.HashMap;
import java.util.Properties;
import java.util.Collections;

import sync4j.framework.tools.beans.BeanFactory;
import sync4j.framework.config.ConfigurationException;

import org.apache.commons.lang.StringUtils;

/**
 * Incapsulates all the configuration information about a <i>Sync4jEngine</i>.
 * Configuration parameters are stored as properties in a Map structure. The
 * key is the name of the parameter and it is strucured in dotted separated
 * namespaces. The value of the parameter is the value of the key and can be of
 * any type. Accessor methods are provided to get the value of the parameter in
 * a particular type (such as String, int, double, boolean, ...).<br>
 * Access to getXXX() and setXXX() methods are synchronized.
 *
 * @author  Stefano Fornari @ funambol
 *
 * @version $Id: Configuration.java,v 1.7 2004/04/13 09:37:29 luigia Exp $
 */
public class Configuration
implements java.io.Serializable {

    // --------------------------------------------------------------- Constants

    // ------------------------------------------------------------ Private data

    private static final Map internalMap = Collections.synchronizedMap(new HashMap());

    // -------------------------------------------------------------- properties

    private transient ClassLoader classLoader = null;

    /** Getter for property classLoader.
     * @return Value of property classLoader.
     *
     */
    public ClassLoader getClassLoader() {
        return classLoader;
    }

    /** Setter for property classLoader.
     * @param classLoader New value of property classLoader.
     *
     */
    public void setClassLoader(ClassLoader classLoader) {
        this.classLoader = classLoader;
    }

    // ------------------------------------------------------------ Constructors

    public Configuration() {
    }

    // ---------------------------------------------------------- Public methods

    public String getStringValue(String name, String def)
    throws ConfigurationException {
        String value = (String)internalMap.get(name);

        return (value == null) ? def : value;
    }

    public String getStringValue(String name)
    throws ConfigurationException {
        String value = (String)internalMap.get(name);

        if (value == null) {
            throw new ConfigurationException("No " + name + " property defined");
        }

        return value;
    }

    /**
     * Turns a character separated values property into an array of String
     * objects given the separator. For example:
     * <pre>
     *      one;two;trhee
     * </pre>
     * will result in
     * <pre
     *      {"one", "two", "trhee"}
     * </pre>
     *
     * @param name the name of the property
     * @param separator the separator character
     *
     * @return an array of Strings
     */
    public String[] getStringArray(String name, char separator)
    throws ConfigurationException {
        String value = (String)internalMap.get(name);

        if (value == null) {
            throw new ConfigurationException("No " + name + " property defined");
        }

        //
        // NOTE: String.split() is not used for performance reason. We do not
        //       need a regular expression here.
        //
        return StringUtils.split(value, String.valueOf(separator));
    }

    public int getIntValue(String name, int def)
    throws ConfigurationException {
        Integer value = (Integer)internalMap.get(name);

        return (value == null) ? def : value.intValue();
    }

    public int getIntValue(String name)
    throws ConfigurationException {
        Integer value = (Integer)internalMap.get(name);

        if (value == null) {
            throw new ConfigurationException("No " + name + " property defined");
        }

        return value.intValue();
    }

    public boolean getBoolValue(String name, boolean def)
    throws ConfigurationException {
        Boolean value = (Boolean)internalMap.get(name);

        return (value == null) ? def : value.booleanValue();
    }

    public boolean getBoolValue(String name)
    throws ConfigurationException {
        Boolean value = (Boolean)internalMap.get(name);

        if (value == null) {
            throw new ConfigurationException("No " + name + " property defined");
        }

        return value.booleanValue();
    }

    public Object getValue(String name, Object def)
    throws ConfigurationException {
        Object value = internalMap.get(name);

        return (value == null) ? def : value;
    }

    public Object getValue(String name)
    throws ConfigurationException {
        Object value = internalMap.get(name);

        if (value == null) {
            throw new ConfigurationException("No " + name + " property defined");
        }

        return value;
    }

    /**
     * It is supposed that the value of the parameter is a class name. It returns
     * an instance of that class, created with <i>newInstance()</i>.
     *
     * @param name the name of the parameter
     *
     * @return an instance of the class specified by the parameter
     *
     * @throws ConfigurationException in case of errors
     */
    public Object getClassInstance(String name)
    throws ConfigurationException {
       String value = (String)internalMap.get(name);

       if (value == null) {
           throw new ConfigurationException("No " + name + " property defined");
       }

       try {
           return Class.forName(value).newInstance();
       } catch (Exception e) {
           throw new ConfigurationException( "Error in creating an instance of "
                                           + value
                                           , e                                );
       }
    }

    /**
     * It is supposed that the value of the parameter is a bean name. It returns
     * that bean, created with <i>BeanFactory.getBeanInstance()</i>.
     *
     * @param name the name of the parameter
     *
     * @return an instance of the class specified by the parameter
     *
     * @throws ConfigurationException in case of errors
     */
    public Object getBeanInstance(String name)
    throws ConfigurationException {
       String value = (String)internalMap.get(name);

       if (value == null) {
           throw new ConfigurationException("No " + name + " property defined");
       }

       try {
           return BeanFactory.getBeanInstance(classLoader, value);
       } catch (Exception e) {
           throw new ConfigurationException( "Error in creating an instance of "
                                           + value
                                           , e                                );
       }
    }

    /**
     * Create and return an array of bean as specified by a list of bean names.
     *
     * @param name the name of the paramenter
     * @param separator the separator character
     *
     */
    public Object[] getBeanArray(String name, char separator)
    throws ConfigurationException {
        String[] values = getStringArray(name, separator);

        Object[] ret = new Object[values.length];

        int i = 0;
        try {
            for (; i<ret.length; ++i) {
                ret[i] = BeanFactory.getBeanInstance(classLoader, values[i]);
            }
        } catch (Exception e) {
            throw new ConfigurationException ( "Error in creating the bean "
                                             + values[i]
                                             , e                           );
        }

        return ret;
    }

    public synchronized void load(InputStream is) throws IOException {
        Properties properties = new Properties();

        properties.load(is);

        internalMap.putAll(properties);
    }

    public synchronized void load(String uri)
    throws IOException {
        load(new URL(uri).openStream());
    }

    public String toString() {
        StringBuffer sb = new StringBuffer();

        sb.append(getClass().getName()).append(" - ");
        sb.append(internalMap.toString()).append(" - ");
        sb.append("classLoader: " + classLoader);

        return sb.toString();
    }

}