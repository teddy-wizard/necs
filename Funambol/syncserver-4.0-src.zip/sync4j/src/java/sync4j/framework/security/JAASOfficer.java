/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.security;


import java.util.logging.Logger;
import java.util.logging.Level;

import java.security.Principal;
import javax.security.auth.*;
import javax.security.auth.login.*;
import javax.security.*;

import sync4j.framework.security.Officer;
import sync4j.framework.security.jaas.CredentialHandler;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.core.Cred;


/**
 * This implementation of <i>Officier</i> uses JAAS for authentication and
 * authorization.
 * <p>
 * In order to use this implementation, remember to set the system property
 * java.security.auth.login.config accordingly as specified in JAAS documentation
 * or in the documentation of the application server in use.<br>
 * For example, in the case of the J2EE RI, in order to use the SimpleLoginModule
 * delivered with the framework, the following lines have to be added to the
 * file <i>{J2EESDK_HOME}/lib/security/login.config</i>:
 * <pre>
 * sync4j {
 *   sync4j.framework.security.jaas.SimpleLoginModule required required debug=true;
 * }
 * </pre>
 * The security policy must be changed as well; add the following lines to the
 * file <i>{J2EESDK_HOME}/lib/security/server.policy</i>:
 * <pre>
 * permission javax.security.auth.AuthPermission "createLoginContext.sync4j";
   permission javax.security.auth.AuthPermission "modifyPrincipals";
 * </pre>
 *
 * TO DO: authorization
 *
 * @author  Stefano Fornari @ Funambol.com
 */
public class JAASOfficer implements Officer, java.io.Serializable {
   
    // ---------------------------------------------------------- Protected data

    protected transient Logger log = Sync4jLogger.getLogger();

    // -------------------------------------------------------------- Properties

    /**
     * Has the last login failed for incorrect login/password?
     */
    private boolean loginFailed = false;

    public boolean isLoginFailed() {
        return loginFailed;
    }

    /**
     * Has the last login failed for expired temporary login?
     */
    private boolean loginExpired = false;

    public boolean isLoginExpired() {
        return loginExpired;
    }
    
    /**
     * Can use a guest credential if there is not credential in the message?
     */
    private boolean guestEnabled = true;
        
    public boolean isGuestEnabled() {       
        return this.guestEnabled;
    }
    
    public void setGuestEnabled(boolean guestEnabled) {
        this.guestEnabled = guestEnabled;
    }

    
    // ---------------------------------------------------------- Public methods

    /**
     * Authenticates a credential based on the configured JAAS subsystem.
     *
     * @param credential the credential to be authenticated
     *
     * @return true if the credential is autenticated, false otherwise
     */
    public boolean authenticate(Cred credential) {
        CredentialHandler handler = null;

        if (log.isLoggable(Level.INFO)) {
            log.info("Authenticating credential: " + credential);
        }

        try {
            handler = new CredentialHandler(credential);
            LoginContext lc = new LoginContext("sync4j", handler);
            lc.login();

            if (log.isLoggable(Level.INFO)) {
                log.info(lc.getSubject() + " authenticated!");
            }
        } catch (AccountExpiredException e) {
             if (log.isLoggable(Level.FINEST)) {
                log.throwing(getClass().getName(), "authenticate", e);
            }
            log.info( "Login failed for "
                    + handler.getLogin()
                    );

            loginFailed  = false;
            loginExpired = true;

            return false;
        } catch (FailedLoginException e) {
             if (log.isLoggable(Level.FINEST)) {
                log.throwing(getClass().getName(), "authenticate", e);
            }
            log.info( "Login failed for "
                    + handler.getLogin()
                    );

            loginFailed  = true;
            loginExpired = false;

            return false;
        } catch (LoginException e) {
            if (log.isLoggable(Level.FINEST)) {
                log.throwing(getClass().getName(), "authenticate", e);
            }
            log.info( "Login failed for "
                    + handler.getLogin()
                    );

            loginFailed  = false;
            loginExpired = false;

            return false;
        } catch (IllegalArgumentException e) {
            log.throwing(getClass().getName(), "authenticate", e);
            return false;
        } catch (Throwable t) {
            //
            // Maybe a configuration error
            //
            t.printStackTrace();
        }

        log.info( handler.getLogin() + " logged in");
        return true;
    }

    /**
     * Authorizes a resource.
     *
     * @param principal the requesting entity
     * @param resource the name (or the identifier) of the resource to be authorized
     *
     * @return true if the credential is authorized to access the resource, false
     *         otherwise
     */
    public boolean authorize(Principal principal, String resource) {
        return true;
    }

    /** Un-authenticates a credential.
     *
     * @param credential the credential to be unauthenticated
     */
    public void unAuthenticate(Cred credential) {
        //
        // Do nothing. In the current implementation, the authentication is
        // discarde as soon as the LoginContext is garbage collected.
        //
    }


    private void readObject(java.io.ObjectInputStream in)
    throws java.io.IOException, ClassNotFoundException {
        in.defaultReadObject();
        log = Sync4jLogger.getLogger();
    }

}