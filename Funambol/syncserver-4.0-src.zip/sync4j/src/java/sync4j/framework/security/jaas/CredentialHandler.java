/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.security.jaas;

import java.io.*;
import java.util.logging.Logger;
import java.util.logging.Level;

import javax.security.auth.callback.*;

import sync4j.framework.core.Cred;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.tools.Base64;
import org.apache.commons.lang.StringUtils;


/**
 * This handler implements the JAAS <i>CallbackHandler</i> interface. It stores 
 * a <i>Credential</i> object for later use as principal and credentials provider. 
 * This simple implementation supports basic authentication stored bas64 encoded
 * in the form login:password.
 *
 * TO DO: supports MD5 authentication
 *
 * @author  Stefano Fornari @ Funambol.com
 */
public class CredentialHandler implements CallbackHandler {
    
    // --------------------------------------------------------------- Constants
    
    public static final String TYPE_BASIC = "syncml:auth-basic";
    public static final String TYPE_CLEAR = "syncml:auth-clear";
    public static final String SUPPORTED_TYPES = TYPE_BASIC + ',' + TYPE_CLEAR;
    
    // ------------------------------------------------------------ Private data
    
    private String     login      = null;
    private char[]     password   = null;
    
    // ---------------------------------------------------------- Protected data
    
    protected final Logger log = Sync4jLogger.getLogger();
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * Creates a new instance of CredentialHandler 
     *
     * @param credential
     * 
     * @throws IllegalArgumentException
     */
    public CredentialHandler(Cred credential) throws IllegalArgumentException {
        
        String type = credential.getType();
        
        if (log.isLoggable(Level.FINEST)) {
            log.finest("credential: " + credential);
        }
        
        if (SUPPORTED_TYPES.indexOf(type) < 0) {
            throw new IllegalArgumentException( "Authorization type '"
                                              + type
                                              + "' not supported"
                                              );
        }
        
        if (TYPE_BASIC.equals(type)) {
            String s = new String(Base64.decode(credential.getData()));
            
            int p = s.indexOf(':');
            
            if (p == -1) {
                login = s;
                password = null;
            } else {
                login = (p>0) ? s.substring(0, p) : "";
                password = toChars((p == (s.length()-1)) ? "" : s.substring(p+1));
            }
        } else if (TYPE_CLEAR.equals(type)) {
            String s = credential.getData();
            
            int p = s.indexOf(':');
            
            if (p == -1) {
                login = s;
                password = null;
            } else {
                login = (p>0) ? s.substring(0, p) : "";
                password = toChars((p == (s.length()-1)) ? "" : s.substring(p+1));
            }
        }
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the login of this credential.
     * 
     * @return the login value
     */
    public String getLogin() {
        return login;
    }
    
    // ------------------------------------------------------------------ handle
    
    public void handle(Callback[] callbacks) 
    throws IOException, UnsupportedCallbackException {
        for (int i = 0; i < callbacks.length; i++) {
            log.finest("Handling " + callbacks[i]);
            
            if (callbacks[i] instanceof TextOutputCallback) {

                // display the message according to the specified type
                TextOutputCallback toc = (TextOutputCallback)callbacks[i];
                switch (toc.getMessageType()) {
                   case TextOutputCallback.INFORMATION:
                      log.info(toc.getMessage());
                      break;
                   case TextOutputCallback.ERROR:
                      log.severe(toc.getMessage());
                      break;
                   case TextOutputCallback.WARNING:
                      log.warning(toc.getMessage());
                     break;
                   default:
                      throw new IOException( "Unsupported message type: " 
                                           + toc.getMessageType()
                                           );
                }

            } else if (callbacks[i] instanceof NameCallback) {
                NameCallback nc = (NameCallback)callbacks[i];
                nc.setName(login);
            } else if (callbacks[i] instanceof PasswordCallback) {
                PasswordCallback nc = (PasswordCallback)callbacks[i];
                nc.setPassword(password);
            } else {
                throw new UnsupportedCallbackException
                 (callbacks[i], "Unrecognized Callback");
            }
          }
    }
    
    // --------------------------------------------------------- Private methods
    
    private char[] toChars(String str) {
        if (StringUtils.isEmpty(str)) {
            return new char[0];
        }
        
        int l = str.length();
        char[] ret = new char[l];
        
        str.getChars(0, l, ret, 0);
        
        return ret;
    }
    
}