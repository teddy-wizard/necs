/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.security.jaas;

import java.util.logging.*;
import java.util.Map;
import java.security.Principal;

import javax.security.auth.*;
import javax.security.auth.spi.*;
import javax.security.auth.login.*;
import javax.security.auth.callback.*;

import sync4j.framework.security.Sync4jPrincipal;
import sync4j.framework.logging.Sync4jLogger;

/**
 * This is a simple implementation of a JAAS login module. It always authenticates
 * and uthorizes.
 *
 * @author  Stefano Fornari @ Funambol.com
 */
public class SimpleLoginModule implements LoginModule {
    
    // ------------------------------------------------------------ Private data
    
    private Subject         subject        = null ;
    private CallbackHandler handler        = null ;
    private boolean         loginSucceded  = false;
    private boolean         loginCommitted = false;
    private Principal       principal      = null ;
    private String          username       = null ;
    private String          password       = null ;
    
    // ---------------------------------------------------------- Protected data
    
    protected final Logger log = Sync4jLogger.getLogger();
    
    // ---------------------------------------------------------- Public methods
    
    public void initialize(Subject         subject            ,
                           CallbackHandler handler            ,
                           Map             sharedState        ,
                           Map             options            ) {
                               
        this.subject = subject;
        this.handler = handler;
        this.loginSucceded = this.loginCommitted = false;
        this.username = null;
        this.password = null;
        
        if (log.isLoggable(Level.FINEST)) {
            log.finest("sharedState: " + sharedState);
            log.finest("options: " + options);
        }
    }
    
    public boolean login() throws LoginException {
        if (handler == null) {
            throw new LoginException("No CallbackHandler defined");
        }
        
        //
        // Creates two callbacks: one for user, one for password. They are for
        // demonstration purpose only, because they will never be used by this
        // implementation of <i>LoginModule</i>
        //
        Callback[] callbacks = new Callback[2];
        
        NameCallback nameCallback = new NameCallback("Username");
        PasswordCallback passwordCallback = new PasswordCallback("Password", false);
        
        callbacks[0] = nameCallback;
        callbacks[1] = passwordCallback;
        
        try {
            handler.handle(callbacks);
            
            username = nameCallback.getName();
            password = (passwordCallback.getPassword() == null) ? null 
                                                                : new String(passwordCallback.getPassword());
            
            passwordCallback.clearPassword();
        } catch (Exception e) {
            throw new LoginException(e.toString());
        }
        
        loginSucceded = true;
        return true;
    }
    
    public boolean commit() throws LoginException {
        if (loginSucceded == false) {
            return false;
        }
        
        //
        // Login succeded, so create a Principal and add it to the subject
        //
        principal = new Sync4jPrincipal(null, username, null);
        
        if (!(subject.getPrincipals().contains(principal))) {
            subject.getPrincipals().add(principal);
        }
        
        username = null;
        password = null;
        loginCommitted = true;
        
        return true;
    }
    
    public boolean abort() throws LoginException {
        if (loginSucceded == false) {
            return false;
        } else if (loginCommitted == false) {
            loginSucceded = false;
            username  = password  = null;
            principal = null;
        } else {
            logout();
        }
        
        return true;
    }
    
    public boolean logout() throws LoginException {
        subject.getPrincipals().remove(principal);
        
        loginSucceded = loginCommitted = false;
        username = password = null;
        principal = null;
        
        return true;
    }
    
}