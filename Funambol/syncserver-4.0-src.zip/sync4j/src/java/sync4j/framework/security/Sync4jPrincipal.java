/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.security;

import java.security.Principal;

import sync4j.framework.core.Constants;
import sync4j.framework.tools.Base64;

/**
 * This class implements the <i>Pricipal</i> interface and represents a Sync4j
 * principal. In Sync4j a principal is represented by a couple
 * <i>(username, device id)</i> and is associated to a unique id.
 *
 * @author  Stefano Fornari @ Funambol.com
 *
 * @version $Id: Sync4jPrincipal.java,v 1.10 2004/04/13 09:37:33 luigia Exp $
 */
public class Sync4jPrincipal implements Principal, java.io.Serializable {
    // --------------------------------------------------------------- Constants

    // ------------------------------------------------------------ Private data

    private String id       = null; // principalid
    private String username = null;
    private String deviceId = null;
    private String email    = null;
    private String firstName= null;
    private String lastName = null;
    private static String userAndPwd  = null;

    // ------------------------------------------------------------ Constructors
    /**
     * Disable the default constructor.
     */
    protected Sync4jPrincipal() {};

    /**
     * Creates a new instance of UsernamePrincipal
     *
     * @param id principal id
     * @param username the username element of the principal
     * @param deviceId the deviceId element of the principal
     */
    public Sync4jPrincipal(String id, String username, String deviceId) {
        this.id       = id      ;
        this.username = username;
        this.deviceId = deviceId;
    }

    /**
     * Creates a new instance of UsernamePrincipal
     *
     * @param username the username element of the principal
     * @param deviceId the deviceId element of the principal
     *
     */
    public Sync4jPrincipal(String username, String deviceId) {
        this(null, username, deviceId);
    }


    /**
     * Creates a new instance of UsernamePrincipal
     *
     * @param id principal id
     */
    public Sync4jPrincipal(String id) {
        this(id, null, null);
    }

    /**
     * Creates a new instance of CredentialPrinciple from the given Credential
     *
     * @param userpwd user and password in the form <user>:<password>
     * @param type the username coding as expressed in the a Credential object
     * @param deviceId the deviceId element of the principal. Can be NULL
     *
     * @see sync4j.framework.core.Credential
     *
     * @throws IllegalArgumentException
     */
    public static Sync4jPrincipal fromCredential( String userpwd  ,
                                                  String type     ,
                                                  String deviceId ) throws IllegalArgumentException {

        Sync4jPrincipal ret = new Sync4jPrincipal();

        if (Constants.AUTH_SUPPORTED_TYPES.indexOf(type) < 0) {
            throw new IllegalArgumentException( "Authorization type '"
                                              + type
                                              + "' not supported"
                                              );
        }

        if (Constants.AUTH_TYPE_BASIC.equals(type)) {
            String s = new String(Base64.decode(userpwd.getBytes()));

            int p = s.indexOf(':');

            if (p == -1) {
                ret.setUsername(s);
            } else {
                ret.setUsername((p>0) ? s.substring(0, p) : "");
            }
        } else if (Constants.AUTH_TYPE_CLEAR.equals(type)) {
            String s = userpwd;

            int p = s.indexOf(':');

            if (p == -1) {
                ret.setUsername(s);
            } else {
                ret.setUsername((p>0) ? s.substring(0, p) : "");
            }
        }
        
        userAndPwd = userpwd;

        ret.setId(null);
        ret.setDeviceId(deviceId);

        return ret;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * The name of this principal is in the form:
     *   {username}.{deviceId}
     *
     * @return the principal's name
     */
    public String getName() {

        return (deviceId == null)
             ? username
             : (username + '.' + deviceId);
    }

    /**
     * The username part of the principal name.
     *
     * @return the username part of the principal name.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Set the username part of the principal name.
     *
     * @param username the username principal's username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * The device id part of the principal name.
     *
     * @return the device id part of the principal name.
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * Set the device id part of the principal name.
     *
     * @param deviceId the device id principal's username
     */
    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * The principal unique id.
     *
     * @return the unique principal id.
     */
    public String getId() {
        return id;
    }

    /**
     * Set the principal unique id.
     *
     * @param id the principal unique id.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * The user's email of the principal.
     *
     * @return the user's email of the principal.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the user's email of the principal.
     *
     * @param email the user's email of the principal
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * The user's first name of the principal.
     *
     * @return the user's first name of the principal.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Set the user's first name of the principal.
     *
     * @param firstName the user's first name of the principal
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    
    /**
     * The user's last name of the principal.
     *
     * @return the user's last name of the principal.
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Set the user's last name of the principal.
     *
     * @param lastName the user's last name of the principal
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
    /**
     * Two Sync4jPrincipals are equals if and only if:
     * <ul>
     *   <li>o is null or
     *   <li>o is not an instance of Sync4jPrincipal or
     *   <li>the two getName()s do not match
     * </ul>
     *
     * @param o the reference object with which to compare.
     *
     * @return true if this object is the same as the obj argument; false otherwise.
     */
    public boolean equals(Object o) {
        if ((o == null) || !(o instanceof Sync4jPrincipal)) {
            return false;
        }

        return (getName().equals(((Sync4jPrincipal)o).getName()));
    }

    public int hashCode() {
        return getName().hashCode();
    }

    public String toString() {
        return getName();
    }
    
    /**
     * @return userAndPwd user and password in the form <user>:<password>
     */
    public String getEncodedCredentials() {
        return this.userAndPwd;
    }
}