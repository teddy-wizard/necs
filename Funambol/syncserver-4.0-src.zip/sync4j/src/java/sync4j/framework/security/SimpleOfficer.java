/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.security;

import java.security.Principal;

import sync4j.framework.security.Officer;
import sync4j.framework.core.Cred;

/**
 * This is a simple implementation of the <i>Officier</i> interface. It always
 * authenticates and authorizes users and resource accesses.
 *
 * @author  Stefano Fornari @ Funambol.com
 */
public class SimpleOfficer implements Officer {
    
    /**
     * Authenticates a credential.
     *
     * @param credential the credential to be authenticated
     *
     * @return true if the credential is autenticated, false otherwise
     */
    public boolean authenticate(Cred credential) {
        return true;
    }
    
    /**
     * Authorizes a resource.
     *
     * @param principal the requesting entity
     * @param resource the name (or the identifier) of the resource to be authorized
     *
     * @return true if the credential is authorized to access the resource, false
     *         otherwise
     */
    public boolean authorize(Principal principal, String resource) {
        return true;
    }
    
    /** Un-authenticates a credential.
     *
     * @param credential the credential to be unauthenticated
     */
    public void unAuthenticate(Cred credential) {
    }    
    
    /**
     * Read property guestEnabled
     */
    public boolean isGuestEnabled() {
        return false;
    }    
    
    
}