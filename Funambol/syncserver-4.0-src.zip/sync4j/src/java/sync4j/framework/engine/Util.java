/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine;

import java.util.ArrayList;

/**
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Util.java,v 1.3 2004/04/13 09:37:32 luigia Exp $
 */
public final class Util {
    /**
     * Creates an array of Boolean starting from an array of strings
     *
     * @param       string_values   array of value to be converted
     *
     * @return      an array of Boolean
     */
    public static boolean[] createArrayOfBooleans(String[] string_values) {
        boolean[] array = new boolean[string_values.length];

        for(int i=0; i<string_values.length; ++i) {
            array[i] = Boolean.getBoolean(string_values[i]);
        }  // next i

        return array;
    } // createArrayOfBooleans

    /**
     * Creates an array of Character starting from an array of strings
     *
     * @param       string_values   array of value to be converted
     *
     * @return      an array of Character
     */
    public static char[] createArrayOfCharacters(String[] string_values) {
        char[] array = new char[string_values.length];

        for(int i=0; i<string_values.length; ++i) {
            array[i] = (string_values[i].length()>0) ? string_values[i].charAt(0) : ' ';
        }  // next i

        return array;
    } // createArrayOfCharacters

    /**
     * Creates an array of Double starting from an array of strings
     *
     * @param       string_values   array of value to be converted
     *
     * @return      an array of Double
     */
    public static double[] createArrayOfDoubles(String[] string_values) {
        double[] array = new double[string_values.length];

        for(int i=0; i<string_values.length; ++i) {
            array[i] = Double.parseDouble(string_values[i]);
        }  // next i

        return array;
    } // createArrayOfDoubles

    /**
     * Creates an array of Float starting from an array of strings
     *
     * @param       string_values   array of value to be converted
     *
     * @return      an array of Float
     */
    public static float[] createArrayOfFloats(String[] string_values) {
        float[] array = new float[string_values.length];

        for(int i=0; i<string_values.length; ++i) {
            array[i] = Float.parseFloat(string_values[i]);
        }  // next i

        return array;
    } // createArrayOfFloats

    /**
     * Creates an array of Integer starting from an array of strings
     *
     * @param       string_values   array of value to be converted
     *
     * @return      an array of int
     */
    public static int[] createArrayOfIntegers(String[] string_values) {
        int[] array = new int[string_values.length];

        for(int i=0; i<string_values.length; ++i) {
            array[i] = Integer.parseInt(string_values[i]);
        }  // next i

        return array;
    } // createArrayOfIntegers

    /**
     * Creates an array of Long starting from an array of strings
     *
     * @param       string_values   array of value to be converted
     *
     * @return      an array of Long
     */
    public static long[] createArrayOfLongs(String[] string_values) {
        long[] array = new long[string_values.length];

        for(int i=0; i<string_values.length; ++i) {
            array[i] = Long.parseLong(string_values[i]);
        }  // next i

        return array;
    } // createArrayOfLongs

    // =========================================================================

    /**
     * Makes a string concatenating the capitalized version of the given words.<p>
     *
     * For example:
     * <pre>
     * Util.makeCapitalizedString(new String[] { "bean", "blue" });
     * </pre>
     * will return <pre>BeanBlue</pre>.<p>
     *
     * null strings in the <i>words</i> array will be silenty ignored.
     *
     * @param   words     the strings to capitalize and concatenate
     *
     * @return  the capitalized string
     *
     */
    public static String makeCapitalizedString(String[] words) {
        StringBuffer sb = new StringBuffer();

        for(int i=0; i<words.length; ++i) {
            if (words[i] != null) sb.append(capitalizeWord(words[i]));
        }  // next i

        return sb.toString();
    }

    /**
     * Capitalizes a word.<p>
     *
     * For example:
     * <pre>
     * Util.capitalizeWord("bean");
     * </pre>
     * will return <pre>Bean</pre>.
     *
     * @param   word    the word to capitalize
     *
     * @return  the capitalized word
     */
    public static String capitalizeWord(String word) {
        int len = word.length();

        if (len == 1) return word.toUpperCase();

        return word.substring(0, 1).toUpperCase() +
               word.substring(1   )               ;
    }
    
    /**
     * Returns a string representation of an array of Objects. It translates
     * the array in an ArrayList and then invokes toString().
     *
     * @param array     the array
     *
     * @return the string representation of the given array
     */
    public static String arrayToString(Object[] array) {
        ArrayList arrayList = new ArrayList();
        
        for (int i=0; i<array.length; ++i) {
            arrayList.add(array[i]);
        }
        
        return arrayList.toString();
    }
}