/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine;

import java.security.Principal;

import sync4j.framework.engine.SyncItem;

/**
 * This interface represents a synchronization operation between two items. 
 * The possible operations are:
 * <ul>
 * <li>create
 * <li>update
 * <li>delete
 * </ul>
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SyncOperation.java,v 1.9 2004/04/13 09:37:32 luigia Exp $
 */
public interface SyncOperation {
    
    public static final char NEW      = 'N';
    public static final char DELETE   = 'D';
    public static final char UPDATE   = 'U';
    public static final char CONFLICT = 'O';
    public static final char NOP      = '-';
    
    public SyncItem getSyncItemA();
    public void setSyncItemA(SyncItem syncItemA);
    
    public SyncItem getSyncItemB();    
    public void setSyncItemB(SyncItem syncItemB);
    
    /**
     * Does the operation apply to the client source
     *
     * @return true if the operation applies to the client source or false otherwise.
     */
    public boolean isAOperation();
    public void setAOperation(boolean a);
    
    /**
     * Does the operation apply to the server source*
     *
     * @return true if the operation applies to the server source or false otherwise.
     */
    public boolean isBOperation();
    public void setBOperation(boolean b);
    
    public char getOperation();
    
    /**
     * The principal that requested this operation. 
     *
     * @return the principal that requested this operation. It may be null.
     */
    public Principal getOwner();
}