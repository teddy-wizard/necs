/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.security.Sync4jPrincipal;
import sync4j.framework.engine.SyncStrategy;

/**
 * A synchronization engine represents a mechanism used to drive the syncrhonization 
 * process.<br>
 * <i>SyncEngine</i> represents the Context partecipant of the Strategy pattern.<br>
 * It is a sort of factory and manager for the starategy object referenced by
 * the property <i>strategy</i> (that implementing classes must provide).<p>
 * <i>SyncEngine</i> concentrate all the implementation specific information 
 * regarding strategies, sources, databases, services, etc. It is the point of
 * contact between the synchronization, protocol and server services.
 * <p>
 * When a synchronization process must take place, the <i>SyncEngine</i> will 
 * pass the control to the configured strategy, which has the responsability of
 * query item sources in order to define which synchronization operations are 
 * required. Then the synchronization operations are applied to the sources.
 *
 * @see SyncStrategy
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SyncEngine.java,v 1.7 2004/04/13 09:37:32 luigia Exp $
 */
public interface SyncEngine {
    
    /**
     * Get the underlying strategy
     *
     * @return the underlying strategy
     */
    public SyncStrategy getStrategy();
    
    /**
     * Set the synchronization strategy to be used
     */
    public void setStrategy(SyncStrategy strategy);
    
    /**
     * Fires and manages the synchronization process.
     *
     * @throws Sync4jException in case of error
     */
    public void sync(Sync4jPrincipal principal) throws Sync4jException;    
}