/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.engine.SyncEngine;
import sync4j.framework.config.Configuration;

/**
 * The interface of a generic synchronization engine factory. Each implementation
 * will create concrete and specific <i>SyncEngine</i> objects.
 * 
 * @author  Stefano Fornari @ Funambol
 * @version $Id: SyncEngineFactory.java,v 1.5 2004/04/13 09:37:32 luigia Exp $
 */
public interface SyncEngineFactory  {

    /**
     * Configure the factory with a <i>Configuration</i> object. This can
     * eventually be passed to the created sync engine.
     *
     * @param configuration the configuration object
     */
    public void setConfiguration(Configuration configuration);
    
    /**
     * Returns the <i>SyncEngine</i> object to be used, creating it if necessary.
     *
     * @return the <i>SyncEngine</i>
     *
     * @throws Sync4jException
     */
    public SyncEngine getSyncEngine() throws Sync4jException;
}