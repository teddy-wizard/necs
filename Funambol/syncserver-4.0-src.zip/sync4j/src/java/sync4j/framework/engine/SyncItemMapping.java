/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine;

import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncItemKey;

import org.apache.commons.lang.builder.ToStringBuilder;


/**
 * <i>SyncItem</i> is the indivisible entity that can be exchanged in a 
 * synchronization process. It is similar to an Item, but it doesn't contain
 * any data, only status and addressing information. The idea is that a 
 * <i>SyncItem</i> represents status information about an item. Only if an item
 * must be synchronized it needs also the real data.
 * <p>
 * The <i>SyncItemKey</i> uniquely identifies the item into the server. Client 
 * keys must be translated into server keys before create a <i>SyncItem</i>.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SyncItemMapping.java,v 1.3 2004/04/13 09:37:32 luigia Exp $
 * 
 */
public class SyncItemMapping {
    // ------------------------------------------------------------ Private data
    
    /**
     * The SyncItem's unique identifier
     */
    private SyncItemKey key = null;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * Create an instance of <i>SyncItemMapping</i> from the mapped key. 
     *
     * @param key the mapped key; if it is a <i>SyncItemKey</i> already, it is 
     *        taken as key, otherwise a new <i>SyncItemKey</i> is created.
     */
    public SyncItemMapping(Object key) {
        if (key instanceof SyncItemKey) {
            this.key = (SyncItemKey)key;
        } else {
            this.key = new SyncItemKey(key);
        }
    }
    
    
    // ---------------------------------------------------------- Public methods

    public SyncItemKey getKey() {
        return this.key;
    }
    
    public void setMapping(SyncItem syncItemA, SyncItem syncItemB) {
        this.syncItemA = syncItemA;
        this.syncItemB = syncItemB;
    }
    
    /**
     * @return a string representation of this SyncItemMapping for debugging purposes
     */
    public String toString() {
        return new ToStringBuilder(this).
                   append("key"      , key.toString()    ).
                   append("syncItemA", syncItemA         ).
                   append("syncItemB", syncItemB         ).
                   toString();
    } 
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The A item
     */
    private SyncItem syncItemA = null;
    
    /** Getter for property syncItemA.
     * @return Value of property syncItemA.
     *
     */
    public SyncItem getSyncItemA() {
        return syncItemA;
    }
    
    /** Setter for property syncItemA.
     * @param syncItemA New value of property syncItemA.
     *
     */
    public void setSyncItemA(SyncItem syncItemA) {
        this.syncItemA = syncItemA;
    }
    
    /**
     * The B item
     */
    private SyncItem syncItemB = null;
    
    /** Getter for property syncItemA.
     * @return Value of property syncItemA.
     *
     */
    public SyncItem getSyncItemB() {
        return syncItemB;
    }
    
    /** Setter for property syncItemA.
     * @param syncItemB New value of property syncItemB.
     *
     */
    public void setSyncItemB(SyncItem syncItemB) {
        this.syncItemB = syncItemB;
    }
}