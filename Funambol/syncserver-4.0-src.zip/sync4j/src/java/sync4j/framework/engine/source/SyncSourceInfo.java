/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine.source;

import sync4j.framework.engine.source.ContentType;

/**
 * This class wraps the following information about a <i>SyncSource</i>
 * <table>
 * <tr>
 * <td>supportedTypes</td>
 * <td>Types supported by a source</td>
 * </tr>
 * <tr>
 * <td>preferredType</td>
 * <td>The preferred source content type</td>
 * </tr>
 * </table>
 *
 * @author  Stefano Fornari
 */
public class SyncSourceInfo implements java.io.Serializable {
    
    // -------------------------------------------------------------- Properties
    
    private ContentType[] supportedTypes = null;
    
    /** Getter for property supportedTypes.
     * @return Value of property supportedTypes.
     *
     */
    public ContentType[] getSupportedTypes() {
        return this.supportedTypes;
    }    
    
    /** Setter for property supportedTypes.
     * @param supportedTypes New value of property supportedTypes.
     *
     */
    public void setSupportedTypes(ContentType[] supportedTypes) {
        this.supportedTypes = supportedTypes;
        this.preferred  = 0;
    }    
    
    /**
     * The preferred content type index
     **/
    private int preferred = 0;
    
    /** Getter for property preferred.
     * @return Value of property preferred.
     *
     */
    public int getPreferred() {
        return preferred;
    }
    
    /** Setter for property preferredType.
     * @param preferred New value of property preferredType.
     *
     */
    public void setPreferred(int preferred) {        
        this.preferred = preferred;
    }
    
    /**
     * Returns the preferred content type among the supported ones.
     *
     * @return the preferred content type among the supported ones.
     *
     */
    public ContentType getPreferredType() {
        assert ((supportedTypes != null) && (preferred >= 0) && (preferred < supportedTypes.length));
        return supportedTypes[preferred];
    }
    
    // ------------------------------------------------------------ Constructors
    /** 
     * Creates a new instance of SyncSuurceInfo 
     *
     * @param supportedTypes - NOT NULL or EMPTY
     * @param preferred the position in the <i>supportedTypes</i> array of the 
     *                  preferred type
     *
     * @throws IllegalArgumentException if the passed in parameters are not correct
     */
    public SyncSourceInfo(ContentType[] supportedTypes, int preferred) {
        if ((supportedTypes == null) || (supportedTypes.length == 0)) {
            throw new IllegalArgumentException("supportedTypes cannot be null");
        }
        
        if ((preferred<0) || (preferred >= supportedTypes.length)) {
            throw new IllegalArgumentException( "preferred is "
                                              + preferred
                                              + " when the supported type are "
                                              + supportedTypes.length);
        }
        
        this.supportedTypes = supportedTypes;
        this.preferred = preferred;
    }
    
    public SyncSourceInfo() {
    }
}