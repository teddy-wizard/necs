/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine;

import sync4j.framework.core.*;
import sync4j.framework.security.Sync4jPrincipal;
import sync4j.framework.engine.SyncEngine;
import sync4j.framework.engine.SyncStrategy;


/**
 * Abstract base implementation of <i>SyncEngine</i>. <br>
 * Subclasses must at least redefine the following methods:
 * <ul>
 *   <li><i>sync()</i>
 *   <li><i>getModifiedSources()</i>
 *   <li><i>addModifiedSource()</i>
 * </ul>
 *
 * @author Stefano Fornari @ Funambol
 * @version $Id: AbstractSyncEngine.java,v 1.9 2004/04/13 09:37:32 luigia Exp $
 *
 */
public abstract class AbstractSyncEngine 
implements SyncEngine, java.io.Serializable {
    /**
     * The underlying strategy.
     */
    private SyncStrategy strategy = null;
    
    /**
     * Get the underlying strategy
     *
     * @return the underlying strategy
     */
    public SyncStrategy getStrategy() {
        return this.strategy;
    }
    
    /**
     * Set the synchronization strategy to be used
     */
    public void setStrategy(SyncStrategy strategy) {
        this.strategy = strategy;
    }
    
    /**
     * @see sync4j.framework.engine.SyncEngine
     */
    abstract public void sync(Sync4jPrincipal principal) throws Sync4jException;
}