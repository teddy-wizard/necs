/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine.pipeline;

import java.io.Serializable;
import java.util.logging.Logger;
import java.util.logging.Level;

import sync4j.framework.logging.Sync4jLogger;

import sync4j.framework.core.SyncML;
import sync4j.framework.core.Sync4jException;

/** 
 * This class represents the manager of the pipeline. It supplies a hook for adding
 * additional processing and manipulation of the message between the server and the
 * client.
 */
public class PipelineManager implements InputMessageProcessor, OutputMessageProcessor, Serializable {

    // --------------------------------------------------------------- Constants

    // ------------------------------------------------------------ Private data

    private static final Logger log = Sync4jLogger.getLogger("engine");
    
    // ------------------------------------------------------------ Constructors

    // -------------------------------------------------------------- Properties

    private InputMessageProcessor  inputProcessors[]  = null;
    private OutputMessageProcessor outputProcessors[] = null;
   
    /** Getter for property inputProcessors.
     * @return Value of property inputProcessors.
     */
    public InputMessageProcessor[] getInputProcessors() {
        return this.inputProcessors;
    }

    /** Setter for property inputProcessors.
     * @param inputProcessors New value of property inputProcessors.
     */
    public void setInputProcessors(InputMessageProcessor[] inputProcessors) {
        this.inputProcessors = inputProcessors;
    }

    /** Getter for property outputProcessors.
     * @return Value of property outputProcessors.
     */
    public OutputMessageProcessor[] getOutputProcessors() {
        return this.outputProcessors;
    }

    /** Setter for property outputProcessors
     * @param outputProcessors New value of property outputProcessors.
     */
    public void setOutputProcessors(OutputMessageProcessor[] outputProcessors) {
        this.outputProcessors = outputProcessors;
    }

    // ---------------------------------------------------------- Public methods

	public PipelineManager() {
    }
    
    /** Process the message with the input processors.
     * @param processingContext message processing context
     * @param message the message to be processed
     */    
    public void preProcessMessage(MessageProcessingContext processingContext, SyncML message) {
        if (log.isLoggable(Level.FINE)) {
            log.fine("Starting preprocessing");
        }
        
		//cycle on inputMessageProcessor[] elements
		int size = inputProcessors.length;  
        for (int i=0; i<size; i++) {
            try {
                inputProcessors[i].preProcessMessage(processingContext, message);
            } catch(Sync4jException e) {
                log.info("preProcessMessage error: " + e);
            }
        }
    }

    /** Process the message with the output processors.
     * @param processingContext message processing context
     * @param message the message to be processed
     */    
    public void postProcessMessage(MessageProcessingContext processingContext, SyncML message) {
        if (log.isLoggable(Level.FINE)) {
            log.fine("Starting postprocessing");
        }
        
		//cycle on outputMessageProcessor[] elements
		int size = outputProcessors.length;       
		for (int i=0; i<size; i++) {
            try {
                outputProcessors[i].postProcessMessage(processingContext, message);
            } catch(Sync4jException e) {
                log.info("postProcessMessage error: " + e);
            }
		}
    }
        
}