/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine;

import sync4j.framework.engine.SyncOperation;
import sync4j.framework.engine.source.SyncSource;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * This is a base implementation of a <i>SyncOperationStatus</i>
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: SyncOperationStatusImpl.java,v 1.3 2004/04/13 09:37:32 luigia Exp $
 *
 */
public abstract class SyncOperationStatusImpl implements SyncOperationStatus {
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The operation this object represents the execution for
     */
    private SyncOperation operation = null;
    
    /** Getter for property operation.
     * @return Value of property operation.
     *
     */
    public SyncOperation getOperation() {
        return operation;
    }
    
    /**
     * The source the operation was executed on
     */
    private SyncSource syncSource = null;
    
    /** Getter for property syncSource.
     * @return Value of property syncSource.
     *
     */
    public SyncSource getSyncSource() {
        return syncSource;
    }
        
    
    // ------------------------------------------------------------- Contructors
    
    /** 
     * Creates a new instance of SyncOperationStatus
     * 
     * @param operation the operation - NOT NULL
     * @param syncSource the source - NOT NULL
     *
     * @throws IllegalArgumentException in case operation is null
     */
    public SyncOperationStatusImpl(SyncOperation operation, SyncSource syncSource) {
        if (operation == null) {
            throw new IllegalArgumentException("operation cannnot be null");
        }
        if (syncSource == null) {
            throw new IllegalArgumentException("syncSource cannnot be null");
        }
        
        this.operation  = operation ;
        this.syncSource = syncSource;
    }
       
    // ---------------------------------------------------------- Public methods

    public String toString() {
        return new ToStringBuilder(this).
            append("operation",  operation.toString() ).
            append("syncSource", syncSource.toString()).
            toString();
    }
    
    /** The operation status code
     * @return the operation status code
     *
     */
    abstract public int getStatusCode();
    
}