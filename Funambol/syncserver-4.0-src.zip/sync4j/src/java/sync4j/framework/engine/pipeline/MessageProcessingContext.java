/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine.pipeline;

import java.io.Serializable;
import java.util.HashMap;

/**
 * This class allows at the elements of the pipeline to add their property
 * independently regarding the other elements.
 *
 * @version $Id: MessageProcessingContext.java,v 1.4 2004/04/13 09:37:32 luigia Exp $
 */
public class MessageProcessingContext implements Serializable {

    // --------------------------------------------------------------- Constants

    // ------------------------------------------------------------ Private data

    private HashMap property = new HashMap();
    
    // ------------------------------------------------------------ Constructors

    // -------------------------------------------------------------- Properties

    /**
     * Getter for property.
     * @return Value of property.
     */
    public HashMap getProperty() {
        return this.property;
    }

    /**
     * Setter for property.
     * @param property New value of property.
     */
    public void setProperty(HashMap property) {
        this.property = property;
    }

    // ---------------------------------------------------------- Public methods

}