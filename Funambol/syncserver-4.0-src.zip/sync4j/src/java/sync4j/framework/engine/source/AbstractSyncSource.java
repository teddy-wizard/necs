/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine.source;

import java.security.Principal;
import java.sql.Timestamp;

import sync4j.framework.engine.*;
import sync4j.framework.engine.source.SyncSource;

/**
 * Implements the basic functionalities of a <i>SyncSource</i> like naming.
 *
 * @author  Stefano Fornari @ Funambol
 *
 * @version $Id: AbstractSyncSource.java,v 1.16 2004/04/13 09:37:32 luigia Exp $
 */
public abstract class AbstractSyncSource implements SyncSource, java.io.Serializable {
    // --------------------------------------------------------------- Constants

    public static final String LOG_NAME = "source";

    // ---------------------------------------------------------- Protected data

    protected String name       = null;
    protected String type       = null;
    protected String sourceURI  = null;
    protected SyncSourceInfo info      = null;

    // ------------------------------------------------------------ Constructors

    /** Creates a new instance of AbstractSyncSource */
    protected AbstractSyncSource() {
    }

    public AbstractSyncSource(String name, String type, String sourceURI) {
        if (name == null) {
            throw new NullPointerException("name is null!");
        }

        this.name      = name;
        this.type      = (type == null) ? "unknown" : type;
        this.sourceURI = sourceURI;
    }

    public AbstractSyncSource(String name) {
        this(name, null, null);
    }

    // ---------------------------------------------------------- Public methods

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    /** Getter for property uri.
     * @return Value of property uri.
     */
    public String getSourceURI() {
        return sourceURI;
    }

    /** Setter for property uri.
     * @param sourceURI New value of property uri.
     */
    public void setSourceURI(String sourceURI) {
        this.sourceURI = sourceURI;
    }

    /** Returns the type info of the content handled by this source
     *
     * @return the type info of the content handled by this source
     *
     */
    public SyncSourceInfo getInfo() {
        return this.info;
    }
    
    /**
     * Setter for the property <i>info</i>
     */
    public void setInfo(SyncSourceInfo info) {
        this.info = info;
    }

    /**
     * Returns a string representation of this object.
     *
     * @return a string representation of this object.
     */
    public String toString() {
        StringBuffer sb = new StringBuffer(super.toString());

        sb.append(" - {name: ").append(getName()     );
        sb.append(" type: "   ).append(getType()     );
        sb.append(" uri: "    ).append(getSourceURI());
        sb.append("}"         );

        return sb.toString();
    }

    public void beginSync(Principal principal, int syncMode) throws SyncSourceException {
    }
    
    public void endSync(Principal principal) throws SyncSourceException {
    }

    // -------------------------------------------------------- Abstract methods

    public abstract SyncItem[] getAllSyncItems(Principal principal) throws SyncSourceException;

    public abstract SyncItemKey[] getDeletedSyncItemKeys(Principal principal,
                                                         Timestamp since    ) throws SyncSourceException;

    public abstract SyncItem[] getDeletedSyncItems(Principal principal,
                                                   Timestamp since    ) throws SyncSourceException;

    public abstract SyncItemKey[] getNewSyncItemKeys(Principal principal,
                                                     Timestamp since    ) throws SyncSourceException;

    public abstract SyncItem[] getNewSyncItems(Principal principal,
                                               Timestamp since    ) throws SyncSourceException;

    public abstract SyncItem getSyncItemFromId(Principal principal, SyncItemKey syncItemKey) throws SyncSourceException;
    
    public abstract SyncItem[] getSyncItemsFromIds(Principal principal, SyncItemKey[] syncItemKeys) throws SyncSourceException;

    public abstract SyncItem[] getUpdatedSyncItems(Principal principal,
                                                   Timestamp since    ) throws SyncSourceException;

    public abstract void removeSyncItem(Principal principal, SyncItem syncItem) throws SyncSourceException;

    public abstract void removeSyncItems(Principal principal, SyncItem[] syncItems) throws SyncSourceException;

    public abstract SyncItem setSyncItem(Principal principal, SyncItem syncInstance) throws SyncSourceException;

    public abstract SyncItem[] setSyncItems(Principal principal, SyncItem[] syncItems) throws SyncSourceException;
    
    public abstract SyncItem getSyncItemFromTwin(Principal principal, SyncItem syncItem) throws SyncSourceException;
    
    public abstract SyncItem[] getSyncItemsFromTwins(Principal principal, SyncItem[] syncItems) throws SyncSourceException;
}