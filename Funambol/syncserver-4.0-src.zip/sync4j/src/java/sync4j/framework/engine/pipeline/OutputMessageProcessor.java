/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine.pipeline;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.core.SyncML;

/**
 * A <i>OutputMessageProcessor<i> is a class that process the output message.
 *
 * @version $Id: OutputMessageProcessor.java,v 1.5 2004/04/13 09:37:32 luigia Exp $
 */
public interface OutputMessageProcessor {

    // ---------------------------------------------------------- Public methods

    /** 
     * Process and manipulate the output message.
     *
     * @param processingContext the message processing context
     * @param message the message to be processed
     * @throws Sync4jException
     */    
    public void postProcessMessage(MessageProcessingContext processingContext, SyncML message) throws Sync4jException;

}