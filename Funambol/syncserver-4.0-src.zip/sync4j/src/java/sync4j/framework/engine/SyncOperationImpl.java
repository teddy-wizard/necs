/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.engine;

import java.security.Principal;

import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncOperation;

import org.apache.commons.lang.builder.ToStringBuilder;


/**
 * This class is a concrete implementation of <i>SyncOperation</i>
 * <p>
 * The property <i>operation</i> contains the type of the operation to perform
 * and the not null syncItemX selects on what source the operation has to be
 * applied.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SyncOperationImpl.java,v 1.5 2004/04/13 09:37:32 luigia Exp $
 */
public class SyncOperationImpl implements SyncOperation {
    
    // -------------------------------------------------------------- Properties
    
    private SyncItem syncItemA = null;
    public SyncItem getSyncItemA() {
        return this.syncItemA;
    }
    
    public void setSyncItemA(SyncItem syncItemA) {
        this.syncItemA = syncItemA;
    }
    
    private SyncItem syncItemB = null;
    public SyncItem getSyncItemB() {
        return this.syncItemB;
    }
    
    public void setSyncItemB(SyncItem syncItemB) {
        this.syncItemB = syncItemB;
    }
    
    private char operation = 0;
    public char getOperation() {
        return this.operation;
    }
    
    private Principal owner = null;
    
    /** The principal that requested this operation.
     *
     * @return the principal that requested this operation. It may be null.
     *
     */
    public Principal getOwner() {
        return this.owner;
    }
    
    /**
     * Set the owner of this operation
     */
    public void setOwner(Principal owner) {
        this.owner = owner;
    }
    
    private boolean aOperation = false;
    
    /** Getter for property aOperation.
     * @return Value of property aOperation.
     *
     */
    public boolean isAOperation() {
        return aOperation;
    }
    
    /** Setter for property aOperation.
     * @param aOperation New value of property aOperation.
     *
     */
    public void setAOperation(boolean aOperation) {
        this.aOperation = aOperation;
    }
    
    private boolean bOperation = false;
    
    /** Getter for property bOperation.
     * @return Value of property bOperation.
     *
     */
    public boolean isBOperation() {
        return bOperation;
    }
    
    /** Setter for property bOperation.
     * @param bOperation New value of property aOperation.
     *
     */
    public void setBOperation(boolean bOperation) {
        this.bOperation = bOperation;
    }
        
    // ------------------------------------------------------------ Constructors
    
    public SyncOperationImpl() {
    }
    
    /**
     * Create a new SyncOperationImpl
     *
     * @param syncItemA the A item
     * @param syncItemB the B item
     * @param operation the operation
     * @param aOperation is an operation to be performed on source A?
     * @param bOperation is an operation to be performed on source B?
     */
    public SyncOperationImpl(Principal owner     , 
                             SyncItem  syncItemA , 
                             SyncItem  syncItemB , 
                             char      operation ,
                             boolean   aOperation,
                             boolean   bOperation) {
        this.owner      = owner    ;
        this.syncItemA  = syncItemA;
        this.syncItemB  = syncItemB;
        this.operation  = operation;
        this.aOperation = aOperation;
        this.bOperation = bOperation;
    }

    public SyncOperationImpl(SyncItem syncItemA, 
                             SyncItem syncItemB, 
                             char     operation) {
        //
        // owner can be set later...
        //
        this(null, syncItemA, syncItemB, operation, false, false);
    }
    
    // ---------------------------------------------------------- Public methods
    
    public String toString() {
        ToStringBuilder b = new ToStringBuilder(this);

        b.append("A", "" + syncItemA);
        b.append("B", "" + syncItemB);
        String o = "";
        switch (operation) {
            case NEW :     o = "NEW"     ; break;
            case DELETE:   o = "DELETE"  ; break;
            case UPDATE:   o = "UPDATE"  ; break;
            case CONFLICT: o = "CONFLICT"; break;
            case NOP:      o = "NOP"     ; break;
        }
        b.append("operation", o);
        b.append("isAOperation", String.valueOf(aOperation));
        b.append("isBOperation", String.valueOf(bOperation));
        
        return b.toString();
    }        
}