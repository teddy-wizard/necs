/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.engine;

import sync4j.framework.engine.source.SyncSource;
import sync4j.framework.engine.SyncOperation;


/**
 * This class represents the status of the execution of a <i>SyncOperation</i>.
 * A reference to the related operation is stored in <i>operation</i>.
 * Subclasses of <i>SyncOperationStatus</i> represent particular status such as
 * OK or Error.
 *
 * @see sync4j.framework.engine.SyncOperation
 *
 * @author  Stefano Fornari @ Funambol
 */
public interface SyncOperationStatus {
    
    /** 
     * Getter for operation this status relates to
     *
     * @return the operation this status relates to.
     *
     */
    public SyncOperation getOperation();
    
    /**
     * The <i>SyncSource</i> the operation was applied to
     *
     * @return the <i>SyncSource</i> the operation was applied to
     */
    public SyncSource getSyncSource();
    
    /** The operation status code
     * @return the operation status code
     */
    public int getStatusCode();
}