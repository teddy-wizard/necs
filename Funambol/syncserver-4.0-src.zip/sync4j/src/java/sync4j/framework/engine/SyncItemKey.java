/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.engine;

/**
 * This class represents a unique identifier of a <i>SyncItem</i> item in a repository.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SyncItemKey.java,v 1.6 2004/04/13 09:37:32 luigia Exp $
 */
public class SyncItemKey implements java.io.Serializable {
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The key value
     */
    private Object keyValue = null;
    public Object getKeyValue(){
        return keyValue;
    }
    
    /**
     * @param keyValue the key - NOT NULL (assert checked)
     */
    public void setKeyValue(Object keyValue){
        assert (keyValue != null);
        this.keyValue = keyValue; 
    }
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * @param keyValue the key - NOT NULL (assert checked)
     */
    public SyncItemKey(Object keyValue) {
        assert (keyValue != null);
        this.keyValue = keyValue;
    }
    
    // ---------------------------------------------------------- Public Methods
    
    /**
     * @return this key's value as a String object (calling toString() on the
     *         value object)
     */
    public String getKeyAsString() {
        return keyValue.toString();
    }
    
    /**
     * Two keys are equal if their keyValues are equal
     *
     * @param o the object this instance must be compared to.
     *
     * @return the given object is equal to this object
     */
    public boolean equals(Object o) {
        if (!(o instanceof SyncItemKey)) return false;
        
        return ((SyncItemKey)o).getKeyValue().equals(keyValue);
    }
    
    /**
     * @return a string representation for debugging purposes of this <i>SyncItemKey</i>.
     */
    public String toString() {
        StringBuffer sb = new StringBuffer(getClass().getName());
        
        sb.append( " { "            );
        sb.append( " keyValue: "    );
        sb.append( getKeyAsString() );
        sb.append( " } "            );
        
        return sb.toString();
    }
}