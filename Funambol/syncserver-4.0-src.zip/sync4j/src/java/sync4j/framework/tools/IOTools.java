/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.tools;

import java.io.*;

/**
 * Container of utility methods for io access
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: IOTools.java,v 1.4 2004/04/13 09:37:34 luigia Exp $
 */
public class IOTools {
    
    /** 
     * Reads a file into a byte array given its filename
     *
     * @param file the filename (as java.io.File)
     *
     * @return the content of the file as a byte array
     *
     * @throws java.io.IOException;
     */
    static public byte[] readFileBytes(File file) 
    throws IOException {
        FileInputStream fis = null;
        
        byte[] buf = new byte[(int)file.length()];
        try {
            fis = new FileInputStream(file);
            fis.read(buf);
            fis.close();
        } finally {
            if (fis != null) {
                fis.close();
            }
        }
        
        return buf;
    }
        
    
    /** 
     * Reads a file into a byte array given its filename
     *
     * @param filename the filename (as java.lang.String)
     *
     * @return the content of the file as a byte array
     *
     * @throws java.io.IOException;
     */
    static public byte[] readFileBytes(String filename) 
    throws IOException {
        return readFileBytes(new File(filename));
    }
    
    /** 
     * Reads a file into a String given its filename
     *
     * @param file the filename (as java.io.File)
     *
     * @return the content of the file as a string
     *
     * @throws java.io.IOException;
     */
    static public String readFileString(File file) 
    throws IOException {
        return new String(readFileBytes(file));
    }
    
    /** 
     * Reads a file into a String given its filename
     *
     * @param filename the filename (as java.lang.String)
     *
     * @return the content of the file as a string
     *
     * @throws java.io.IOException;
     */
    static public String readFileString(String filename) 
    throws IOException {
        return readFileString(new File(filename));
    }
    
    /**
     * Writes the given string to the file with the given name
     *
     * @param str the string to write
     * @param file the file name as a java.io.File
     *
     * @throws java.io.IOException
     */
    static public void writeFile(String str, File file) 
    throws IOException {
        writeFile(str.getBytes(), file);
    }
    
    /**
     * Writes the given string to the file with the given name
     *
     * @param str the string to write
     * @param filename the file name as a java.lang.String
     *
     * @throws java.io.IOException
     */
    static public void writeFile(String str, String filename) 
    throws IOException {
        writeFile(str.getBytes(), new File(filename));
    }
    
    /**
     * Writes the given bytes to the file with the given name
     *
     * @param buf the bytes to write
     * @param filename the file name as a java.lang.String
     *
     * @throws java.io.IOException
     */
    static public void writeFile(byte[] buf, String filename) 
    throws IOException {
        writeFile(buf, new File(filename));
    }
    
    /**
     * Writes the given bytes to the file with the given name
     *
     * @param buf the bytes to write
     * @param file the file name as a java.io.File
     *
     * @throws java.io.IOException
     */
    static public void writeFile(byte[] buf, File file) 
    throws IOException {
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
            fos.write(buf);
            fos.close();
        } finally {
            if (fos != null) {
                fos.close();
            }
        }
    }
    
    /**
     * Returns a <i>FilenameFilter</i> that accepts only the files of the given
     * type (extension).
     *
     * @param type the type (the file extension) of the files to select. NULL
     *             means all files, the empty string means files without extension
     *             The filtering is case-insensitive
     *
     * @return the filter
     */
    public static FilenameFilter getFileTypeFilter(String type) {
        return new FileTypeFilter(type);
    }
    
    // -------------------------------------------------------------------------
    
    /**
     * This class is a <i>FilenameFilter</i> that accepts only the files of the 
     * specified type (extension). The filtering is case-insensitive,
     */
    public static class FileTypeFilter implements FilenameFilter {
        
        private String type;
        
        /**
         * Creates the filter on the given type. 
         *
         * @param type the type (the file extension) of the files to select. NULL
         *             means all files, the empty string means files without 
         *             extension. The filtering is case-insensitive
         */
        public FileTypeFilter(final String type) {
            this.type = type.toUpperCase();
        }
        
        public boolean accept(File dir, String name) {
            if (type == null) {
                return true;
            }
            
            if (type.length() == 0) {
                return (name.indexOf('.') < 0);
            }
            
            return (name.toUpperCase().endsWith(type));
        }
    }
}