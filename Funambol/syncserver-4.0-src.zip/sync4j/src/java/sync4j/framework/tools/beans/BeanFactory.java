/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.tools.beans;

import java.beans.XMLEncoder;
import java.beans.XMLDecoder;

import java.io.*;

import sync4j.framework.tools.beans.LazyInitBean;
import sync4j.framework.tools.beans.BeanException;
import sync4j.framework.tools.beans.BeanInstantiationException;
import sync4j.framework.tools.beans.BeanInitializationException;



/**
 * This is a JavaBeans factory. At the moment it has a very simple
 * implementation: it loads the class from a serialized file at runtime.
 *
 * @author Stefano Fornari @ Funambol
 * @version $Id: BeanFactory.java,v 1.10 2004/04/13 09:37:34 luigia Exp $
 */
public class BeanFactory {

    protected BeanFactory() { }

    /**
     * Creates an instance of the given bean. The bean is first search as a
     * class. If not found as class, it is searched as a resource. There isn't a
     * lazy initialization.
     *
     * @param       classLoader the class loader to use for loading the bean
     * @param       beanName    name of the bean (for now is also the file name,
     *                          without .ser, into which the bean has been serialized)
     *                          NOT NULL
     *
     * @return      a new instance of the serialized bean
     *
     * @throws      BeanInstantiationException if the bean cannot be istantiated
     */
    public static Object getNoInitBeanInstance(ClassLoader classLoader, String beanName)
           throws BeanInstantiationException, BeanInitializationException {

        if (classLoader == null) {
            classLoader = ClassLoader.getSystemClassLoader();
        }

        Object bean = null;

        //
        // Search beanName as a class
        //
        try {
            bean = Class.forName(beanName, true, classLoader).newInstance();
            if (bean instanceof LazyInitBean) {
                ((LazyInitBean)bean).init();
            }
            return bean;
        }  catch (ClassNotFoundException e) {
            //
            // beanName does not represent a class!
            //
        } catch (BeanInitializationException e) {
            throw e;
        } catch (Exception e) {
            //
            // Other exceptions are not good!
            //
            throw new BeanInstantiationException( "Error instantiating "
                                                + beanName
                                                , e
                                                );
        }
        InputStream is = classLoader.getResourceAsStream(beanName);

        if (is == null) {
            throw new BeanInstantiationException( "Resource "
                                                 + beanName
                                                 + " not found"
                                                 + " with "
                                                 + classLoader
                                                 );
        }

        BeanExceptionListener exceptionListener = new BeanExceptionListener();

        //
        // IMPORTANT NOTE
        // --------------
        // 
        // This serialization is a very important flaw for scalability, but we
        // must do it for a bug in XMLDecoder (see bug #  4822050:
        // http://developer.java.sun.com/developer/bugParade/bugs/4822050.html )
        // 
        synchronized (BeanFactory.class) {
            XMLDecoder d = new XMLDecoder(is, null, exceptionListener);
            bean = d.readObject();
            d.close();
        }

        if (exceptionListener.exceptionThrown()) {
            Throwable t = exceptionListener.getException();
            
            if (t.getCause() != null) {
                t = t.getCause();
            }
            throw new BeanInstantiationException( "Error instantiating "
                                                + beanName
                                                , t
                                                );
        }

        return bean;
    }

    /**
     * Creates an instance of the given bean. The bean is first search as a
     * class. If not found as class, it is searched as a resource.
     *
     * @param       classLoader the class loader to use for loading the bean
     * @param       beanName    name of the bean (for now is also the file name,
     *                          without .ser, into which the bean has been serialized)
     *                          NOT NULL
     *
     * @return      a new instance of the serialized bean
     *
     * @throws      BeanInstantiationException if the bean cannot be istantiated
     */
    public static Object getBeanInstance(ClassLoader classLoader, String beanName)
           throws BeanInstantiationException, BeanInitializationException {

        Object bean = null;

        bean = getNoInitBeanInstance(classLoader, beanName);

        if (bean instanceof LazyInitBean) {
            ((LazyInitBean)bean).init();
        }

        return bean;
    }


    /**
     * Creates an instance of the given bean using the system class loader.
     *
     * @param       beanName    name of the bean (for now is also the file name,
     *                          without .ser, into which the bean has been serialized)
     *
     * @return      a new instance of the serialized bean
     *
     * @throws      BeanInstantiationException if the bean cannot be istantiated
     */
    public static Object getBeanInstance(String beanName)
           throws BeanInstantiationException, BeanInitializationException {
           return getBeanInstance(null, beanName);
    }


    /**
     * Creates an instance of the given bean. This version deserializes the bean
     * from the given file.
     *
     * @param       beanFile    the filename of the serialized file
     *
     * @return      a new instance of the serialized bean
     *
     * @throws      BeanInstantiationException if the bean cannot be istantiated
     */
    public static Object getBeanInstance(File beanFile)
           throws BeanInstantiationException, BeanInitializationException {
        try {
            Object bean = null;

            XMLDecoder e = new XMLDecoder(new FileInputStream(beanFile));
            bean = e.readObject();
            e.close();

            if (bean instanceof LazyInitBean) {
                ((LazyInitBean)bean).init();
            }
            return bean;
        } catch (IOException e) {
            String msg = "Bean creation ("
                       +          beanFile
                       +       ") failed: "
                       +     e.getMessage()
                       ;
            throw new BeanInstantiationException(msg, e);
        } catch (Exception e) {
            String msg = "Bean creation (" + beanFile + ") failed: " + e.getMessage();
            throw new BeanInstantiationException(msg, e);
        }
    }

    /**
     * Serialize the given object in the give file using XMLEncoder.
     *
     * @param obj the object to be serialized
     * @param file the file into wich serialize the object
     *
     * @throws BeanException in case of errors
     */
    public static void saveBeanInstance(Object obj, File file)
    throws BeanException {
        XMLEncoder encoder = null;

        try {
            encoder = new XMLEncoder(new FileOutputStream(file));
            encoder.writeObject(obj);
        } catch (IOException e) {
            String msg = "Bean saving (" + file + ") failed: " + e.getMessage();
            throw new BeanException(msg, e);
        } finally {
            if (encoder != null) {
                encoder.close();
            }
        }
    }

    /**
     * Creates a bean instance given the class name and serialize it in the
     * specified file. The object is serialized in XML.
     * <p>
     * Syntax:<br>
     * sync4j.framework.tools.beans.BeanFactory <i>class name</i> </i>file name</i>
     **/
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Syntax: sync4j.framework.tools.beans.BeanFactory <class name> <file name>");
            return;
        }

        saveBeanInstance(getBeanInstance(args[0]), new File(args[1]));
    }
}