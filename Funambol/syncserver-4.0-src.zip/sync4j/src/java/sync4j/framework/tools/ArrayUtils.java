/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.tools;

import java.lang.reflect.Array;


/**
 * Collection of tools for the server
 *
 * @author  Stefano Fornari
 */
public class ArrayUtils {
    
    /**
     * Merges the two given arrays in a single array, putting the elements of 
     * the former array first and the elements of the latter array. The returned 
     * array will be of the type specified by <i>elementClass</i>
     *
     * @param a the former array - NULL
     * @param b the latter array - NULL
     * @param elementType the class of the elements
     *
     * @return an array containing the elements of <i>a</i> and <i>b</i>
     */
    public static Object mergeArrays(Object[] a, Object[] b, Class elementType) {
        
        int size = 0;
        
        if (a != null) size += a.length;
        if (b != null) size += b.length;

        Object newArray = Array.newInstance(elementType, size);
        
        int newArrayPos = 0;
        if (a != null) {
            System.arraycopy(a, 0, newArray, newArrayPos, a.length);
            newArrayPos = a.length;
        }
         
        if (b != null) {
            System.arraycopy(b, 0, newArray, newArrayPos, b.length);
        }
        
        return newArray;

    }
    
}