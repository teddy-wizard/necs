/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.transport.http;

import javax.servlet.http.*;

import sync4j.framework.server.SyncResponse;
import sync4j.framework.core.Sync4jException;
import sync4j.framework.server.error.ServerException;
import sync4j.framework.server.error.NotImplementedException;
import sync4j.framework.protocol.ProtocolException;


/**
 * This is an interface of sync holder. A sync holder hides the implementation 
 * of the real service provider. Thus the provider can be developed as a local
 * EJB, a remote EJB or a simple local object.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: SyncHolder.java,v 1.6 2004/04/13 09:37:34 luigia Exp $
 */
public interface SyncHolder {
    // --------------------------------------------------------------- Constants
    
    // ---------------------------------------------------------- Public methods
    
    public void setSessionId(String sessionId) throws Sync4jException;
    
    public String getSessionId();
    
    /**
     * Processes an incoming message.
     *
     * @param requestData the SyncML request as stream of bytes
     * @param contentType the content type associated with the request
     *
     * @return the SyncML response as a <i>ISyncResponse</i> object
     */
    public SyncResponse processMessage(byte[] requestData, String contentType)
    throws NotImplementedException, ProtocolException, ServerException;
    
    /**
     * Called when the SyncHolder is not required any more. It gives the holder
     * an opportunity to do clean up and releaseing of resources.
     *
     * @throws java.lang.Exception in case of error. The real exception is stored
     * in the cause.
     */
    public void close() throws Exception;
    
    /**
     * Returns the creation timestamp (in milliseconds since midnight, January 
     * 1, 1970 UTC).
     */
    public long getCreationTimestamp();
}