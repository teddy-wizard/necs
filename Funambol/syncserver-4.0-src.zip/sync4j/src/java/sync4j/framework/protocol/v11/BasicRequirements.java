/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol.v11;

import sync4j.framework.core.*;

import sync4j.framework.protocol.ProtocolException;

/**
 *
 * @author  Stefano Fornari @ Funambol
 *
 * @version $Id: BasicRequirements.java,v 1.7 2004/04/13 09:37:33 luigia Exp $
 */
public class BasicRequirements
implements Errors {
    // ---------------------------------------------------- Contraint values

    public static final VerDTD[]      SUPPORTED_DTD_VERSIONS     
        = new VerDTD[] { Constants.DTD_1_0, Constants.DTD_1_1 };
    public static final VerProto[] SUPPORTED_PROTOCOL_VERSIONS
        = new VerProto[] { Constants.PROT_1_0, Constants.PROT_1_1, Constants.PROT_1_1_1 };
        
    public static final String CAPABILITIES_SOURCE = "./devinf11";
    public static final String CAPABILITIES_TARGET = "./devinf11";
    public static final String SERVER_CAPABILITIES = "server";
    public static final String CLIENT_CAPABILITIES = "client";

    //----------------------------------------------------------- Public methods

    static public void checkDTDVersion(VerDTD version) 
    throws ProtocolException {
        for (int i=0; i<SUPPORTED_DTD_VERSIONS.length; ++i) {
            if (SUPPORTED_DTD_VERSIONS[i].equals(version)) {
                return;  // OK!
            }
        }

        // KO!

            String[] args = new String[] { version.toString() };

            throw new ProtocolException(ERRMSG_DTD_VER_NOT_SUPPORTED, args);
        }

    static public void checkProtocolVersion(VerProto version)
    throws ProtocolException {
        for (int i=0; i<SUPPORTED_PROTOCOL_VERSIONS.length; ++i) {
            if (SUPPORTED_PROTOCOL_VERSIONS[i].equals(version)) {
                return;  // OK!
            }
        }
        
            String[] args = new String[] { version.toString() };

            throw new ProtocolException(ERRMSG_PROTOCOL_VER_NOT_SUPPORTED, args);
    }

    static public void checkSessionId(SessionID id)
    throws ProtocolException {
        if ((id == null) || (id.toString().trim().length() == 0)) {
            throw new ProtocolException(ERRMSG_NO_SESSION_ID);
        }
    }

    static public void checkMessageId(String id)
    throws ProtocolException
    {
        if ((id == null) || (id.trim().length() == 0)) {
            throw new ProtocolException(ERRMSG_NO_MESSAGE_ID);
        }
    }

    /**
     * A target is valid if it is not null and one of <i>location name</i> or
     * <i>URI</i> is specified.
     *
     * @param target the target to be checked - NULL
     *
     * @throws ProtocolException
     */
    static public void checkTarget(Target target) throws ProtocolException {
        boolean valid    = target != null;
        boolean location = false;
        boolean uri      = false;

        if (valid) {
            location = (  (target.getLocName() != null)
                       && (target.getLocName().trim().length() != 0) );
            uri = (target.getLocURI() != null);

            valid = location || uri;
        }

        if (!valid) {            
            String[] args = { ((target == null) ? "null" : target.getLocURI()) };
            throw new ProtocolException(ERRMSG_INVALID_TARGET, args);
        }
    }

    /**
     * A source is valid if it is not null and one of <i>location name</i> or
     * <i>URI</i> is specified.
     *
     * @param source the source to be checked - NULL
     *
     * @throws ProtocolException
     */
    static public void checkSource(Source source) throws ProtocolException {
        boolean valid    = source != null;
        boolean location = false;
        boolean uri      = false;

        if (valid) {
            location = (  (source.getLocName() != null)
                       && (source.getLocName().trim().length() != 0) );
            uri = (source.getLocURI() != null);

            valid = location || uri;
        }

        if (!valid) {
            String[] args = { ((source == null) ? "null" : source.getLocURI()) };
            throw new ProtocolException(ERRMSG_INVALID_SOURCE, args);
        }
    }

    static public void checkCommandId(CmdID commandId)
    throws ProtocolException
    {
        String cmdValue = null;

        if (  ( commandId == null                       )
           || ((cmdValue = commandId.getCmdID()) == null)
           || ( cmdValue.trim().length() == 0)          ) {
            throw new ProtocolException(ERRMSG_NO_MESSAGE_ID);
        }
    }

    static public void checkAlertCommand(Alert alert) throws ProtocolException {
        //
        // Check the command id
        //
        String[] args = new String[] {"alert is null!"};

        if (alert == null) {
            throw new ProtocolException(ERRMSG_INVALID_ALERT, args);
        }

        try {
            checkCommandId(alert.getCmdID());
        } catch (ProtocolException e) {
            args = new String[] { e.getMessage() };
            throw new ProtocolException(ERRMSG_INVALID_ALERT, args);
        }
    }

    /**
     * Checks if the given command contains valid device information.
     *
     * @param cmd the command containing data
     * @param device specifies if the command should contain client or server
     *        capabilities
     *
     * @throws ProtocolException
     */
    static public void checkCapabilities(ItemizedCommand cmd, String device)
    throws ProtocolException {
        //
        // Checks command id
        //
        try {
            checkCommandId(cmd.getCmdID());
        } catch (ProtocolException e) {
            String[] args = new String[] { device, e.getMessage() };
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }

        //
        // Checks the <Type> tag in metadata
        //
        Meta meta = cmd.getMeta();
        if (meta == null) {
            Object[] args = new Object[] { device, "missing metadata" };
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }
        
        if (meta.getType() == null) {
            Object[] args = new Object[] { device, "invalid metadata type" };
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }

        //
        // NOTE: the validation of the metadata should be done at XML level
        //       (see http://www.syncml.org/docs/syncml_protocol_v101_20010615.pdf)
        //

        //
        // Checks source
        //
        Item[] items = (Item[])cmd.getItems().toArray(new Item[0]);

        if ((items == null) || (items.length ==0)) {
            String[] args = new String[] { device, ERRMSG_MISSING_ITEM};
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }

        try {
            checkSource(items[0].getSource());
        } catch (ProtocolException e) {
            String[] args = new String[] { device, "missing source" };
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }

        if (!CAPABILITIES_SOURCE.equals(items[0].getSource().getLocURI().toString())) {
            String[] args = new String[] { device, "URI not " + CAPABILITIES_SOURCE};
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }

    }
}