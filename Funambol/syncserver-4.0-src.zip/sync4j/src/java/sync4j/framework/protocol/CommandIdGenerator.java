/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol;

import sync4j.framework.protocol.IdGenerator;
import sync4j.framework.protocol.SimpleIdGenerator;
import sync4j.framework.core.CmdID;

/**
 * This class creates command ids. Note that when a new CommandIdentifier is
 * created, it is stored also in <i>currentId</i>, which is returned by
 * <i>current()</i>. This is to avoid that <i>current()</i> creates a new
 * CommandIdentifier object each time is called.
 * <p>
 * This class is thread-safe.
 *
 * @author  Stefano Fornari @ funambol
 */
public class CommandIdGenerator
        implements java.io.Serializable {

  // ---------------------------------------------------------- Private fields

  /**
   * The underlying IdGenerator object
   */
  private IdGenerator idGenerator = null;

  /**
   * The current identifier
   */
  private CmdID currentId = null;

  // ------------------------------------------------------------ Constructors

  /** Creates a new instance of CommandIdGenerator */
  public CommandIdGenerator() {
    this(new SimpleIdGenerator());

  }

  /**
   * Creates a new instance of CommandIdGenerator given an IdGenerator
   *
   * @param idGenerator the idGenerator object - NOT NULL
   */
  public CommandIdGenerator(IdGenerator idGenerator) {
    if (idGenerator == null) {
      throw new NullPointerException("idGenerator cannot be null!");
    }
    this.idGenerator = idGenerator;
  }

  // ---------------------------------------------------------- Public methods

  /**
   * Returns a new generated command id.
   *
   * @return a new generated command id.
   */
  public synchronized CmdID next() {
    return (currentId = new CmdID(idGenerator.next()));
  }

  /**
   * Reset the Id counter
   */
  public synchronized void reset() {
    idGenerator.reset();
  }

  /**
   * Returns the last generated command id (which is the current command id).
   *
   * @return the last generated command id
   */
  public synchronized CmdID current() {
    return currentId;
  }
}