/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol.v11;

/**
 *
 * @author  Stefano Fornari @ Funambol
 */
public interface Errors {
    public static final String ERRMSG_DTD_VER_NOT_SUPPORTED        =
       "DTD ver {0} not supported"
    ;
    public static final String ERRMSG_PROTOCOL_VER_NOT_SUPPORTED   =
       "Protocol ver {0} not supported"
    ;
    public static final String ERRMSG_NO_SESSION_ID                =
       "Missing session ID"
    ;
    public static final String ERRMSG_NO_MESSAGE_ID                =
       "Missing message ID"
    ;
    public static final String ERRMSG_INVALID_TARGET               =
       "Invalid target ({0})"
    ;
    public static final String ERRMSG_INVALID_SOURCE               =
       "Invalid source({0})"
    ;
    public static final String ERRMSG_INVALID_ALERT                =
       "Invalid alert command ({0})"
    ;
    public static final String ERRMSG_INVALID_ALERT_CODE           =
       "The alert code {0} is not an initialization code"
    ;
    public static final String ERRMSG_MISSING_ITEM                 =
       "The item element is missing"
    ;
    public static final String ERRMSG_MISSING_SYNC_ANCHOR          =
       "The sync anchor element is missing"
    ;
    public static final String ERRMSG_INVALID_CAPABILITIES         =
       "Invalid {0} capabilities ({1})"
    ;
    public static final String ERRMSG_INVALID_CAPABILITIES_REQUEST =
       "Invalid capabilities request ({1})"
    ;
    public static final String ERRMSG_BODY_NOT_FINAL               =
       "The body packet is not marked 'final'"
    ;
    public static final String ERRMSG_MISSING_STATUS_COMMAND       =
       "Missing status command for command {1}"
    ;
    public static final String ERRMSG_MISSING_RESULTS_COMMAND      =
       "Missing results command for command {1}"
    ;
    public static final String ERRMSG_MISSING_SYNC_COMMAND         =
       "Missing sync command for command"
    ;
    public static final String ERRMSG_INVALID_SYNC_COMMAND         =
       "Invalid sync command ({1})"
    ;
    public static final String ERRMSG_INVALID_MODIFICATION_COMMAND =
       "Invalid modification command ({1})"
    ;
    public static final String ERRMSG_MISSING_TYPE                 =
       "Missing metadata type in {1}"
    ;
    public static final String ERRMSG_MISSING_DATA                 =
       "Missing data in {1}"
    ;
}