/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.protocol;

import sync4j.framework.core.*;
import sync4j.framework.protocol.v11.CompletionRequirements;
import sync4j.framework.protocol.ProtocolUtil;
import sync4j.framework.logging.Sync4jLogger;

import java.util.List;
import java.util.ArrayList;
import java.util.logging.Logger;

/**
 * ClientCompletion class represent the phase or state that come after
 * Modification phase. In this state client send status for the sync command,
 * a status for every sub sync command like Add, Replace and finally send a
 * MapCommand in the case a AddCommand was done succesfully.
 * We need to extract this mapping information to update the LUID GUID Mapping.
 * see the SyncML sync protocol for a detailed example
 *
 *@author Richard Wafer
 *@version $Id: ClientCompletion.java,v 1.12 2004/04/13 09:37:32 luigia Exp $
 */
public class ClientCompletion extends SyncPackage {
    
    /**
     * Sync4j Logging facility
     */
    private transient Logger mLog = Sync4jLogger.getLogger();
    
    /**
     * Cache the commands sent by the client. It is set during the
     * check for the requirements.
     */
    private AbstractCommand[] clientCommands = null;
    
    /**
     * Get all the commands extracted from the client last message.
     * @return An array of AbstractCommand
     */
    public AbstractCommand[] getClientCommands() {
        return clientCommands;
    }
    
    /**
     * The Map Command from the client. It's used to construct the
     * response back to client.
     */
    private Map[] mapCommands = null;
    
    /**
     * Get the Map command
     */
    public Map[] getMapCommands() {
        return mapCommands;
    }
    
    /**
     * true if Map Command where find
     */
    private boolean mapCommandFind = false;
    
    /**
     * @return true if a map Command were find
     */
    public boolean isMapCommandFind() {
        return mapCommandFind;
    }
    
    /**
     * The last message from client Identifier.
     */
    private String lastMessageId = null;
    
    /**
     * Contruct a ClientCompletion State processing treatment
     * @param syncHeader The header of the client message
     * @param syncBody The body of the client message
     * @throws Sync4jException
     */
    public ClientCompletion(final SyncHdr syncHeader, final SyncBody syncBody)
    throws Sync4jException {
        super(syncHeader, syncBody);
        checkHeaderRequirements();
        checkBodyRequirements();
    }
    
    /**
     * Checks that all requirements regarding the header of the initialization
     * packet are respected.
     *
     * @throws ProtocolException
     */
    public void checkHeaderRequirements() throws ProtocolException {
        CompletionRequirements.checkDTDVersion(syncHeader.getVerDTD());
        CompletionRequirements.checkProtocolVersion(syncHeader.getVerProto());
        CompletionRequirements.checkSessionId(syncHeader.getSessionID());
        CompletionRequirements.checkMessageId(syncHeader.getMsgID());
        CompletionRequirements.checkTarget(syncHeader.getTarget());
        CompletionRequirements.checkSource(syncHeader.getSource());
        
        //Conserve the message ID from the client message header.
        lastMessageId = syncHeader.getMsgID();
    }
    
    /**
     * Checks that all requirements regarding the body of the initialization
     * packet are respected.
     *
     * @throws ProtocolException
     */
    public void checkBodyRequirements() throws ProtocolException {
        clientCommands = (AbstractCommand[])syncBody.getCommands().toArray(new AbstractCommand[0]);
        
        // Check the status command if add ak then check for map command
        checkStatusCommands();
        
        //If status for AddCommand was find
        checkMapCommand();
    }
    
    /**
     * Check the status commands from the client to check failure and to check
     * wether or not a status from a Add Command Exist. In this case true is
     * return to toggle the Map existence.
     * todo : check the failure
     */
    private void checkStatusCommands() {
    }
    
    /**
     * Check The Map Command for new mapped items.
     * @throws ProtocolException
     */
    private void checkMapCommand() throws ProtocolException {
        List list = ProtocolUtil.filterCommands(clientCommands,
        Map.class
        );

        if (list.size() > 0) {
            mapCommands = (Map[]) list.toArray(new Map[list.size()]);
            mapCommandFind = true;
        } else {
            mapCommands = null;
            mapCommandFind = false;
        }
    }
    
    /**
     * Constructs a proper response message. That include from the syncMl spec
     * <br>
     *  <ui>
     *    <li>Status for last message syncheader</li>
     *    <li>May include Status for the mapping command</li>
     *  <ui>
     * @return the response message
     * @throws ProtocolException in case of error or inconsistency
     */
    public SyncML getResponse() throws ProtocolException {
        ArrayList commands = new ArrayList();
        
        /*
        1. Requirements for the elements within the SyncHdr element.
            - The value of the VerDTD element MUST be '1.1'.
            - The value of the VerProto element MUST be 'SyncML/1.1'.
            - Session ID MUST be included to indicate the ID of a sync session.
            - MsgID MUST be used to unambiguously identify the message belonging a sync session
              and traveling from the client to the server.
            - The Target element MUST be used to identify the target device and service.
            - The Source element MUST be used to identify the source device.
            - The response MUST NOT be required for this message.
        */
        Target target = new Target(syncHeader.getSource().getLocURI(),
            syncHeader.getSource().getLocName());
            Source source = new Source(syncHeader.getTarget().getLocURI(),
            syncHeader.getTarget().getLocName());
            SyncHdr responseHeader = new SyncHdr(
                getDTDVersion()                      ,
                getProtocolVersion()                 ,
            syncHeader.getSessionID()       ,
            syncHeader.getMsgID()           ,
            target,
            source,
            null  /* response URI */,
                true /* Response not required */     ,
            null /* credentials */,
            null /* meta date */
        );
        
        /*
        2. The Status element(s) MUST be included in SyncBody. It is now used to indicate the status of
          the Map operation(s). This or these can be sent before Package #5 is completely received.
        */
        //
        // Create the synhdr status response
        //
        TargetRef[] targetRefs = new TargetRef[] { new TargetRef(syncHeader.getTarget().getLocURI()) };
        SourceRef[] sourceRefs = new SourceRef[] { new SourceRef(syncHeader.getSource().getLocURI()) };
        Status synchdrStatus = new Status(
            idGenerator.next(),
            lastMessageId,
            "0",
            "SyncHdr",
            targetRefs,
            sourceRefs,
            null,
            null,
            new Data(StatusCode.OK),
            new Item[0]
        );
        commands.add(synchdrStatus);
        
        //
        //Create the map commands status response
        //
        if (mapCommandFind) {
            //Contruct the status command for the Map command
            
            Status mapStatus = null;
            for (int i=0; i<mapCommands.length; ++i) {
                
                targetRefs = new TargetRef[] { new TargetRef(mapCommands[i].getTarget()) };
                sourceRefs = new SourceRef[] { new SourceRef(mapCommands[i].getSource()) };

                mapStatus = new Status(
                    idGenerator.next(),
                    lastMessageId,
                    mapCommands[i].getCmdID().getCmdID(),
                    Map.COMMAND_NAME,
                    targetRefs,
                    sourceRefs,
                    null,
                    null,
                    new Data(StatusCode.OK),
                    new Item[0]
                );
                commands.add(mapStatus);
            }
        }
        
        /*
        3. The Final element MUST be used for the message, which is the last in this package.
        */
        SyncBody responseBody = new SyncBody(
            (AbstractCommand[]) commands.toArray(new AbstractCommand[0]),
            isFlag(Flags.FLAG_FINAL_MESSAGE)
        );
        
        try {
            return new SyncML(responseHeader, responseBody);
        } catch (RepresentationException e) {
            //
            // It should never happen !!!!
            //
            throw new ProtocolException("Unexpected error", e);
        }
    }
}