/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol.v11;

import sync4j.framework.core.*;

import sync4j.framework.protocol.ProtocolException;
import sync4j.framework.protocol.v11.BasicRequirements;
import sync4j.framework.protocol.v11.Errors;

/**
 * This class groups utility methods used for checking that an initialization
 * massage follows the requirements that the protocol mandates.
 *
 * @author  Stefano Fornari @ Funambol
 * 
 * @version $Id: InitializationRequirements.java,v 1.4 2004/04/13 09:37:33 luigia Exp $
 */
public class InitializationRequirements 
extends BasicRequirements
implements Errors {
    
    // --------------------------------------------------------------- Constants

    // ---------------------------------------------------------- Public methods
    
    static public void checkAlertCommand(Alert alert) throws ProtocolException {
        try {
            BasicRequirements.checkAlertCommand(alert);
        } catch (ProtocolException e) {
            String[] args = new String[] { e.getMessage() };
            throw new ProtocolException(ERRMSG_INVALID_ALERT, args);
        }

        //
        // Checks the alert code
        //
        if (!AlertCode.isInitializationCode(alert.getData())) {
            String[] args = new String[] { String.valueOf(alert.getData()) };
            throw new ProtocolException(ERRMSG_INVALID_ALERT_CODE, args);
        }

        //
        // Checks source and target
        //
        Item[] items = (Item[])alert.getItems().toArray(new Item[0]);

        if ((items == null) || (items.length ==0)) {
            throw new ProtocolException(ERRMSG_MISSING_ITEM);
        }

        try {
            checkSource(items[0].getSource());
        } catch (ProtocolException e) {
            String[] args = new String[] { "source" };
            throw new ProtocolException(ERRMSG_INVALID_ALERT, args);
        }

        try {
            checkTarget(items[0].getTarget());
        } catch (ProtocolException e) {
            String[] args = new String[] { "target" };
            throw new ProtocolException(ERRMSG_INVALID_ALERT, args);
        }

        //
        // Checks sync anchors
        //
        Meta meta = items[0].getMeta();
       
        if (meta == null || meta.getAnchor() == null) {
           throw new ProtocolException(ERRMSG_MISSING_SYNC_ANCHOR);
        }
    }
    
    /**
     * Checks if the given command contains a valid request for server capablities.
     *
     * @param cmd the command containing the request
     *
     * @throws ProtocolException
     */
    static public void checkCapabilitiesRequest(Get cmd) 
    throws ProtocolException {
        //
        // Checks command id
        //
        try {
            checkCommandId(cmd.getCmdID());
        } catch (ProtocolException e) {
            String[] args = new String[] { e.getMessage() };
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES, args);
        }
        
        Item[] items = (Item[])cmd.getItems().toArray(new Item[0]);

        if ((items == null) || (items.length ==0)) {
            String[] args = new String[] {ERRMSG_MISSING_ITEM};
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES_REQUEST, args);
        }

        try {
            checkTarget(items[0].getTarget());
        } catch (ProtocolException e) {
            String[] args = new String[] { "missing target" };
            throw new ProtocolException(ERRMSG_INVALID_CAPABILITIES_REQUEST, args);
        }
    }
}