/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol;

import sync4j.framework.protocol.IdGenerator;

/**
 * This class works as a simple id generator that after being initialized with a
 * numeric value, increments the counter each time the next method is called.
 * <p>
 * SimpleIdGenerator is thread-safe
 *
 * @author  Stefano Fornari @ funambol
 */
public final class SimpleIdGenerator
        implements IdGenerator, java.io.Serializable {

  // -------------------------------------------------------------- Properties

  /**
   * The counter
   */
  private long counter = 0;

  public long getCounter()
  {
    return counter;
  }

  /**
   * Standard setter method
   */
  public void setCounter(long counter)
  {
    this.counter = counter;
  }

  /**
   * The units the counter must be incremented each time next is called
   */
  private int increment = 1;

  public int getIncrement()
  {
    return increment;
  }

  /**
   * Standard setter method
   */
  public void setIncrement(int increment)
  {
    this.increment = increment;
  }

  // ------------------------------------------------------------ Constructors

  /**
   * Creates a new instance of SimpleIdGenerator
   *
   * @param counter the starting value
   * @param increment the increment
   */
  public SimpleIdGenerator(long counter, int increment)
  {
    this.counter = counter;
    this.increment = increment;
  }

  /**
   * Like this(counter,1)
   *
   * @param counter the starting value
   */
  public SimpleIdGenerator(int counter)
  {
    this(counter, 1);
  }

  /**
   * Reset the generator to 0.
   */
  public void reset()
  {
    this.counter = 0;
  }

  /**
   * Like this(0,1)
   */
  public SimpleIdGenerator()
  {
    this(0, 1);
  }

  /**
   * Returns the next value of the counter (incrementing the counter by the
   * increment)
   *
   * @return the next generated value
   */
  public synchronized String next()
  {
    counter += increment;

    return String.valueOf(counter);
  }

  /**
   * Returns the last generated id (which is the current id).
   *
   * @return the last generated id
   */
  public synchronized String current()
  {
    return String.valueOf(counter);
  }
}