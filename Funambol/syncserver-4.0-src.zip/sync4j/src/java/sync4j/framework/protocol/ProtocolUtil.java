/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol;

import java.util.ArrayList;

import sync4j.framework.core.*;
import sync4j.framework.database.Database;
import sync4j.framework.protocol.v11.*;

/**
 *
 * @author  Stefano Fornari @ Funambol
 *
 * @version $Id: ProtocolUtil.java,v 1.7 2004/04/13 09:37:32 luigia Exp $
 *
 */
public class ProtocolUtil {

    /** Filters the given commands based on the given class
     *
     * @param commands commands to be filtered
     * @param filterClass selector
     *
     * @return a java.util.List containing the selected commands
     *
     */
    public static ArrayList filterCommands(AbstractCommand[] commands, Class filterClass) {
        ArrayList filteredCommands = new ArrayList();

        for (int i=0; i<commands.length; ++i) {
            if (filterClass.isInstance(commands[i])) {
                filteredCommands.add(commands[i]);
            }
        }

        return filteredCommands;
    }

    /**
     * Filters the given commands based on the given command id. A command is
     * selected if it a ResponseCommand (only ResponseCommand subclasses have
     * got the reference command id) and its command id ref matches <i>cmdId</i>.
     *
     * @param commands commands to be filtered
     * @param cmdId selector
     *
     * @return a java.util.List containing the selected commands
     *
     */
    public static ArrayList filterCommands(AbstractCommand[] commands,
                                           CmdID cmdId               ) {
        ArrayList filteredCommands = new ArrayList();

        for (int i=0; i<commands.length; ++i) {
            if (  (commands[i] instanceof ResponseCommand)
               && ((((ResponseCommand)commands[1]).getCmdID()).equals(cmdId))) {
                filteredCommands.add(commands[i]);
            }
        }

        return filteredCommands;
    }

    /**
     * Filters the given commands based on the given command type and command id.
     * It combines <i>filterCommands(commands, filterClass)</i> and
     * <i>filterCommands(commands, cmdId)</i> returning only the commands
     * that respect both requirements.
     *
     * @param commands commands to be filtered
     * @param filterClass class type selector
     * @param cmdId selector
     *
     * @return a java.util.List containing the selected commands
     *
     */
    public static ArrayList filterCommands(AbstractCommand[] commands   ,
                                           Class             filterClass,
                                           CmdID cmdId                  ) {
        //
        // Since filtering on command identifier seems more selective,
        // filterCommands(commands, cmdId) is called first and than
        // filterCommands(..., filterClass) is called with the returned values.
        //
        ArrayList list = filterCommands(commands, cmdId);
        int size = list.size();
        AbstractCommand [] aCommands = new AbstractCommand[size];
        for (int i=0; i < size; i++) {
            aCommands[i] = (AbstractCommand)list.get(i);
        }
        return filterCommands(
                    /* not compatible with j2me
                    (AbstractCommand[])list.toArray(new AbstractCommand[0]),
                    */
                    aCommands,
                   filterClass
               );
    }

    /**
     * Creates and returns and AlertCommand for the synchronization of the
     * given database.
     *
     * @param id the command id - NULL
     * @param noResponse
     * @param credential - NULL
     * @param db the database to be synchronized - NOT NULL
     *
     * @return the AlertCommand object
     */
    public static Alert createAlertCommand(CmdID    id        ,
                                           boolean  noResponse,
                                           Cred     credential,
                                           Database db        ) {
        Item[] items = new Item[1];

        Anchor serverAnchor = db.getServerAnchor();

        Meta meta = new Meta();
        meta.setAnchor(serverAnchor);
        items[0] = new Item(db.getTarget(),
                            db.getSource(),
                            meta          ,
                            null          );

        return new Alert(
                   id            ,
                   noResponse    ,
                   credential    ,
                   db.getMethod(),
                   items
               );
    }

    /**
     * Translates a Target object to a Source object
     *
     * @param target the target object - NULL
     *
     * @return a Source object with the same URI and local name of <i>target</i>
     */
    public static Source target2Source(Target target) {
        if (target == null) return null;

        return new Source(target.getLocURI(), target.getLocName());
    }

    /**
     * Translates a Source object to a Target object
     *
     * @param source the source object - NULL
     *
     * @return a Target object with the same URI and local name of <i>source</i>
     */
    public static Target source2Target(Source source) {
        if (source == null) return null;

        return new Target(source.getLocURI(), source.getLocName());
    }
    
    /** 
     * Extracts the target and source refs from an array of items
     *
     * @param items the items to inspect. If null targetRefs and sourceRefs
     *              remain unchanged
     * @param targetRefs a reference to an array that will contain the references
     *                   to the items' targets
     * @param sourceRefs a reference to an array that will contain the references
     *                   to the items' sources
     *
     */
    public static void extractRefs(Item[] items          , 
                                   TargetRef[] targetRefs,
                                   SourceRef[] sourceRefs) {
        if (items == null) {
            return;
        }
        
        Target t = null;
        Source s = null;
        for (int i=0; i<items.length; ++i) {
            t = items[i].getTarget();
            s = items[i].getSource();
            
            targetRefs[i] = (t != null) ? new TargetRef(t) : null;
            sourceRefs[i] = (s != null) ? new SourceRef(s) : null;
        }
    }
    
}