/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.protocol;

/**
 * This interface grups flags used to drive the reading and the creations of 
 * syncml packages.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: Flags.java,v 1.3 2004/04/13 09:37:32 luigia Exp $
 */
public interface Flags {
    
    public static int HOW_MANY_FLAGS = 6;
    
    /**
     * Generic flags
     */
    public static int FLAG_ALL                    = -1;
    public static int FLAG_ALL_RESPONSES_REQUIRED = -2;
    
    /**
     * Specific flags
     */
    public static int FLAG_SYNC_RESPONSE_REQUIRED          =  0;
    public static int FLAG_MODIFICATIONS_RESPONSE_REQUIRED =  1;
    public static int FLAG_SYNC_STATUS_REQUIRED            =  2;
    public static int FLAG_FINAL_MESSAGE                   =  3;
    
    /**
     * should a deleted item be archived ?
     */
    public static int FLAG_ARCHIVE_DATA                    =  4; 
    
    /**
     * are deletions soft deletions?
     */
    public static int FLAG_SOFT_DELETE                     =  5;
}