/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.protocol.v11;

import sync4j.framework.core.*;

import sync4j.framework.protocol.ProtocolException;
import sync4j.framework.protocol.v11.BasicRequirements;
import sync4j.framework.protocol.v11.Errors;

/**
 * This class groups utility methods used for checking that a client modifications
 * massage follows the requirements that the protocol mandates.
 *
 * @author Stefano Fornari @ Funambol
 */
public class ClientModificationsRequirements 
extends BasicRequirements 
implements Errors {
    
    // --------------------------------------------------------------- Constants
    
    // ---------------------------------------------------------- Public methods
 
    /**
     * Checks if the given command contains a valid request for server capablities.
     *
     * @param cmd the command containing the request
     *
     * @throws ProtocolException
     */
    static public void checkSync(Sync cmd) throws ProtocolException {
        //
        // Checks command id
        //
        try {
            checkCommandId(cmd.getCmdID());
        } catch (ProtocolException e) {
            String[] args = new String[] { e.getMessage() };
            throw new ProtocolException(ERRMSG_INVALID_SYNC_COMMAND, args);
        }
        
        //
        // Checks modifications
        //
        AbstractCommand[] modifications = 
           (AbstractCommand[])cmd.getCommands().toArray(new AbstractCommand[0]);
        
        for (int i=0; ((modifications != null) && (i<modifications.length)); ++i) {
            checkModification((ItemizedCommand)modifications[i]);
        }  // next i
    }
    
    /**
     * Checks the requirements for a modification command.
     *
     * @param cmd the modification command
     *
     * @throws ProtocolException
     */
    static public void checkModification(ItemizedCommand cmd)
    throws ProtocolException {
        //
        // Checks command id
        //
        try {
            checkCommandId(cmd.getCmdID());
        
        
            Item[] items = (Item[])cmd.getItems().toArray(new Item[0]);

            //
            // The type of each single item can be specified at command level
            // or at item level. If the type is specified at command level, items
            // without type will take the command type as default. If the type
            // is not specified at command level, each single item MUST specify
            // its type.
            //
            Meta meta = cmd.getMeta();
            
            boolean checkType = false;
            if (meta.getType() != null) {
                checkType = true;
            }

            for(int i=0; ((items != null) && (i<items.length)); ++i) {
                // 
                // NOTE: all commands but delete use <Data> to carry data about 
                // the modification
                //
                checkModificationItem(items[i], checkType, !cmd.getName().equals("Delete"));
            }
            
        } catch (ProtocolException e) {
            String[] args = new String[] { e.getMessage() };
            throw new ProtocolException(ERRMSG_INVALID_MODIFICATION_COMMAND, args);
        }
    }
    
    /**
     * Checks an item included into a modification command
     *
     * @param item the item to be checked
     * @param checkType indicats if the type specified in the <Meta> tag is
     *                  mandatory and must be checked
     * @param checkData indicates when check for the existance of the <Data> tag
     *
     * @throws ProtocolException
     */
    static public void checkModificationItem(final Item    item     , 
                                             final boolean checkType,
                                             final boolean checkData) 
    throws ProtocolException {
        checkSource(item.getSource());
        
        if (checkType) {
            Meta meta = item.getMeta();
            if (meta.getType() == null) {
               String[] args = new String[] { item.toString() };
               throw new ProtocolException(ERRMSG_MISSING_TYPE, args);
            }
        }
        
        if (checkData) {
            if (item.getData() == null) {
                String[] args = new String[] { item.toString() };
                throw new ProtocolException(ERRMSG_MISSING_DATA, args);
            }
        }
    }
        
}