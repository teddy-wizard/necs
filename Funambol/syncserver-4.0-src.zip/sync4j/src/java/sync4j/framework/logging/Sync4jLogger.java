/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.logging;

import java.util.logging.Logger;

/**
 * Provides a common logging facility for the framework. 
 * <p>
 * The verbosity of the log can be set in the JDK logging properties files
 * giving one of the following values (case insensitively):
 * <ul>
 *   <li>SEVERE
 *   <li>WARNING
 *   <li>INFO
 *   <li>CONFIG
 *   <li>FINE
 *   <li>FINER
 *   <li>FINEST
 *   <li>ALL
 * </ul>
 *
 * For example, for the Sync4j default logger, you can specify:
 * <pre>
 *   sync4j.level=SEVERE
 * </pre>
 * @author  Stefano Fornari @ Funambol.com
 */
public class Sync4jLogger {
    
    public static final String LOG_NAME = "sync4j";
    
    /**
     * Returns the Sync4j default logger
     *
     * @return the Sync4j default logger
     */
    public static Logger getLogger() {
        return Logger.getLogger(LOG_NAME);
    }
    
    /**
     * Returns the logger associated with the name <i>LOG_NAME</i>.name.
     *
     * @param name the subname of the logger.
     *
     * @return the logger associated with the name <i>LOG_NAME</i>.name.
     */
    public static Logger getLogger(String name) {
        return Logger.getLogger(LOG_NAME + '.' + name);
    } 
}