/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.logging;

import java.util.logging.Logger;

import com.p6spy.engine.logging.appender.FormattedLogger;
import com.p6spy.engine.logging.appender.P6Logger;

/**
 * Appender for P6Spy SQL logger.
 *
 *
 * @author  Stefano Fornari @ Funambol.com
 * @version $Id: P6SpyLogger.java,v 1.3 2004/04/13 09:37:32 luigia Exp $
 */
public class P6SpyLogger extends FormattedLogger implements P6Logger {
    public static final String LOG_NAME = "sync4j.log.sql";
    
    protected Logger log = null;
    
    public P6SpyLogger() {
        log = Logger.getLogger(LOG_NAME);
    }
    
    public void logSQL(int    connectionId, 
                       String now         , 
                       long   elapsed     , 
                       String category    , 
                       String prepared    , 
                       String sql         ) {
                           
        StringBuffer sb = new StringBuffer();
        
        sb.append(now).append(' ');
        sb.append((connectionId==-1 ? "" : String.valueOf(connectionId))).append(' ');
        sb.append(category).append(' ');
        
        if ((prepared != null) && (prepared.length() >= 0)) {
            logText(sb.toString() + prepared);
        }
        
        sb.append(elapsed).append(' ');
        sb.append(sql).append(' ');

        logText(sb.toString());
    }
    
    public void logText(String text) {
        log.info(text);
        setLastEntry(text);
    }
    
    public void logException(Exception e) {
        log.throwing("-", "-", e);
    }
}