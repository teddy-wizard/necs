/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * Corresponds to the &ltDevInf&gt element in the SyncML devinf DTD
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: DevInf.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class DevInf
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private VerDTD verDTD;
    private String man;
    private String mod;
    private String oem;
    private String fwV;
    private String swV;
    private String hwV;
    private String devID;
    private String devTyp;
    private ArrayList datastores = new ArrayList();   
    private ArrayList ctCap = new ArrayList();
    private ArrayList ext = new ArrayList();
    private boolean utc;
    private boolean supportLargeObjs;
    private boolean supportNumberOfChanges;

    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected DevInf() {}
    
    /**
     * Creates a new DevInf object with the given parameter
     *
     * @param verDTD the DTD version - NOT NULL
     * @param man the device manufacturer
     * @param mod the device model name
     * @param oem the device OEM
     * @param fwV the device firmware version
     * @param swV the device software version
     * @param hwV the device hardware version
     * @param devID the device ID - NOT NULL
     * @param devTyp the device type - NOT NULL
     * @param datastores the array of datastore - NOT NULL
     * @param ctCap the array of content type capability - NOT NULL
     * @param ext the array of extension element name - NOT NULL
     * @param utc is true if the device supports UTC based time
     * @param supportLargeObjs is true if the device supports handling of large objects
     * @param supportNumberOfChanges is true if the device supports number of changes
     *
     */
    public DevInf(final VerDTD verDTD,
                  final String man,
                  final String mod,
                  final String oem,
                  final String fwV,
                  final String swV,
                  final String hwV,
                  final String devID,
                  final String devTyp,
                  final DataStore[] dataStores,
                  final CTCap[] ctCap,              
                  final Ext[] ext) {

        setVerDTD(verDTD);
        setDevID(devID);
        setDevTyp(devTyp);
        setDataStore(dataStores);
        setCTCap(ctCap);
        setExt(ext);

        this.man = man;
        this.mod = mod;
        this.oem = oem;
        this.fwV = fwV;
        this.swV = swV;
        this.hwV = hwV;
    }
    
    // ---------------------------------------------------------- Public methods
    /**
     * Gets the DTD version property
     *
     * @return the DTD version property
     */
    public VerDTD getVerDTD() {
        return verDTD;
    }
    
    /**
     * Sets the DTD version property
     *
     * @param verDTD the DTD version
     */
    public void setVerDTD(VerDTD verDTD) {
        if (verDTD == null) {
            throw new IllegalArgumentException("verDTD cannot be null");
        }
        this.verDTD = verDTD;
    }

    /**
     * Gets the device manufacturer property
     *
     * @return the device manufacturer property
     */
    public String getMan() {
        return man;
    }
    
    /**
     * Sets the device manufacturer property
     * 
     * @param man the device manufacturer property
     *
     */
    public void setMan(String man) {
        this.man = man;
    }

    /**
     * Gets the model name of device
     *
     * @return the model name of device
     */
    public String getMod() {
        return mod;
    }

    /**
     * Sets the device model property
     * 
     * @param man the device model property
     *
     */
    public void setMod(String mod) {
        this.mod = mod;
    }

    /**
     * Gets the Original Equipment Manufacturer of the device
     *
     * @return the OEM property
     */
    public String getOEM() {
        return oem;
    }
    
    /**
     * Sets the Original Equipment Manufacturer of the device
     * 
     * @param oem the Original Equipment Manufacturer of the device
     *
     */
    public void setOEM(String oem) {
        this.oem = oem;
    }

    /**
     * Gets the firmware version property
     *
     * @return the firmware version property
     */
    public String getFwV() {
        return fwV;
    }

    /**
     * Sets the firmware version property
     *
     * @param fwV the firmware version property
     *
     */
    public void setFwV(String fwV) {
        this.fwV =fwV;
    }
    
    /**
     * Gets the software version property
     *
     * @return the software version property
     */
    public String getSwV() {
        return swV;
    }

    /**
     * Sets the software version property
     *
     * @param swV the software version property
     *
     */
    public void setSwV(String swV) {
        this.swV =swV;
    }
    
    /**
     * Gets the hardware version property
     *
     * @return the hardware version property
     */
    public String getHwV() {
        return hwV;
    }

    /**
     * Sets the hardware version property
     *
     * @param hwV the hardware version property
     *
     */
    public void setHwV(String hwV) {
        this.hwV =hwV;
    }
    
    /**
     * Gets the device identifier
     *
     * @return the device identifier
     */
    public String getDevID() {
        return devID;
    }
    
    /**
     * Sets the device identifier
     *
     * @param devID the device identifier
     *
     */
    public void setDevID(String devID) {
        if (devID == null) {
            throw new IllegalArgumentException("devID cannot be null");
        }
        this.devID = devID;
    }

    /**
     * Gets the device type
     *
     * @return the device type
     */
    public String getDevTyp() {
        return devTyp;
    }
    
    /**
     * Sets the device type
     *
     * @param devTyp the device type
     *
     */
    public void setDevTyp(String devTyp) {
        if (devTyp == null) {
            throw new IllegalArgumentException("devTyp cannot be null");
        }
        this.devTyp = devTyp;
    }

    /**
     * Gets the array of datastore
     *
     * @return the array of datastore
     */    
    public ArrayList getDataStore() {
        return this.datastores;
    }
    
    /**
     * Sets an array of datastore
     * 
     * @param dataStore an array of datastore
     *
     */
    public void setDataStore(DataStore[] dataStores) {
        if (dataStores == null ) {
            throw new IllegalArgumentException("datastores cannot be null");
        }
        
        List c = Arrays.asList(dataStores);
        this.datastores.addAll(c);

    }

    /**
     * Gets the array of content type capability
     *
     * @return the array of content type capability
     */
    public ArrayList getCTCap() {
        return this.ctCap;
    }

    /**
     * Sets an array of content type capability
     *
     * @param ctCap an array of content type capability
     *
     */
    public void setCTCap(CTCap[] ctCap) {        
        if (ctCap != null) {
            List c = Arrays.asList(ctCap);
            this.ctCap.addAll(c);
        }
    }

    /**
     * Gets the array of extension
     *
     * @return the array of extension
     */
    public ArrayList getExt() {
        return this.ext;
    }
    
    /**
     * Sets an array of extensions
     *
     * @param ext an array of extensions
     *
     */
    public void setExt(Ext[] ext) {
        if (ext != null) {
            List c = Arrays.asList(ext);
            this.ext.addAll(c);
        }
    }
          
    /**
     * Gets true if the device supports UTC based time
     *
     * @return true if the device supports UTC based time
     */
    public boolean isUtC() {
        return this.utc;
    }
    
    /**
     * Sets the UTC property
     *
     * @param utc is true if the device supports UTC based time
     */
    public void setUTC(boolean utc) {
        this.utc = utc;
    }
    
    /**
     * Gets true if the device supports handling of large objects
     *
     * @return true if the device supports handling of large objects
     */
    public boolean isSupportLargeObjs() {
        return this.supportLargeObjs;
    }
    
    /**
     * Sets the supportLargeObjs property
     *
     * @param supportLargeObjs is true if the device supports handling of large objects
     *
     */
    public void setSupportLargeObjs(boolean supportLargeObjs) {
        this.supportLargeObjs = supportLargeObjs;
    }
    
    
    /**
     * Gets true if the device supports number of changes
     *
     * @return true if the device supports number of changes
     */
    public boolean isSupportNumberOfChanges() {
        return this.supportNumberOfChanges;
    }
    
    /**
     * Sets the supportNumberOfChanges property
     *
     * @param supportNumberOfChanges is true if the device supports number of changes
     *
     */
    public void setSupportNumberOfChanges(boolean supportNumberOfChanges) {
        this.supportNumberOfChanges = supportNumberOfChanges;
    }
}