/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.framework.core;

import java.io.PrintStream;
import java.io.PrintWriter;

import java.text.MessageFormat;


/**
 * Because this class must be JDK 1.1.8 compliant, we can't use the <i>cause</i>
 * stuff of the JDK 1.2...
 *
 * @author    Sean C. Sullivan, Stefano Fornari
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Sync4jException.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public class Sync4jException extends Exception {
   Throwable cause;

   /**
     * @param strMsg  human readable String that describes the cause of the
     *      exception
     */
    public Sync4jException(final String strMsg) {
        super(strMsg);
    }

    /**
     * Constructor for the ServerException object
     *
     * @param strMsg    Description of the Parameter
     * @param aobjArgs  Description of the Parameter
     */
    public Sync4jException(final String strMsg, final Object[] aobjArgs) {
         super(MessageFormat.format(strMsg, aobjArgs));
    }

    public Sync4jException(final String strMsg, final Throwable cause) {
        super(strMsg);

        this.cause = cause;
    }

    public Sync4jException(final Throwable cause) {
        this("", cause);
    }

    public Throwable getCause() {
        return cause;
    }

    public void printStackTrace() {
        super.printStackTrace();
        if (cause != null) {
            System.err.println("Caused by:");
            cause.printStackTrace();
        }
    }

    public void printStackTrace(PrintStream ps) {
        super.printStackTrace(ps);
        if (cause != null) {
            System.err.println("Caused by:");
            cause.printStackTrace(ps);
        }
    }

    public void printStackTrace(PrintWriter pw) {
        super.printStackTrace(pw);
        if (cause != null) {
            System.err.println("Caused by:");
            cause.printStackTrace(pw);
        }
    }
}