/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;


/**
 * This class represents the possible alerts code.
 *
 * @author Stefano Fornari
 *
 * @version $Id: AlertCode.java,v 1.1 2004/04/13 09:37:29 luigia Exp $
 *  
 * @see AlertCommand
 *
 */
public final class AlertCode {
  public final static int DISPLAY                       = 100;
  public final static int TWO_WAY                       = 200;
  public final static int SLOW                          = 201;
  public final static int ONE_WAY_FROM_CLIENT           = 202;
  public final static int REFRESH_FROM_CLIENT           = 203;
  public final static int ONE_WAY_FROM_SERVER           = 204;
  public final static int REFRESH_FROM_SERVER           = 205;
  public final static int TWO_WAY_BY_SERVER             = 206;
  public final static int ONE_WAY_FROM_CLIENT_BY_SERVER = 207;
  public final static int REFRESH_FROM_CLIENT_BY_SERVER = 208;
  public final static int ONE_WAY_FROM_SERVER_BY_SERVER = 209;
  public final static int REFRESH_FROM_SERVER_BY_SERVER = 210;
  public final static int RESULT_ALERT                  = 221;
  public final static int NEXT_MESSAGE                  = 222;

  private AlertCode() {}
  
  /**
   * Determines if the given code is an initialization code, such as one of:
   * <ul>
   *   <li> TWO_WAY                      
   *   <li> SLOW                         
   *   <li> ONE_WAY_FROM_CLIENT          
   *   <li> REFRESH_FROM_CLIENT          
   *   <li> ONE_WAY_FROM_SERVER          
   *   <li> REFRESH_FROM_SERVER        
   *   <li> TWO_WAY_BY_SERVER          
   *   <li> ONE_WAY_FROM_CLIENT_BY_SERVE
   *   <li> REFRESH_FROM_CLIENT_BY_SERVER
   *   <li> ONE_WAY_FROM_SERVER_BY_SERVER
   *   <li> REFRESH_FROM_SERVER_BY_SERVER
   * </ul>
   *
   * @param code the code to be checked
   *
   * @return true if the code is an initialization code, false otherwise
   */
  static public boolean isInitializationCode(int code) {
      return (  (code == TWO_WAY                      )
             || (code == SLOW                         )
             || (code == ONE_WAY_FROM_CLIENT          )
             || (code == REFRESH_FROM_CLIENT          )
             || (code == ONE_WAY_FROM_SERVER          )
             || (code == REFRESH_FROM_SERVER          )
             || (code == TWO_WAY_BY_SERVER            )
             || (code == ONE_WAY_FROM_CLIENT_BY_SERVER)
             || (code == REFRESH_FROM_CLIENT_BY_SERVER)
             || (code == ONE_WAY_FROM_SERVER_BY_SERVER)
             || (code == REFRESH_FROM_SERVER_BY_SERVER)
             );
  }
  
  /**
   * Determines if the given code represents a client only action, such as is 
   * one of:
   * <ul>
   *   <li>ONE_WAY_FROM_CLIENT</li>
   *   <li>REFRESH_FROM_CLIENT</li>
   * </ul>
   *
   * @param code the code to be checked
   *
   * @return true if the code represents a client only action, false otherwise
   */
  static public boolean isClientOnlyCode(int code) {
      return (  (code == ONE_WAY_FROM_CLIENT)
             || (code == REFRESH_FROM_CLIENT)
             );
  }

}