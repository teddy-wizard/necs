/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import sync4j.framework.tools.Base64;

/**
 * This is a base class for "authentication" classes
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Authentication.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Authentication {

    // ------------------------------------------------------------ Private data
    private String type     = null;
    private String format   = null;
    private String data     = null;
    private String username = null;
    private String password = null;
    private boolean encode = false;
    
    // ------------------------------------------------------------ Constructors

    /** For serialization purposes */
    protected Authentication() {}

    public Authentication(final String type, 
                          final String data) {
        
        createAuthentication(type, data);
    }
    
    /**
     * Creates a new Authentication object with the given data
     *
     * @param data the data of authentication
     *
     */
    public Authentication(final String data) {
        createAuthentication(type, data);     
    }
    
    public Authentication(final String type, 
                          final String data, 
                          final boolean encode) {

        this.encode = encode;
        createAuthentication(type, data);
    }
    
    public Authentication(final String type, 
                          final String username, 
                          final String password) {

        this(type, username + ":" + password, true);
        
        if (username == null || password == null)
            throw new IllegalArgumentException(
                     "The authentication username and password cannot be null");
        
    }
    
    // ---------------------------------------------------------- Public methods

    public void createAuthentication(String type, String data) {
        
        if (Constants.AUTH_SUPPORTED_TYPES.indexOf(type) < 0) {
            
            type = Constants.AUTH_TYPE_BASIC;
        }
        
        if (Constants.AUTH_TYPE_BASIC.equals(type)) {
            
            this.setType(Constants.AUTH_TYPE_BASIC);
            this.setFormat(Constants.FORMAT_B64);
            this.setData(data);
            
        } else if (Constants.AUTH_TYPE_CLEAR.equals(type)) {
            
            this.setType(Constants.AUTH_TYPE_CLEAR);
            this.setFormat(Constants.FORMAT_CLEAR);
            this.setData(data);
            
        }        
    }
        
    /**
     * Gets the type property
     *
     * @return the type property
     */
    public String getType() {
        return this.type;
    }
    
    public void setType(String type) {
        if (type == null)
            throw new IllegalArgumentException("type cannot be null");

        this.type = type;
    }

    /**
     * Gets the format property
     *
     * @return the format property
     */
    public String getFormat() {
        return this.format;
    };
    
    public void setFormat(String format) {
        this.format = format;
    };

    /**
     * Gets the data property
     *
     * @return the data property
     */
    public final String getData() {
        return data;
    }

    /**
     * Sets the data property
     *
     * @param data the data property
     *
     */
    public void setData(String data) {
        if (data == null)
            throw new IllegalArgumentException("data cannot be null");

        if (this.type.equals(Constants.AUTH_TYPE_CLEAR)) {
            this.data = data;

            int p = data.indexOf(':');

            if (p == -1) {
                this.setUsername(data);
                this.setPassoword(null);
            } else {
                this.username = (p>0) ? data.substring(0, p) : "";
                this.password = (p<data.length()) ? data.substring(p) : "";
            }
        }
        
        if (this.type.equals(Constants.AUTH_TYPE_BASIC)) {        
            String clearData = null;
        
            if (encode) {
                this.data = new String(Base64.encode(data.getBytes()));
                clearData = data;
            } else {                
                clearData = new String(Base64.decode(data.getBytes()));
                this.data = data;
            }            
            
            int p = clearData.indexOf(':');

            if (p == -1) {
                this.setUsername(clearData);
                this.setPassoword(null);
            } else {
                this.username = (p>0) ? clearData.substring(0, p) : "";
                this.password = (p<data.length()) ? clearData.substring(p) : "";
            }
        }       
    }

    
    /**
     * Gets username property
     *
     * @return the username property
     */
    public String getUsername() {
        return username;
    }
    
    /**
     * Sets the username property
     *
     * @param username the username property
     */
    public void setUsername(String username) {
        this.username = username;
    }
    
    /**
     * Gets password property
     *
     * @return the password property
     */
    public String getPassword() {
        return password;
    }
    
    /**
     * Sets the password property
     *
     * @param password the password property
     */
    public void setPassoword(String password) {
        this.password = password;
    }

}