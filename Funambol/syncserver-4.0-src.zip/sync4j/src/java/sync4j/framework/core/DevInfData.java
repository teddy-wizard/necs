/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * Corresponds to the &ltData&gt tag in the SyncML represent DTD when delivering
 * a Put command element
 *  
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: DevInfData.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class DevInfData 
extends Data
implements java.io.Serializable {
    // ------------------------------------------------------------ Private data
    private DevInf devInf;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected DevInfData() {}    
    
    /**
     * Creates a new DevInfData object with the given parameter
     *
     * @param devInf the DevInf object - NOT NULL
     *
     */
    public DevInfData(final DevInf devInf) {
        setDevInf(devInf);
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Gets the devInf object
     *
     * @return devInf the devInf object
     */
    public DevInf getDevInf() {
        return this.devInf;
    }
    
    /**
     * Sets the DevInf object
     * 
     * @param devInf the DevInf object
     *
     */
    public void setDevInf(DevInf devInf) {
        if (devInf == null) {
            throw new IllegalArgumentException("devInf cannot be null");
        }
        this.devInf = devInf;
    }
}