/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This is the base (and abstract) class for response commands
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: ResponseCommand.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public abstract class ResponseCommand 
extends ItemizedCommand
implements java.io.Serializable {
    
    // ---------------------------------------------------------- Protected data
    
    /**
     * Message reference
     */
    protected String msgRef;
    
    /** 
     * Command reference
     */
    protected String cmdRef;
    
    /**
     * Target references
     */
    protected ArrayList targetRef = new ArrayList();
    
    /**
     * Source references
     */
    protected ArrayList sourceRef = new ArrayList();
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected ResponseCommand() {}
    
    /**
     * Creates a new ResponseCommand object.
     *
     * @param cmdid the command idendifier  - NOT NULL
     * @param msgRef message reference
     * @param cmdRef command reference - NOT NULL
     * @param targetRefs target references
     * @param sourceRefs source references
     * @param items command items
     *
     * @throws IllegalArgumentException if any of the NOT NULL parameter is null
     */
    public ResponseCommand(
        final CmdID cmdid     ,
        final String            msgRef    ,
        final String            cmdRef    ,
        final TargetRef[]       targetRefs,
        final SourceRef[]       sourceRefs,
        final Item[]            items     ) {
        super(cmdid, items);
        
        setCmdRef(cmdRef);
        
        this.msgRef = msgRef;
        
        setTargetRef(targetRefs);
        setSourceRef(sourceRefs);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the message reference
     *
     * @return the message reference
     *
     */
    public String getMsgRef() {
        return this.msgRef;
    }
    
    /**
     * Sets the message reference
     *
     * @param msgRef message reference
     */
    public void setMsgRef(String msgRef) {
        this.msgRef = msgRef;
    }
    
    /**
     * Returns the command reference
     *
     * @return the command reference
     *
     */
    public String getCmdRef() {
        return cmdRef;
    }
    
    /**
     * Sets the command reference
     *
     * @param cmdRef commandreference - NOT NULL
     *
     * @throws IllegalArgumentException if cmdRef is null
     */
    public void setCmdRef(String cmdRef) {
        if (cmdRef == null) {
            throw new IllegalArgumentException("cmdRef cannot be null");
        }        
        this.cmdRef = cmdRef;
    }
    
    /**
     * Returns the target references
     *
     * @return the target references
     *
     */
    public ArrayList getTargetRef() {
        return this.targetRef;
    }
    
    /**
     * Sets the target references
     *
     * @param targetRefs target refrences
     */
    public void setTargetRef(TargetRef[] targetRefs) {  
        if (targetRefs == null) {
            this.targetRef = null;
        } else {
            this.targetRef.addAll(Arrays.asList(targetRefs));
        }
    }
    
    /**
     * Returns the source references
     *
     * @return the source references
     *
     */
    public ArrayList getSourceRef() {
        return this.sourceRef;
    }
    
    /**
     * Sets the source references
     *
     * @param sourceRefs source refrences
     */
    public void setSourceRef(SourceRef[] sourceRefs) {
        if (sourceRefs == null) {
            this.sourceRef = null;
        } else {
            this.sourceRef.addAll(Arrays.asList(sourceRefs));
        }
    }
    
    /**
     * Returns the command name. It must be redefined by subclasses.
     *
     * @return the command name
     */
    abstract public String getName();
    
}