/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents an authentication challenge element. It  corresponds
 * to the &ltChal&gt element in SyncML representation DTD
 *
 *  @author Stefano Fornari @ Funambol
 *  @see    Credential
 *
 *  @version $Id: Chal.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Chal
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String type;
    private String format;
    private NextNonce nextNonce;

    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected Chal() {}

    /**
     * Constructs a new Chal object.
     *
     * @param type The authentication type (see Constants) - NOT NULL
     * @param format The encoding format (suzh as b64) - NOT NULL
     * @param nextNonce The next nonce value - NULL
     *
     */
    public Chal(final String    type     ,
                final String    format   ,
                final NextNonce nextNonce) {
        if (type == null) {
            throw new IllegalArgumentException(
                                     "The authentication type cannot be null");
        }

        this.type      = type     ;
        this.format    = format   ;
        this.nextNonce = nextNonce;

        if (format == null) {
            if (type.equalsIgnoreCase(Constants.AUTH_TYPE_BASIC)) {
                this.format = Constants.FORMAT_B64;
            } else {
                throw new IllegalArgumentException(
                                   "The authentication format cannot be null");
            }
        }
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Returns the nextNonce property or null
     *
     *  @return the nextNonce property or null
     */
    public NextNonce getNextNonce() {
        return nextNonce;
    }
    
    /**
     * Sets the NextNonce object
     *
     * @param nextNonce the NextNonce object
     *
     */
    public void setNextNonce(NextNonce nextNonce) {
        this.nextNonce = nextNonce;
    }

    /**
     * Returns the authentication type
     *
     * @return authentication type.
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the type of authentication challenge
     *
     * @param type the type of authentication challenge
     *
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /**
     * Returns the authentication format
     *
     * @return format the authentication format
     */
    public String getFormat() {
        return format;
    }

    /**
     * Sets the format of authentication challenge
     *
     * @param format the format of authentication challenge
     *
     */
    public void setFormat(String format) {
        this.format = format;
    }
    
    /**
     * Creates a basic authentication challange.
     * This will have type = Constants.AUTH_TYPE_BASIC and
     * format = Constants.FORMAT_B64
     *
     * @return the newly created AuthenticationChallange
     */
    public static Chal getBasicChal() {
        return new Chal(Constants.AUTH_TYPE_BASIC, Constants.FORMAT_B64, null);
    }
}