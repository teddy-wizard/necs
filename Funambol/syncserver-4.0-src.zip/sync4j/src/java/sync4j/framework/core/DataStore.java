/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * Corresponds to &ltDataStore&gt element in SyncML devinf DTD
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: DataStore.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class DataStore 
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private SourceRef sourceRef;
    private String displayName;
    private long maxGUIDSize;
    private ContentTypeInfo rxPref;
    private ArrayList rx = new ArrayList();
    private ContentTypeInfo txPref;
    private ArrayList tx = new ArrayList();
    private DSMem dsMem;
    private SyncCap syncCap;
    
    // ------------------------------------------------------------ Constructors
    
    /** For serialization purposes */
    protected DataStore() {}
    
    /**
     * Creates a new DataStore object with the given input information
     *
     * @param sourceRef specifies the source address from the associated 
     *                  command - NOT NULL
     * @param displayName the display name
     * @param maxGUIDSize the maximum GUID size. Set to -1 if the Maximum GUID 
     *                  size is unknown or unspecified. Otherwise, this 
     *                  parameter should be a positive number.
     * @param rxPref the relative information received to the content type 
     *               preferred - NOT NULL
     * @param rx an array of the relative info received to the content type 
     *           supported - NOT NULL
     * @param txPref the relative information trasmitted 
     *                  to the content type preferred - NOT NULL
     * @param tx an array of the relative info trasmitted to the content type 
     *           supported - NOT NULL
     * @param dsMem the datastore memory info
     * @param syncCap the synchronization capabilities - NOT NULL
     *
     */
    public DataStore(final SourceRef sourceRef,
                     final String displayName,
                     final long maxGUIDSize,
                     final ContentTypeInfo rxPref,
                     final ContentTypeInfo[] rx,
                     final ContentTypeInfo txPref,
                     final ContentTypeInfo[] tx,
                     final DSMem dsMem,
                     final SyncCap syncCap) {
        
        setSourceRef(sourceRef);
        setMaxGUIDSize(maxGUIDSize);
        setRxPref(rxPref);
        setRx(rx);
        setTxPref(txPref);
        setTx(tx);
        setSyncCap(syncCap);
       
        this.displayName = displayName;        
        this.dsMem = dsMem;
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Gets the sourceRef properties
     *
     * @return the sourceRef properties
     */
    public SourceRef getSourceRef() {
        return sourceRef;
    }
    
    /**
     * Sets the reference URI
     *
     * @param sourceRef the reference URI
     *
     */
    public void setSourceRef(SourceRef sourceRef) {
        if (sourceRef == null) {
            throw new IllegalArgumentException("sourceRef cannot be null");
        }
        this.sourceRef = sourceRef;
    }
    
    /**
     * Gets the displayName properties
     *
     * @return the displayName properties
     */
    public String getDisplayName() {
        return displayName;
    }
    
    /**
     * Gets the maxGUIDSize properties
     *
     * @return the maxGUIDSize properties
     */
    public long getMaxGUIDSize() {
        return maxGUIDSize;
    }

    public void setMaxGUIDSize(long maxGUIDSize) {
        if ((maxGUIDSize == 0) || (maxGUIDSize < -1)) {
            throw new IllegalArgumentException("illegal maxGUIDSize value");
        }
        this.maxGUIDSize = maxGUIDSize;
    }
    
    /**
     * Gets the ContentTypeInfo corresponds to &ltRx-Pref&gt element
     *
     * @return the ContentTypeInfo corresponds to &ltRx-Pref&gt element
     */
    public ContentTypeInfo getRxPref() {
        return rxPref;
    }

    /**
     * Sets the preferred type and version of a content type received by the device
     *
     * @param rxPref the preferred type and version of a content type
     */
    public void setRxPref(ContentTypeInfo rxPref) {
        if (rxPref == null) {
            throw new IllegalArgumentException("rxPref cannot be null");
        }
        this.rxPref = rxPref;
    }
    
    /**
     * Gets the ContentTypeInfo corresponds to &ltRx&gt element
     *
     * @return the ContentTypeInfo corresponds to &ltRx&gt element
     */
    public ArrayList getRx() {
        return rx;
    }
    
    /**
     * Sets the supported type and version of a content type received by the device
     *
     * @param rx and array of supported type and version of a content type
     */
    public void setRx(ContentTypeInfo[] rxCTI) {
        if (rxCTI == null) {
            throw new IllegalArgumentException("rx cannot be null");
        }
        List c = Arrays.asList(rxCTI);
        this.rx.addAll(c);
    }
    
    
    /**
     * Gets the ContentTypeInfo corresponds to &ltTx-Pref&gt element
     *
     * @return the ContentTypeInfo corresponds to &ltTx-Pref&gt element
     */
    public ContentTypeInfo getTxPref() {
        return txPref;
    }
    
    /**
     * Sets the preferred type and version of a content type trasmitted by the device
     *
     * @param txPref the preferred type and version of a content type
     */
    public void setTxPref(ContentTypeInfo txPref) {
        if (txPref == null) {
            throw new IllegalArgumentException("txPref cannot be null");
        }
        this.txPref = txPref;
    }
    
    /**
     * Gets an array of ContentTypeInfo corresponds to &ltTx&gt element
     *
     * @return an array of ContentTypeInfo corresponds to &ltTx&gt element
     */
    public ArrayList getTx() {
        return tx;
    }
    
    /**
     * Sets the supported type and version of a content type trasmitted by the device
     *
     * @param tx and array of supported type and version of a content type
     */
    public void setTx(ContentTypeInfo[] txCTI) {
        if (txCTI == null) {
            throw new IllegalArgumentException("tx cannot be null");
        }
        List c = Arrays.asList(txCTI);
        this.tx.addAll(c);
    }
    
    /**
     * Gets the datastore memory information.
     *
     * @return the datastore memory information.
     */
    public DSMem getDSMem() {
        return dsMem;
    }
    
    /**
     * Gets the synchronization capabilities of a datastore.
     *
     * @return the synchronization capabilities of a datastore.
     */
    public SyncCap getSyncCap() {
        return syncCap;
    }
    
    /**
     * Sets the synchronization capabilities of a datastore.
     *
     * @param syncCap the synchronization capabilities of a datastore
     *
     */
    public void setSyncCap(SyncCap syncCap) {
        if (syncCap == null) {
            throw new IllegalArgumentException("syncCap cannot be null");
        }
        this.syncCap = syncCap;
    }
}