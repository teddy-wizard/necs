/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the &lt;MapItem&gt; tag as defined by the SyncML r
 * epresentation specifications.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Mark.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 *
 */
final public class Mark 
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static final String DRAFT    = "draft"   ;
    public static final String FINAL    = "final"   ;
    public static final String DELETE   = "delete"  ;
    public static final String UNDELETE = "undelete";
    public static final String READ     = "read"    ;
    public static final String UNREAD   = "unread"  ;
    
    // ------------------------------------------------------------ Private data
    
    private String mark;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Mark() {}
    
    /**
     * Creates a new Mark object with the given value
     *
     * @param mark the mark value - NOT NULL
     *
     * @throws IllegalArgumentException if mark is null
     */
    public Mark(String mark) {
        setMark(mark);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the mark
     */
    public String getMark() {
        return mark;
    }
    
    /** 
     * Sets the mark value
     *
     * @param mark the mark value - NOT NULL
     *
     * @throws IllegalArgumentException if mark is null
     */
    public void setMark(String mark) {
        if (mark == null) {
            throw new IllegalArgumentException("mark cannot be null");
        }        
        this.mark = mark;
    }
}