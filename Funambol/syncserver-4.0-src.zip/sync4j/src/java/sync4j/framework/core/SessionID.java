/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class is related to the "last" and "next" values in an &ltAnchor&gt tag 
 * in the metainfo spec
 *
 * @author Stefano Fornari @ Funambol
 * @see    SyncAnchor
 *
 * @version $Id: SessionID.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class SessionID
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data

    private String sessionID;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected SessionID() {}
    
    /**
     * Create a new SessionID object with the parameters
     *
     * @param sessionID the identifier of session - NOT NULL
     *
     */
    public SessionID(final String sessionID) {
        setSessionID(sessionID);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Gets the session identifier
     *
     * @return sessionID the session identifier
     */
    public String getSessionID() {
        return sessionID;
    }
    
    /**
     * Sets the session identifier
     *
     * @param sessionID the session identifier
     */
    public void setSessionID(String sessionID) {
        if (sessionID == null || sessionID.length() == 0) {
            throw new IllegalArgumentException(
                                          "sessionID cannot be null or empty");
        }
        this.sessionID = sessionID;
    }
}