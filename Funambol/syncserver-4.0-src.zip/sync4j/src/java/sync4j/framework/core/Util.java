/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.core;

import java.io.ByteArrayOutputStream;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.*;

/**
 *
 * This class contains methods for serialize and deserialize
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Util.java,v 1.2 2004/04/13 17:35:00 luigia Exp $
 *
 */
public final class Util {

    // ------------------------------------------------------------ Private data
    private static final String NS_METINF_1 = " xmlns=\"syncml:metinf\"";
    private static final String NS_METINF_2 = " xmlns=\'syncml:metinf\'";
    private static final String NS_DEVINF_1 = " xmlns=\"syncml:devinf\"";
    private static final String NS_DEVINF_2 = " xmlns=\'syncml:devinf\'";
    
    // ------------------------------------------------------------ Constructors

    private Util() {
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Serialize Long value to string.
     *
     * @param value Long value to be serialized
     *
     * @return the representation of value
     */
    public static String serializeWrapLong(Long value) {
        return String.valueOf(value);
    }

    /**
     * Deserialize Long from string
     *
     * @param value string to be parsed
     *
     * @return the representation of value
     */
    public static Long deserializeWrapLong(String value) {
        if (value != null) {
            return Long.valueOf(value.trim());
        }
        return null;
    }

	public static Boolean deserializeBoolean(String value) {
		if (value != null && 
            (value.equals("") || value.equalsIgnoreCase("true"))) {
            return new Boolean(true);
		}
		return null;
	}

	public static String serializeBoolean(Boolean value) {
		return value.booleanValue() ? "" : null;
	}
    
    /**
     * Use marshall to create the representation XML of the object SyncML
     *
     * @param syncML the object SyncML
     *
     * @return the representation XML of the message
     */
    public static String toXML(SyncML syncML) {
        String message = null;
        try {
            
            ByteArrayOutputStream bout = new ByteArrayOutputStream();

            IBindingFactory f = BindingDirectory.getFactory(SyncML.class);
            IMarshallingContext c = f.createMarshallingContext();
            c.setIndent(0);
            c.marshalDocument(syncML, "UTF-8", null, bout);
            
            message = new String(bout.toByteArray());
            
        } catch(Exception e) {
            e.printStackTrace();
        }
        return message;
    }
    
    /**
     * Remove the namespace <i>xmlns="syncml:metinf"</i> from the message.
     * Remove the namespace <i>xmlns="syncml:devinf"</i> from the tag SyncML.
     * Add namespace <i>xmlns="syncml:devinf"</i> to tag DevInf
     *
     * @param msg the original message xml
     *
     */
    public static String manageNamespace(String msg) {
        msg = msg.replaceAll(NS_METINF_1, "");
        msg = msg.replaceAll(NS_METINF_2, "");
        msg = msg.replaceAll(NS_DEVINF_1, "");
        msg = msg.replaceAll(NS_DEVINF_2, "");
        msg = msg.replaceAll("<DevInf>", "<DevInf" + NS_DEVINF_1 + ">");
        return msg;
    }
}