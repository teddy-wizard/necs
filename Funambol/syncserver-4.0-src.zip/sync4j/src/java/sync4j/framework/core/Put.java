/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 *
 * This class represents the &lt;Put&gt; tag as defined by the SyncML 
 * representation specifications.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Put.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Put
extends ItemizedCommand
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    public static String COMMAND_NAME = "Put";
    
    // ------------------------------------------------------------ Private data
    private String lang;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Put() {}
    
    /**
     * Creates a new Put object given its elements.
     *
     * @param cmdid the command identifier - NOT NULL
     * @param noResponse is &lt;NoResponse/&gt; required?
     * @param lang Preferred language
     * @param credential authentication credentials
     * @param meta meta information
     * @param items Item elements - NOT NULL
     *
     * @throw IllegalArgumentException if any NOT NULL parameter is null
     */
    public Put(
        final CmdID   cmdID ,
        final boolean noResp,
        final String  lang  ,
        final Cred    cred  ,
        final Meta    meta  ,
        final Item[]  items ) {
        super(cmdID, meta, items);
             
        setCred(cred);
        this.noResp  = (noResp) ? new Boolean(noResp) : null;
        this.lang   = lang;
    }
    

    
   // ----------------------------------------------------------- Public methods
        
    /**
     * Returns the preferred language
     *
     * @return the preferred language
     *
     */
    public String getLang() {
        return lang;
    }
    
    /**
     * Sets the preferred language
     *
     * @param lang new preferred language
     */
    public void setLang(String lang) {
        this.lang = lang;
    }
    
    /**
     * Returns the command name
     *
     * @return the command name
     */
    public String getName() {
        return Put.COMMAND_NAME;
    }
}