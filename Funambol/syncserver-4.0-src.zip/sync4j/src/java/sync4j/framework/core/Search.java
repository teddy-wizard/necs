/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 *
 * This class represents the &lt;Search&gt; tag as defined by the SyncML
 * representation specifications.
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: Search.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 *
 */
public final class Search 
extends AbstractCommand 
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static String COMMAND_NAME = "Search";
    
    // ------------------------------------------------------------ Private data
    
    private Boolean    noResults;
    private Target     target   ;
    private ArrayList  sources = new ArrayList();
    private String     lang     ;
    private Data       data     ;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Search() {}
    
    /**
     * Creates a new Search object.
     *
     * @param cmdid command identifier - NOT NULL
     * @param noResponse is &lt;NoResponse/&gt; required?
     * @param noResults is &lt;NoResults/&gt; required?
     * @param cred  authentication credentials
     * @param target target
     * @param sources sources - NOT NULL
     * @param lang preferred language
     * @param meta meta data - NOT NULL
     * @param data contains the search grammar - NOT NULL
     *
     *  @throws java.lang.IllegalArgumentException if any NOT NULL parameter is null
     *
     */
    public Search(
               final CmdID    cmdid    ,
               final boolean  noResp   ,
               final boolean  noResults,
               final Cred     cred     ,
               final Target   target   ,
               final Source[] sources  ,
               final String   lang     ,
               final Meta     meta     ,
               final Data     data     ) {
        super(cmdid, noResp);

        setCred(cred);
        setMeta(meta);
        setSources(sources);
        setData(data);
        
        this.noResults = (noResults) ? new Boolean(noResults) : null;
        this.target    = target;
        this.lang      = lang  ;
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns noResults
     *
     * @return noResults
     *
     */
    public boolean isNoResults() {
        return (noResults != null);
    }
    
    /**
     * Sets noResults
     *
     * @param noResults the noResults value
     */
    public void setNoResults(Boolean noResults) {
        this.noResults = noResults;
    }
    
    /**
     * Gets the Boolean value of noResults property
     *
     * @return noResults if boolean value is true, otherwise null
     */
    public Boolean getNoResults() {
        if (!noResults.booleanValue()) {
            return null;
        }
        return noResults;
    }    
    
    /**
     * Returns target property
     * @return target the Target property
     */
    public Target getTarget() {
        return target;
    }
    
    /**
     * Sets target property
     *
     * @param target the target property
     */
    public void setTarget(Target target) {
        this.target = target;
    }
    
    /**
     * Returns command sources
     * @return command sources
     */
    public ArrayList getSources() {
        return sources;
    }
    
    /**
     * Sets command sources
     *
     * @param sources the command sources - NOT NULL
     *
     * @throews IllegalArgumentException if sources is null
     */
    public void setSources(Source[] sources) {
        if (sources == null) {
            throw new IllegalArgumentException("sources cannot be null");
        }
        List c = Arrays.asList(sources);
        this.sources.addAll(c);
    }
    
    /**
     * Returns the preferred language
     *
     * @return the preferred language
     *
     */
    public String getLang() {
        return lang;
    }
    
    /**
     * Sets the preferred language
     *
     * @param lang the preferred language
     */
    public void setLang(String lang) {
        this.lang = lang;
    }
        
    /**
     * Returns data
     *
     * @return data
     *
     */
    public Data getData() {
        return data;
    }
    
    /**
     * Sets data
     *
     * @param data the command's data - NOT NULL
     *
     * @throws IllegalArgumentException id data is null
     */
    public void setData(Data data) {
        if (data == null) {
            throw new IllegalArgumentException("data cannot be null");
        }        
        this.data = data;
    }
    
    /**
     * Returns the command name
     *
     * @return the command name
     */
    public String getName() {
        return Search.COMMAND_NAME;
    }
}