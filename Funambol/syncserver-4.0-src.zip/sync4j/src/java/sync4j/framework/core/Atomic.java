/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 *  Corresponds to the &ltAtomic&gt tag in the SyncML represent DTD
 *
 *  @author Stefano Fornari
 *  
 *  @version $Id: Atomic.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Atomic
extends AbstractCommand
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    public static String COMMAND_NAME = "Atomic";

    // ------------------------------------------------------------ Private Data
    private ArrayList commands = new ArrayList();
    
    // ------------------------------------------------------------ Constructors
    
    /** For serialization purposes */
    protected Atomic(){}

    /** 
     * Creates a new Atomic object with the given command identifier, noResponse,
     * meta and an array of abstract command
     *
     * @param cmdID the command identifier - NOT NULL
     * @param noResp is true if no response is required
     * @param meta the meta data
     * @param commands an array of abstract command - NOT NULL
     */
    public Atomic(final CmdID cmdID,
                  final boolean noResp,
                  final Meta meta,
                  final AbstractCommand[] commands) {
        super(cmdID);
        
        this.noResp  = (noResp) ? new Boolean(noResp) : null;
        setMeta(meta);
        setCommands(commands);
        
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets an array of AbstractCommand
     *
     * @return an array of command objects
     */
    public ArrayList getCommands() {
        return this.commands;
    }
    
    /**
     * Sets an array of AbstractCommand
     *
     * @param commands the array of AbstractCommand
     *
     */
    public void setCommands(AbstractCommand[] commands) {
        if (commands == null || commands.length == 0)
            throw new IllegalArgumentException("commands cannot be null");

        for (int i=0; i<commands.length; i++) {
            if ((!(commands[i] instanceof Add))
             && (!(commands[i] instanceof Delete))
             && (!(commands[i] instanceof Copy))
             && (!(commands[i] instanceof Map))
             && (!(commands[i] instanceof Replace))
             && (!(commands[i] instanceof Sequence))
             && (!(commands[i] instanceof Sync))) {
                
                throw new IllegalArgumentException(
                                    "illegal nested command: " + commands[i]);
            }
        }
        
        List c = Arrays.asList(commands);
        this.commands.addAll(c);
    }

    /**
     * Gets the command name property
     *
     * @return the command name property
     */ 
    public String getName() {
        return Atomic.COMMAND_NAME;
    }
}