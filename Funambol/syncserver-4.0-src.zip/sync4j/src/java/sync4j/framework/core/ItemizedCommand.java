/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

/**
 * This is a base class for "command" classes
 *
 * @author  Stefano Fornari @ Funambol
 *
 * @version $Id: ItemizedCommand.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public abstract class ItemizedCommand 
extends AbstractCommand 
implements java.io.Serializable {
    // ---------------------------------------------------------- Protected data
    
    //
    // subclasses must have access the following properties
    //
    protected ArrayList items = new ArrayList();
    protected Meta   meta ;
    
    // ------------------------------------------------------------ Constructors

    /** For serialization purposes */
    protected ItemizedCommand() {}
    
    /**
     * Create a new ItemizedCommand object with the given commandIdentifier, 
     * meta object and an array of item
     *
     * @param cmdID the command identifier - NOT NULL
     * @param meta the meta object
     * @param items an array of item - NOT NULL
     *
     */
    public ItemizedCommand(CmdID cmdID, Meta meta, Item[] items) {
        super(cmdID);
        
        if (cmdID == null) {
            throw new IllegalArgumentException("cmdID cannot be null or empty");
        }

        if (items == null) {
            items = new Item[0];
        }
        
        this.meta  = meta;
        
        List c = Arrays.asList(items);
        this.items.addAll(c);
    }
    
    /**
     * Create a new ItemizedCommand object with the given commandIdentifier
     * and an array of item
     *
     * @param cmdID the command identifier - NOT NULL
     * @param items an array of item - NOT NULL
     *
     */
    public ItemizedCommand(final CmdID  cmdID, final Item[] items) {
        this(cmdID, null, items);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Gets the array of items
     *
     * @return the array of items
     */    
    public java.util.ArrayList getItems() {
        return this.items;
    }
    
    /**
     * Sets an array of Item object
     *
     * @param items an array of Item object
     */    
    public void setItems(Item[] items) {
        java.util.List c = java.util.Arrays.asList(items);
        this.items.addAll(c);
    }
    
    /**
     * Gets the Meta object
     *
     * @return the Meta object
     */
    public Meta getMeta() {
        return meta;
    }

    /**
     * Sets the Meta object
     *
     * @param meta the Meta object
     *
     */
    public void setMeta(Meta meta) {
        this.meta = meta;
    }
    
    /**
     * Gets the name of the command
     *
     * @return the name of the command
     */
    public abstract String getName();
}