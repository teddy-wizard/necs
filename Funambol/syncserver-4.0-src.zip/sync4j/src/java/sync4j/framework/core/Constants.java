/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import sync4j.framework.core.VerDTD;
import sync4j.framework.core.VerProto;

/**
 * This class includes the costants relative to the SyncML.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Constants.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Constants {
   public static final String MIMETYPE_SYNCML_XML 
                                        = "application/vnd.syncml+xml";
   public static final String MIMETYPE_SYNCML_WBXML 
                                        = "application/vnd.syncml+wbxml";
   public static final String MIMETYPE_SYNCML_DEVICEINFO_XML 
                                        = "application/vnd.syncml-devinf+xml";
   public static final String MIMETYPE_SYNCML_DEVICEINFO_WBXML 
                                        = "application/vnd.syncml-devinf+wbxml";

   public static final String NAMESPACE_METINF = "syncml:metinf";
   public static final String NAMESPACE_DEVINF = "syncml:devinf";


   public static final String AUTH_TYPE_MD5   = "syncml:auth-md5";
   public static final String AUTH_TYPE_BASIC = "syncml:auth-basic";
   public static final String AUTH_TYPE_CLEAR = "syncml:auth-clear";
   public static final String AUTH_SUPPORTED_TYPES = AUTH_TYPE_BASIC
                                                   + ','
                                                   + AUTH_TYPE_CLEAR;

   public static final VerDTD DTD_1_0 = new VerDTD("1.0");
   public static final VerDTD DTD_1_1 = new VerDTD("1.1");

   public static final VerProto PROT_1_0   = new VerProto("SyncML/1.0");
   public static final VerProto PROT_1_1   = new VerProto("SyncML/1.1");
   public static final VerProto PROT_1_1_1 = new VerProto("SyncML/1.1.1");

   public static final String FORMAT_B64 = "b64";
   public static final String FORMAT_CLEAR = "clear";
  }