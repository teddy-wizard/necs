/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 *
 * This class represents the &lt;Status&gt; tag as defined by the SyncML
 * representation specifications.
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: Status.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 *
 */
public final class Status
extends ResponseCommand 
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static String COMMAND_NAME = "Status";
    
    // ------------------------------------------------------------ Private data
    
    private Chal   chal;
    private Data   data;
    private String cmd ;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialiazaion purposes
     */
    protected Status() {}
    
    /**
     * Creates a new Status object.
     *
     * @param cmdid command identifier - NOT NULL
     * @param msgRef message reference
     * @param cmdRef command reference - NOT NULL
     * @param cmd command - NOT NULL
     * @param targetRefs target references. If null 
     * @param sourceRefs source references. If null 
     * @param cred authentication credentials
     * @param chal authentication challenge
     * @param data status data - NOT NULL
     * @param items command items - NOT NULL
     *
     * @throws IllegalArgumentException if any NOT NULL argument is null
     *
     */
    public Status(
               final CmdID       cmdid     ,
               final String      msgRef    ,
               final String      cmdRef    ,
               final String      cmd       ,
               final TargetRef[] targetRefs,
               final SourceRef[] sourceRefs,
               final Cred        cred      ,
               final Chal        chal      ,
               final Data        data      ,
               final Item[]      items     ) {
        super(
            cmdid,
            msgRef,
            cmdRef,
            targetRefs,
            sourceRefs,
            items
        );
        
        setCred(cred);
        setData(data);
        setCmd(cmd);

        this.chal = chal;
    }
    
    /**
     * The same as the previous constructor, but accepting <i>targetRefs</i>
     * and <i>sourceRefs</i> as String instead of String[].
     *
     * @param cmdid command identifier - NOT NULL
     * @param msgRef message reference
     * @param cmdRef command reference - NOT NULL
     * @param cmd command - NOT NULL
     * @param targetRefs target references. If null a TargetRef[0] is used
     * @param sourceRefs source references. If null a SourceRef[0] is used
     * @param cred authentication credentials
     * @param chal authentication challenge
     * @param data status data - NOT NULL
     * @param items command items - NOT NULL
     *
     * @throws IllegalArgumentException if any NOT NULL argument is null
     *
     */
    public Status(
               final CmdID     cmdid    ,
               final String    msgRef   ,
               final String    cmdRef   ,
               final String    cmd      ,
               final TargetRef targetRef,
               final SourceRef sourceRef,
               final Cred      cred     ,
               final Chal      chal     ,
               final Data      data     ,
               final Item[]    items    ) {
        this( 
            cmdid,
            msgRef,
            cmdRef,
            cmd,
            (targetRef == null) ? null : new TargetRef[] { targetRef },
            (sourceRef == null) ? null : new SourceRef[] { sourceRef },
            cred,
            chal,
            data,
            items
        );
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the chal element
     *
     * @return the chal element
     *
     */
    public Chal getChal() {
        return chal;
    }
    
    /**
     * Sets the chal element
     *
     * @param chal the new chal
     */
    public void setChal(Chal chal) {
        this.chal = chal;
    }
    
    /**
     * Returns the status data
     *
     * @return the status data
     *
     */
    public Data getData() {
        return data;
    }
    
    /**
     * Sets the status data
     *
     * @param data the new data
     *
     * @throws IllegalArgumentException if data is null
     */
    public void setData(Data data) {
        if (data == null) {
            throw new IllegalArgumentException("data cannot be null");
        }
        this.data = data;
    }
    
    /**
     * Returns the cmd element
     *
     * @return the cmd element
     */
    public String getCmd() {
        return cmd;
    }
    
    /**
     * Sets the cmd element
     *
     * @param cmd the new cmd element - NOT NULL
     *
     * @throws IllegalArgumentException if cmd is null
     */
    public void setCmd(String cmd) {
        if (cmd == null) {
            throw new IllegalArgumentException("cmd cannot be null");
        }        
        this.cmd = cmd;
    }    
    
    /**
     * Returns the command name
     *
     * @return the command name
     */
    public String getName() {
        return Status.COMMAND_NAME;
    }
}