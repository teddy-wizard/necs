/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;


/**
 * This class represents the &lt;Results&gt; tag as defined by the SyncML
 * representation specifications.
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: Results.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Results
extends ResponseCommand 
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static String COMMAND_NAME = "Results";
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Results() {}
    
    /**
     * Creates a new Results object.
     *
     * @param cmdid command identifier - NOT NULL
     * @param msgRef message reference
     * @param cmdRef command reference - NOT NULL
     * @param meta meta information
     * @param targetRef target reference
     * @param sourceRef source reference
     * @param items command items
     *
     * @throws java.lang.IllegalArgumentException if any of the NOT NULL 
     * parameters is null.
     *
     */
    public Results(
        final CmdID     cmdid,
        final String    msgRef,
        final String    cmdRef,
        final Meta      meta,
        final TargetRef targetRef,
        final SourceRef sourceRef,
        final Item[]    items) {
            
        super(
            cmdid,
            msgRef,
            cmdRef,
            (targetRef == null) ? null : new TargetRef[] { targetRef },
            (sourceRef == null) ? null : new SourceRef[] { sourceRef },
            items
        );
            
        this.meta      = meta;
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Returns the command name.
     *
     * @return the command name
     */
    public String getName() {
        return Results.COMMAND_NAME;
    }
}