/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.framework.core;

/**
 * This is just a placeholder to group the modification commands.  For now it 
 * does not add anything to the superclass.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: ModificationCommand.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public abstract class ModificationCommand extends ItemizedCommand {
    
    // ------------------------------------------------------------ Constructors

    /**
     * For serialization purposes
     */
    protected ModificationCommand() {}
    
    /**
     * Creates a new ModificationCommand object.
     *
     * @param cmdid the command identifier
     * @param neta the meta data
     * @param items the modification items
     */
    public ModificationCommand(final CmdID cmdID, final Meta meta, final Item[] items) {
        super(cmdID, meta, items);
    }
    
    /**
     * Creates a new ModificationCommand object.
     *
     * @param cmdid the command identifier
     * @param items the modification items
     */
    public ModificationCommand(final CmdID cmdID, final Item[] items) {
        super(cmdID, items);
    }
}