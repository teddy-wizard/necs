/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the &ltSourceRef&gt element as defined by the SyncML 
 * representation specifications 
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SourceRef.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public final class SourceRef 
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data
    private String value;
    private Source source;
    
    // ------------------------------------------------------------ Constructors

    /**
     * For serialization purposes
     */
    protected SourceRef() {}
    
    /**
     * Creates a new SourceRef object given the referenced value. A null value
     * is considered an empty string
     *
     * @param value the referenced value - NULL ALLOWED
     *
     * @throws IllegalArgumentException if value is null
     */
    public SourceRef(final String value) {
        setValue(value);
    }
    
    /**
     * Creates a new SourceRef object from an existing Source.
     *
     * @param source the source to extract the reference from - NOT NULL
     *
     * @throws IllegalArgumentException if source is null
     *
     */
    public SourceRef(final Source source) {
        setSource(source);
        
        value = source.getLocURI();
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the value
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }
    
    /**
     * Sets the reference value. If value is null, the empty string is adopted.
     *
     * @param value the reference value - NULL
     */
    public void setValue(String value) {
        this.value = (value == null) ? "" : value;
    }
    
    /**
     * Gets the Source property
     * 
     * @return source the Source object property
     */
    public Source getSource() {
        return this.source;
    }
    
    /**
     * Sets the Source property
     * 
     * @param source the Source object property - NOT NULL
     */
    public void setSource(Source source) {
        if (source == null) {
            throw new IllegalArgumentException("source cannot be null");
        }
        this.source = source;
    }
}