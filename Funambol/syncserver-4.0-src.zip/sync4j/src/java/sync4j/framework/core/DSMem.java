/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * Corresponds to the &ltDSMem&gt element in the SyncML devinf DTD
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: DSMem.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class DSMem
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private Boolean sharedMem;
    private long    maxMem   ;
    private long    maxID    ;
    
    // ------------------------------------------------------------ Constructors

    /** For serialization purposes */
    protected DSMem() {}

    /**
     * Creates a new DSMem object with the given sharedMem, maxMem and maxID
     *
     * @param sharedMem is true if the datastore uses shared memory
     * @param maxMem the maximum memory size for o given datastore
     * @param maxID the maximum number of items that can be stored in a given 
     *              datastore
     *
     */
    public DSMem(final boolean sharedMem, final long maxMem, final long maxID) {
        setMaxMem(maxMem);
        setMaxID(maxID);
        this.sharedMem = (sharedMem) ? new Boolean(sharedMem) : null;

    }

    // ---------------------------------------------------------- Public methods

    /**
     * Returns the memoryShared status
     *
     * @return <i>true</i> if the datastore memory is shared, <i>false</i> otherwise
     */
    public boolean isSharedMem() {
        return (sharedMem != null);
    }
    
    /**
     * Sets the memoryShared status
     *
     * @param memoryShared the new memoryShared status
     */
    public void setSharedMem(Boolean sharedMem) {
        this.sharedMem = sharedMem;
    }
    
    /**
     * Gets Boolean shared memory
     * 
     * @return sharedMem the Boolean sharedMem
     */
    public Boolean getSharedMem() {
        if (!sharedMem.booleanValue()) {
            return null;
        }
        return sharedMem;
    }
        
    /**
     * Gets the maximum memory size in bytes
     * 
     * @return if value is -1 indicates that the property value is unspecified
     */
    public long getMaxMem() {
        return this.maxMem;
    }
    
    /**
     * Sets the max memory property
     * 
     * @param maxMem the value of max memory property
     *
     */
    public void setMaxMem(long maxMem) {
        this.maxMem = maxMem;
    }

    /**
     * Gets the maximum number of items
     *
     * @return if value is -1 indicates that the property value is unspecified
     */
    public long getMaxID() {
        return this.maxID;
    }
    
    /**
     * Sets the max ID property
     *
     * @param maxID the value of maxID property
     */
    public void setMaxID(long maxID) {
        this.maxID = maxID;
    }
}