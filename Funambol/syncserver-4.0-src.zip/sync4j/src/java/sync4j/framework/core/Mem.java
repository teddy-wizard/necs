/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the &lt;Mem&gt; tag as defined by the SyncML r
 * epresentation specifications.
 *
 *  @author Stefano Fornari
 *
 *  @version $Id: Mem.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Mem
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    
    private Boolean sharedMem;
    private long    freeMem  ;
    private long    freeID   ;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Mem(){}
    
    /**
     * Creates a new Mem object from memory characteristics.
     *
     * @param isShared is the datastore memory shared
     * @param freeMem free memory size in bytes (>= 0)
     * @param freeID number of available item IDs (>= 0)
     *
     */
    public Mem(final boolean sharedMem, final long freeMem, final long freeID) {        
        setFreeMem(freeMem);
        setFreeID(freeID);
        this.sharedMem = (sharedMem) ? new Boolean(sharedMem) : null;
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the memoryShared status
     *
     * @return <i>true</i> if the datastore memory is shared, <i>false</i> otherwise
     *
     */
    public boolean isSharedMem() {
        return (sharedMem != null);
    }
    
    /**
     * Sets the memoryShared status
     *
     * @param memoryShared the new memoryShared status
     */
    public void setSharedMem(Boolean sharedMem) {
        this.sharedMem = sharedMem;
    }
    
    /**
     * Gets the Boolean shared memory property
     *
     * @return sharedMem the Boolean shared memory property
     */
    public Boolean getSharedMem() {
        if (!sharedMem.booleanValue()) {
            return null;
        }
        return sharedMem;
    }
    
    /**
     * Returns the freeMem property (in bytes)
     *
     * @return the freeMem property
     *
     */
    public long getFreeMem() {
        return freeMem;
    }
    
    /**
     * Sets the freeMem property.
     *
     * @param freeMem the freeMem value (>= 0)
     *
     * @throws IllegalArgumentException if freeMEmory is < 0
     */
    public void setFreeMem(long freeMem) {
        if (freeMem < 0) {
            throw new IllegalArgumentException("freeMem cannot be < 0)");
        }
        this.freeMem = freeMem;
    }
    
    /**
     * Returns the number of available item IDs (>= 0)
     *
     * @return the number of available item IDs (>= 0)
     *
     */
    public long getFreeID() {
        return freeID;
    }
    
    /**
     * Sets the freeID property.
     *
     * @param freeID the freeIDCount value (>= 0)
     *
     * @throws IllegalArgumentException if freeIDCount is < 0
     */
    public void setFreeID(long freeID) {
        if (freeID < 0) {
            throw new IllegalArgumentException("freeID cannot be < 0)");
        }
        this.freeID = freeID;
    }
}