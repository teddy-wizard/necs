/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This class represents the &lt;Sequence&gt; tag as defined by the SyncML
 * representation specifications.
 * A sequence can contain the following commands: Add, Replace, Delete, Copy,
 * Atomic, Map, Sync.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Sequence.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 *
 */
public final class Sequence
extends AbstractCommand
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static String COMMAND_NAME = "Sequence";
    
    // ------------------------------------------------------------ Private data
    
    private ArrayList commands = new ArrayList();
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Sequence() {}
    
    /**
     * Create a new Sequence object. The commands in <i>commands</i>
     * must be of the allowed types.
     *
     * @param cmdid command identifier - NOT NULL
     * @param noResponse is &lt;NoREsponse/&gt; required?
     * @param meta meta information
     * @param commands the sequenced commands - NOT NULL
     *
     * @throws java.lang.IllegalArgumentException is any of the parameters is invalid
     *
     */
    public Sequence(
               final CmdID             cmdid     ,
               final boolean           noResp    ,
               final Meta              meta      ,
               final AbstractCommand[] commands  ) {
        super(cmdid, noResp);

        setMeta(meta);
        setCommands(commands);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Gets an array of AbstractCommand
     *
     * @return an array of command objects
     */
    public ArrayList getCommands() {
        return this.commands;
    }
    
    /**
     * Sets the sequenced commands. The given commands must be of the allowed
     * types.
     *
     * @param commands the commands - NOT NULL and o the allawed types
     *
     * @throws IllegalArgumentException if the constraints are not met
     */
    public void setCommands(AbstractCommand[] commands) {
        if (commands == null) {
            throw new IllegalArgumentException("commands cannot be null");
        }
        
        for (int i = 0; i < commands.length; i++) {
            if (commands[i] == null) {
                throw new IllegalArgumentException("commands[" + i +"] cannot be null");
            } else if ((!(commands[i] instanceof Add))
                       && (!(commands[i] instanceof Replace))
                       && (!(commands[i] instanceof Delete))
                       && (!(commands[i] instanceof Copy))
                       && (!(commands[i] instanceof Atomic))
                       && (!(commands[i] instanceof Map))
                       && (!(commands[i] instanceof Sync))) {
                throw new IllegalArgumentException(
                    "commands[" + i + "] cannot be a " + commands[i].getName()
                );
            }
        }
        
        List c = Arrays.asList(commands);
        this.commands.addAll(c);
    }
    
    /**
     * Returns the command name
     *
     * @return the command name
     */
    public String getName() {
        return Sequence.COMMAND_NAME;
    }
}