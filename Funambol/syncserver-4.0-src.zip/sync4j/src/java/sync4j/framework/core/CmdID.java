/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the &ltCmdID&gt element specified by the
 * SyncML representation DTD
 *
 * @author Stefano Fornari @ Funambol
 *
* @version $Id: CmdID.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class CmdID
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String cmdID;

    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected CmdID() {}

    /**
     * Creates a new CmdID object with the given String cmdID
     *
     * @param cmdID the cmdID of CmdID - NOT NULL
     *
     */
    public CmdID(final String cmdID) {
        if ((cmdID == null) || (cmdID.length() == 0)) {
            throw new IllegalArgumentException("cmdID cannot be empty");
        }
        this.cmdID = cmdID;
    }

    /**
     * Creates a new CmdID object with the given numeric cmdID
     *
     * @param cmdID the cmdID of CmdID
     *
     */
    public CmdID(final long cmdID) {
        this(String.valueOf(cmdID));
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets cmdID properties
     *
     * @return cmdID properties
     */
    public String getCmdID() {
        return this.cmdID;
    }

    /**
     * Compares the string cmdID to the specified input object.
     *
     * @param object the object to be compared
     *
     * @return true if the specified input object equals the cmdID of the
     *         CmdID
     *
     */
    public boolean equals(Object object) {
        String cmdID = null;

        if (object instanceof String) {
            cmdID = (String)object;
        } else if (object instanceof CmdID) {
            cmdID = ((CmdID)object).getCmdID();
        }

        return (cmdID == null) ? false : cmdID.equals(cmdID);
    }
}