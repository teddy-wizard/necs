/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This is a base class for "command" classes
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: AbstractCommand.java,v 1.1 2004/04/13 09:37:29 luigia Exp $
 */
public abstract class AbstractCommand 
implements java.io.Serializable {
    
    // ---------------------------------------------------------- Protected data
    protected CmdID   cmdID     ;
    protected Boolean noResp    ;
    protected Meta    meta      ;
    protected Cred    credential;
    
    // ------------------------------------------------------------ Constructors
    
    /** For serialization purposes */
    protected AbstractCommand() {}

    /**
     * Create a new AbstractCommand object with the given commandIdentifier 
     * and noResponse
     *
     * @param cmdID the command identifier - NOT NULL
     * @param noResponse true if the command doesn't require a response
     *
     */
    public AbstractCommand(final CmdID cmdID, final boolean noResp) {        
        setCmdID(cmdID);
        this.noResp  = (noResp) ? new Boolean(noResp) : null;
    }    

    /**
     * Create a new AbstractCommand object with the given commandIdentifier
     *
     * @param cmdID the command identifier - NOT NULL
     *
     */
    public AbstractCommand(final CmdID cmdID) {
        this(cmdID, false);
    }

    // ---------------------------------------------------------- Public methods
    /**
     * Get CommandIdentifier property
     *
     * @return the command identifier - NOT NULL
     */
    public CmdID getCmdID() {
        return this.cmdID;
    }
    
    /**
     * Sets the CommandIdentifier property
     *
     * @param cmdID the command identifier
     *
     */
    public void setCmdID(CmdID cmdID) {
        if (cmdID == null) {
            throw new IllegalArgumentException("cmdID cannot be null");
        }
        this.cmdID = cmdID;
    }

    /**
     * Gets noResp property
     *
     * @return true if the command doesn't require a response, false otherwise
     */
    public boolean isNoResp() {
        return (noResp != null);
    }

    public Boolean getNoResp() {
        if (!noResp.booleanValue()) {
            return null;
        }
        return noResp;
    }
    
    /**
     * Sets noResp true if no response is required
     * 
     * @param noResponse is true if no response is required
     *
     */
    public void setNoResp(Boolean noResp) {
        this.noResp = noResp;
    }
    
    /**
     * Gets Credential object
     *
     * @return the Credential object
     */    
    public Cred getCred() {
        return credential;
    }
    
    /**
     * Sets authentication credential
     * 
     * @param cred the authentication credential
     *
     */
    public void setCred(Cred cred) {
        this.credential = cred;
    }
    
    /**
     * Gets an Meta object
     *
     * @return an Meta object
     */
    public Meta getMeta() {
        return meta;
    }
    
    /**
     * Sets Meta object
     * 
     * @param meta the meta object
     *
     */
    public void setMeta(Meta meta) {
        this.meta = meta;
    }
    
    /**
     * Get name property
     *
     * @return the name of the command
     */
    public abstract String getName();
}