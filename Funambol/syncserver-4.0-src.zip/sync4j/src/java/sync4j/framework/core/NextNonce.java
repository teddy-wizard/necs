/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import sync4j.framework.tools.Base64;

/**
 * Corresponds to &ltNextNonce&gt tag that specifies the nonce string to be 
 * used in any subsequent communication
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: NextNonce.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class NextNonce
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data

    private String value;
    
    // ------------------------------------------------------------ Constructors
    /**
     * For serialization purposes
     */
    protected NextNonce() {}

    /**
     * Creates a new NextNonce object with the given information
     *
     * @param value the value of next nonce NOT NULL
     * @param bBase64Encoded is true if value is already Base64 encoded
     *
     */
    public NextNonce(final String value, final boolean bBase64Encoded) {
        this.value = value;
        if (value == null) {
            throw new IllegalArgumentException("value cannot be null");
        }
    }

    // ---------------------------------------------------------- Public methods
    
    /**
     * Gets the value
     * 
     * @return value
     */
    public String getValue() {
        return value;
    }

    /**
     * Gets the value in Base64 encoded
     *
     * @return the value in Base64 encoded form
     */
    public String getValueAsBase64() {        
        byte[] encoded = Base64.encode(value.getBytes());
        return new String(encoded);
    }
}