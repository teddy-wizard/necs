/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import sync4j.framework.core.*;

/**
 * Corresponds to the &ltSyncHdr&gt element in the SyncML represent DTD
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @see    SyncBody
 *
 *  @version $Id: SyncHdr.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public class SyncHdr
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data

    private VerDTD    verDTD   ;
    private VerProto  verProto ;
    private SessionID sessionID;
    private String    msgID    ;
    private Target    target   ;
    private Source    source   ;
    private String    respURI  ;
    private Boolean   noResp   ;
    private Cred      cred     ;
    private Meta      meta     ;

    // ------------------------------------------------------------ Constructors

    /** For serialization purposes */
    protected SyncHdr(){}

    /**
     * Creates a nee SyncHdr object
     *
     * @param verDTD SyncML DTD version - NOT NULL
     * @param verProto SyncML protocol version - NOT NULL
     * @param sessionID sync session identifier - NOT NULL
     * @param msgID message ID - NOT NULL
     * @param target target URI - NOT NULL
     * @param source source URI - NOT NULL
     * @param respURI may be null.
     * @param noResp true if no response is required
     * @param cred credentials. May be null.
     * @param meta may be null.
     *
     */
    public SyncHdr(final VerDTD verDTD,
                   final VerProto verProto,
                   final SessionID sessionID,
                   final String msgID,
                   final Target target,
                   final Source source,
                   final String respURI,
                   final boolean noResp,
                   final Cred cred,
                   final Meta meta) {

        setMsgID(msgID);
        setVerDTD(verDTD);
        setVerProto(verProto);
        setSessionID(sessionID);
        setTarget(target);
        setSource(source);

        this.noResp  = (noResp) ? new Boolean(noResp) : null;
        this.respURI = respURI;

        this.cred = cred;
        this.meta = meta;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the DTD version
     *
     * @return verDTD the DTD version
     */
    public VerDTD getVerDTD() {
        return verDTD;
    }

    /**
     * Sets the DTD version
     *
     * @param verDTD the DTD version
     *
     */
    public void setVerDTD(VerDTD verDTD) {
        if (verDTD == null) {
            throw new IllegalArgumentException("verDTD cannot be null");
        }
        this.verDTD = verDTD;
    }

    /**
     * Gets the protocol version
     *
     * @return verProto the protocol version
     */
    public VerProto getVerProto() {
        return verProto;
    }

    /**
     * Sets the protocol version
     *
     * @param verProto the protocol version
     */
    public void setVerProto(VerProto verProto) {
        if (verProto == null) {
            throw new IllegalArgumentException("verProto cannot be null");
        }
        this.verProto = verProto;
    }

    /**
     * Gets the session identifier
     *
     * @return sessionID the session identifier
     */
    public SessionID getSessionID() {
        return sessionID;
    }

    /**
     * Sets the session identifier
     *
     * @param sessionID the session identifier
     *
     */
    public void setSessionID(SessionID sessionID) {
        if (sessionID == null) {
            throw new IllegalArgumentException("sessionID cannot be null");
        }
        this.sessionID = sessionID;
    }

    /**
     * Gets the message identifier
     *
     * @return msgID the message identifier
     */
    public String getMsgID() {
        return msgID;
    }

    /**
     * Sets the message identifier
     *
     * @param msgID the message identifier
     */
    public void setMsgID(String msgID) {
        if (msgID == null || msgID.length() == 0) {
            throw new IllegalArgumentException(
                                          "msgID cannot be null or empty");
        }
        this.msgID = msgID;
    }

    /**
     * Gets the Target object
     *
     * @return target the Target object
     */
    public Target getTarget() {
        return target;
    }

    /**
     * Sets the Target object
     *
     * @param target the Target object
     */
    public void setTarget(Target target) {
        if (target == null) {
            throw new IllegalArgumentException("target cannot be null");
        }
        this.target = target;
    }

    /**
     * Gets the Source object
     *
     * @return source the Source object
     */
    public Source getSource() {
        return source;
    }

    /**
     * Sets the Source object
     *
     * @param source the Source object
     */
    public void setSource(Source source) {
        if (source == null) {
            throw new IllegalArgumentException("source cannot be null");
        }
        this.source = source;
    }

    /**
     * Gets the response URI
     *
     * @return respURI the response URI
     */
    public String getRespURI() {
        return respURI;
    }

    /**
     * Sets the response URI.
     *
     * @param uri the new response URI; NOT NULL
     */
    public void setRespURI(String uri) {
        this.respURI = uri;
    }

    /**
     * Gets noResp property
     *
     * @return true if the command doesn't require a response, false otherwise
     */
    public boolean isNoResp() {
        return (noResp != null);
    }

    /**
     * Gets the Boolean value of noResp
     *
     * @return true if the command doesn't require a response, null otherwise
     */
    public Boolean getNoResp() {
        if (!noResp.booleanValue()) {
            return null;
        }
        return noResp;
    }

    /**
     * Sets the noResponse property
     *
     * @param noResp the noResponse property
     */
    public void setNoResp(Boolean noResp) {
        this.noResp = noResp;
    }

    /**
     * Gets the Credential property
     * 
     * @return cred the Credential property
     */
    public Cred getCred() {
        return cred;
    }

    /**
     * Sets the Credential property
     * 
     * @param cred the Credential property
     */
    public void setCred(Cred cred) {
        this.cred = cred;
    }

    /**
     * Gets the Meta property
     * 
     * @return meta the Meta property
     */
    public Meta getMeta() {
        return meta;
    }

    /**
     * Sets the Meta property
     * 
     * @param meta the Meta property
     */
    public void setMeta(Meta meta) {
        this.meta = meta;
    }
}