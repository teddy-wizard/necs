/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This class represents the content type property such as property name, value,
 * display name, size and the content type parameters
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: CTPropParam.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class CTPropParam
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String propName;
    private ArrayList valEnum = new ArrayList();
    private String displayName;
    private String dataType;
    private int size;
    private ArrayList ctParameters = new ArrayList();
    
    // ------------------------------------------------------------ Constructors
    
    /** For serialization purposes */
    protected CTPropParam() {}

    /**
     * Creates a new ContentTypeProperty object with the given name, value and
     * display name
     *
     * @param propName corresponds to &ltPropName&gt element in the SyncML 
     *                  specification - NOT NULL
     * @param valEnum   corresponds to &ltValEnum&gt element in the SyncML 
     *                  specification
     * @param displayName corresponds to &ltDisplayName&gt element in the SyncML 
     *                  specification
     * @param ctParameters the array of content type parameters - NOT NULL
     *
     */
    public CTPropParam(final String propName,
                       final String[] valEnum,
                       final String displayName,
                       final ContentTypeParameter[] ctParameters) {
        setPropName(propName);
        setValEnum(valEnum);
        setContentTypeParameters(ctParameters);
        
        this.displayName  = displayName;
    }

    
    /**
     * Creates a new ContentTypeProperty object with the given name, value and
     * display name
     *
     * @param propName corresponds to &ltPropName&gt element in the SyncML 
     *                  specification - NOT NULL
     * @param valEnum   corresponds to &ltValEnum&gt element in the SyncML 
     *                  specification
     * @param displayName corresponds to &ltDisplayName&gt element in the SyncML 
     *                  specification
     * @param ctParameters the array of content type parameters - NOT NULL
     *
     */
    public CTPropParam(final String propName,
                       final String dataType,
                       final int size,
                       final String displayName,
                       final ContentTypeParameter[] ctParameters) {
        
        setPropName(propName);
        setContentTypeParameters(ctParameters);
        
        this.dataType     = dataType;
        this.size         = size;
        this.displayName  = displayName;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the property name
     *
     * @return the property name
     */
    public String getPropName() {
        return propName;
    }
    
    /**
     * Sets the property name
     *
     * @param propName the property name
     */
    public void setPropName(String propName) {
        if (propName == null){
            throw new IllegalArgumentException("propName cannot be null");
        }
        this.propName = propName;
    }
    
    /**
     * Gets the array of value for the property
     *
     * @return the array of value for the property
     */
    public ArrayList getValEnum() {
        return this.valEnum;
    }
    
    /**
     * Sets the array of enumerated value property
     *
     * @param valEnum the array of enumerated value property
     */
    public void setValEnum(String[] valEnum) {
        if (valEnum != null) {
            List c = Arrays.asList(valEnum);
            this.valEnum.addAll(c);
        }
    }
    
    /**
     * Gets the display name property
     *
     * @return the display name property
     */
    public String getDisplayName() {
        return displayName;
    }
    
    /**
     * Sets the display name of a given content type property
     *
     * @param displayName the display name of a given content type property
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    
    /**
     * Gets the data type propeties
     *
     * @return the data type propeties
     */
    public String getDataType() {
        return dataType;
    }
    
    /**
     * Sets the data type of a given content type property
     *
     * @param dataType the data type of a given content type property
     */
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    /**
     * Gets the size propeties
     *
     * @return the size propeties
     */
    public int getSize() {
        return size;
    }

    /**
     * Sets the size of a given content type property
     *
     * @param size the size of a given content type property
     *
     */
    public void setSize(int size) {
        this.size = size;
    }
    
    /**
     * Gets the array of ContentTypeParameter
     *
     * @return the size propeties
     */
    public ArrayList getContentTypeParameters() {
        return this.ctParameters;
    }
    
    /**
     * Sets an array of content type properties
     *
     * @param an array of content type properties
     *
     */
    public void setContentTypeParameters(ContentTypeParameter[] ctParameters) {
        if (ctParameters != null) {
            List c = Arrays.asList(ctParameters);
            this.ctParameters.addAll(c);
        }
    }
}