/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the &ltItem&gt tag ias defined by the SyncML
 * representation specifications
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Item.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public class Item
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data
    private Target target;
    private Source source;
    private Meta meta;
    private ComplexData data;

    // ------------------------------------------------------------ Constructors

    protected Item() {}
    
    /**
     * Creates a new Item object.
     *
     * @param target item target - NULL ALLOWED
     * @param source item source - NULL ALLOWED
     * @param meta item meta data - NULL ALLOWED
     * @param data item data - NULL ALLOWED
     *
     */
    public Item(final Target target,
                final Source source,
                final Meta   meta  ,
                final ComplexData   data  ) {
        this.target = target;
        this.source = source;
        this.meta   = meta  ;
        this.data   = data  ;
    }

    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the item target
     *
     * @return the item target
     */
    public Target getTarget() {
        return target;
    }
    
    /**
     * Sets the item target
     *
     * @param target the target
     *
     */
    public void setTarget(Target target) {
        this.target = target;
    }
    
    /**
     * Returns the item source
     *
     * @return the item source
     */
    public Source getSource() {
        return source;
    }
    
    /**
     * Sets the item source
     *
     * @param source the source
     *
     */
    public void setSource(Source source) {
        this.source = source;
    }
    
    /**
     * Returns the item meta element
     *
     * @return the item meta element
     */
    public Meta getMeta() {
        return meta;
    }
    
    /**
     * Sets the meta item
     *
     * @param meta the item meta element
     *
     */
    public void setMeta(Meta meta) {
        this.meta = meta;
    }

    /**
     * Returns the item data
     *
     * @return the item data
     *
     */
    public ComplexData getData() {
        return data;
    }
    
    /**
     * Sets the item data
     *
     * @param data the item data
     *
     */
    public void setData(ComplexData data) {
        this.data = data;
    }
}