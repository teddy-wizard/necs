/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

import sync4j.framework.core.RepresentationException;

/**
 * This class contains the information on CTCap
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: CTTypeSupported.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class CTTypeSupported
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data
    private CTType ctType;
    private ArrayList ctPropParams = new ArrayList();
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected CTTypeSupported() {}
    
    /**
     * Creates a new CTTypeSupported object with the given information
     *
     * @param ctType an object CTType - NOT NULL
     * @param ctPropParams the array of content type properties and/or content
     *                     content type parameters - NOT NULL
     *
     */
    public CTTypeSupported(final CTType ctType,
                           final CTPropParam[] ctPropParams ) {
        setCTType(ctType);
        setCTPropParams(ctPropParams);
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Get a CTType object
     *
     * @return a CTType object
     */
    public CTType getCTType() {
        return this.ctType;
    }
    
    /**
     * Sets a CTType object
     *
     * @param ctType a CTType object
     */
    public void setCTType(CTType ctType) {
        if (ctType == null) {
            throw new IllegalArgumentException("ctType cannot be null");
        }
        
        this.ctType = ctType;
    }
    
    /**
     * Gets an array of content type properties and parameters
     *
     * @return an array of content type properties and parameters
     *
     */
    public ArrayList getCTPropParams() {
        return this.ctPropParams;
    }
    
    /**
     * Sets an array of content type properties and parameters
     *
     * @param an array of content type properties and parameters
     *
     */
    public void setCTPropParams(CTPropParam[] ctPropParams) {
        if (ctPropParams == null) {
            throw new IllegalArgumentException("ctPropParams cannot be null");
        }
        List c = Arrays.asList(ctPropParams);
        this.ctPropParams.addAll(c);
    }
}