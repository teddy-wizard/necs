/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the content type information such as content type and 
 * version of content type
 * 
 *  @author Stefano Fornari @ Funambol
 *
 *  @verCT $Id: ContentTypeInfo.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public class ContentTypeInfo
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String ctType;
    private String verCT;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected ContentTypeInfo() {}

    /**
     * Creates a new ContentTypeCapability object with the given content type 
     * and versione
     *
     * @param ctType corresponds to &ltCTType&gt element in the SyncML 
     *                    specification - NOT NULL
     * @param verCT corresponds to &ltVerCT&gt element in the SyncML 
     *                specification - NOT NULL
     *
     */
    public ContentTypeInfo(final String ctType, final String verCT) {
        if (ctType == null || ctType.length() == 0){
            throw new IllegalArgumentException("ctType cannot be null");
        }
        
        if (verCT == null || verCT.length() == 0){
            throw new IllegalArgumentException("verCT cannot be null");
        }        
        this.ctType = ctType;
        this.verCT = verCT;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the content type properties
     *
     * @return the content type properties
     */
    public String getCTType() {
        return ctType;
    }
    
    /**
     * Sets the content type properties
     *
     * @param ctType the content type properties
     */
    public void setCTType(String ctType) {
        this.ctType = ctType;
    }

    /**
     * Gets the version of the content type
     *
     * @return the version of the content type
     */
    public String getVerCT() {
        return verCT;
    }

    /**
     * Sets the version of the content type
     *
     * @param verCT the version of the content type
     */
    public void setVerCT(String verCT) {
        this.verCT = verCT;
    }
}