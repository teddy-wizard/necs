/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

import sync4j.framework.core.RepresentationException;

/**
 * This class represents the &lt;SyncML&gt; tag as defined by the SyncML r
 * epresentation specifications.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: SyncML.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public final class SyncML
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    
    private SyncHdr  header;
    private SyncBody body;
    private boolean  lastMessage;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected SyncML(){};
        
    /**
     * Creates a new SyncML object from header and body.
     *
     * @param syncHdr the SyncML header - NOT NULL
     * @param syncBody the SyncML body - NOT NULL
     * @param last is the last SyncML of a session ?
     *
     */
    public SyncML(final SyncHdr  header,
                  final SyncBody body,
                  final boolean  last) 
    throws RepresentationException {
        
        setSyncHdr(header);
        setSyncBody(body);
        
        this.lastMessage = last;
    }
    
    /**
     * The same as SyncML(header, body, false).
     *
     * @param header the SyncML header - NOT NULL
     * @param body the SyncML body - NOT NULL
     *
     */
    public SyncML(final SyncHdr header, final SyncBody body) 
    throws RepresentationException {
        this(header, body, false);
    }

    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the SyncML header
     *
     * @return the SyncML header
     *
     */
    public SyncHdr getSyncHdr() {
        return header;
    }
    
    /**
     * Sets the SyncML header
     *
     * @param header the SyncML header - NOT NULL
     *
     * @throws IllegalArgumentException if header is null
     */
    public void setSyncHdr(SyncHdr header) {
        if (header == null) {
            throw new IllegalArgumentException("header cannot be null");
        }
        this.header = header;
    }
    
    /**
     * Returns the SyncML body
     *
     * @return the SyncML body
     *
     */
    public SyncBody getSyncBody() {
        return body;
    }
    
    /**
     * Sets the SyncML body
     *
     * @param body the SyncML body - NOT NULL
     *
     * @throws IllegalArgumentException if body is null
     */
    public void setSyncBody(SyncBody body) {
        if (body == null) {
            throw new IllegalArgumentException("body cannot be null");
        }
        this.body = body;
    }
    
    /**
     * Returns lastMessage
     *
     * @return lastMessage
     */
    public boolean isLastMessage() {
        return lastMessage;
    }
    
    /**
     * Sets lastMessage
     *
     * @param lastMessage the new lastMessage value
     *
     */
    public void setLastMessage(boolean lastMessage) {
        this.lastMessage = lastMessage;
    }  
}