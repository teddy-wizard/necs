/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This class represents the &lt;Map&gt; tag as defined by the SyncML r
 * epresentation specifications.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Map.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 *
 */
public final class Map
extends AbstractCommand
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static String COMMAND_NAME = "Map";
    
    // ------------------------------------------------------------ Private data
    
    private Target    target;
    private Source    source;
    private ArrayList mapItems = new ArrayList();
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    protected Map() {}
    
    /**
     * Creates a new Map commands from its constituent information.
     *
     * @param cmdID command identifier - NOT NULL
     * @param target the target - NOT NULL
     * @param source the source - NOT NULL
     * @param cred authentication credential - NULL ALLOWED
     * @param meta the associated meta data - NULL ALLOWED
     * @param mapItems the mapping items - NOT NULL
     *
     */
    public Map(final CmdID cmdID,
               final Target target,
               final Source source,
               final Cred credential,
               final Meta meta,
               final MapItem[] mapItems) {

        super(cmdID);
        setMeta(meta);
        setCred(credential);
        
        setTarget  (target  );
        setSource  (source  );
        setMapItems(mapItems);
    }   
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the target property
     * @return the target property
     *
     */
    public Target getTarget() {
        return target;
    }
    
    /**
     * Sets the target property
     *
     * @param target the target - NOT NULL
     *
     * @throws IllegalArgumentException if target is null
     */
    public void setTarget(Target target) {
        if (target == null) {
            throw new IllegalArgumentException("target cannot be null");
        }
        
        this.target = target;
    }
    
    /**
     * Returns the source property
     * @return the source property
     *
     */
    public Source getSource() {
        return source;
    }
    
    /**
     * Sets the source property
     *
     * @param source the source - NOT NULL
     *
     * @throws IllegalArgumentException if source is null
     */
    public void setSource(Source source) {
        if (source == null) {
            throw new IllegalArgumentException("source cannot be null");
        }
        this.source = source;
    }
    
    /**
     * Returns the map items
     *
     * @return the map items
     *
     */
    public ArrayList getMapItems() {
        return mapItems;
    }
    
    /**
     * Sets the mapItems property
     *
     * @param mapItems the map items - NOT NULL
     *
     * @throws IllegalArgumentException if mapItems is null
     */
    public void setMapItems(MapItem[] mapItems) {
        if (mapItems == null) {
            throw new IllegalArgumentException("mapItems cannot be null");
        }
        List c = Arrays.asList(mapItems);
        this.mapItems.addAll(c);
    }
       
    /**
     * Returns the command name
     *
     * @return the command name
     */
    public String getName() {
        return Map.COMMAND_NAME;
    }
}