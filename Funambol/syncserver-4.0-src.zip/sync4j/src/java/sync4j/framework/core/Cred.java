/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import sync4j.framework.core.Constants;

/**
 *
 *  Corresponds to &ltCred&gt element in SyncML represent DTD
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @see AuthenticationChallenge
 *
 *  @version $Id: Cred.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Cred
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private Authentication authentication;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected Cred() {}
    
    /**
     * Creates a new Cred object with the given Authentication
     *
     * @param authentication the authentication object - NOT NULL
     *        This parameter will usually be an instance of 
     *        BasicAuthentication or ClearAuthentication
     *
     */
    public Cred(final Authentication authentication) {
        if (authentication == null) {
            throw new IllegalArgumentException("authentication cannot be null");
        }        
        this.authentication = authentication;
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Gets type property
     *
     * @return type property
     */
    public String getType() {
        return authentication.getType();
    }
        
    /**
     * Gets format property
     *
     * @return format property
     */
    public String getFormat() {
        return authentication.getFormat();
    }
    
    /**
     * Gets data property
     *
     * @return data property
     */
    public String getData() {
        return authentication.getData();
    }
    
    /**
     * Gets the username stored in this credential
     *
     * @return the username stored in this credential
     */
    public String getUsername() {
        return authentication.getUsername();
    }
    
   
    /**
     * Creates and returns the credential for "guest" user
     *
     * @return the credential for "guest" user 
     */
    public static Cred getGuestCredential() {
        String guest = "guest:guest";
        
        return new Cred(
                    createAuthentication(guest, Constants.AUTH_TYPE_CLEAR)
                   );
    }
    
    /**
     * Create and return the Authentication object corresponding to the given
     * type and data.
     *
     * @param type the type of the required Authentication object
     * @param data the data to be interpreted based on the type
     *
     * @return the corresponding Authentication object.
     */
    public static Authentication createAuthentication(String data,
                                                      String type) {
        
        return new Authentication(type,data);
    }    
}