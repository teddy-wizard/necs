/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * Corresponds to the &ltData&gt tag in the SyncML represent DTD when delivering
 * an Anchor
 *  
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: ComplexData.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class ComplexData
extends Data 
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private Anchor anchor;
    private DevInf devInf;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    public ComplexData() {}
    
    /**
     * Creates a Data object from the given anchors string.
     *
     * @param last the last anchor
     * @param next the next anchor - NOT NULL
     *
     */
    public ComplexData(String data) {
        super(data);
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Gets the Anchor object property
     * 
     * @return anchor the Anchor object
     */
    public Anchor getAnchor() {
        return anchor;
    }
    
    /**
     * Sets the Anchor object property
     *
     * @param anchor the Anchor object
     */
    public void setAnchor(Anchor anchor) {
        if (null == anchor) {
            throw new IllegalArgumentException("anchor cannot be null");
        }        
        this.anchor = anchor;
    }

    /**
     * Gets the DevInf object property
     *
     * @return devInf the DevInf object property
     */
    public DevInf getDevInf() {
        return devInf;
    }
    
    /**
     * Sets the DevInf object property
     *
     * @param devInf the DevInf object property
     *
     */
    public void setDevInf(DevInf devInf) {
        if (null == devInf) {
            throw new IllegalArgumentException("devInf cannot be null");
        }        
        this.devInf = devInf;
    }
}