/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This class represents the content type parameter such as paramName, valEnum,
 * displayName or data type
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: ContentTypeParameter.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class ContentTypeParameter
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String paramName;
    private ArrayList valEnum = new ArrayList();
    private String displayName;
    private String dataType;
    private int size;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    private ContentTypeParameter() {}
    
    /**
     * Creates a new ContentTypeParameter object with the given name, value and
     * display name
     *
     * @param paramName corresponds to &ltParamName&gt element in the SyncML 
     *                  specification - NOT NULL
     * @param valEnum   corresponds to &ltValEnum&gt element in the SyncML 
     *                  specification
     * @param displayName corresponds to &ltDisplayName&gt element in the SyncML 
     *                  specification
     *
     */
    public ContentTypeParameter(final String paramName,
                                final String[] valEnum,
                                final String displayName) {                                    
        setParamName(paramName);
        setValEnum(valEnum);
        
        this.displayName = displayName;
    }

    /**
     * Creates a new ContentTypeParameter object with the given name, data type,
     * size, display name
     *
     * @param paramName corresponds to &ltParamName&gt element in the SyncML 
     *                  specification - NOT NULL
     * @param dataType  corresponds to &ltDataType&gt element in the SyncML 
     *                  specification
     * @param size      corresponds to &ltSize&gt element in the SyncML 
     *                  specification
     * @param displayName corresponds to &ltDisplayName&gt element in the SyncML 
     *                  specification
     *
     */
    public ContentTypeParameter(final String paramName,
                                final String dataType,
                                final int size,
                                final String displayName) {
        setParamName(paramName);
        
        this.dataType    = dataType;
        this.size        = size;
        this.displayName = displayName;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the parameter name propeties
     *
     * @return the parameter name propeties
     */
    public String getParamName() {
        return paramName;
    }
    
    /**
     * Sets the param name property
     *
     * @param paramName the param name property
     */
    public void setParamName(String paramName) {
        if (paramName == null){
            throw new IllegalArgumentException("paramName cannot be null");
        }
        this.paramName = paramName;
    }
    
    /**
     * Gets the array of value for parameter
     *
     * @return the array of value for parameter
     */
    public ArrayList getValEnum() {
        return this.valEnum;
    }
    
    /**
     * Sets the array of enumerated value property
     *
     * @param valEnum the array of enumerated value property
     */
    public void setValEnum(String[] valEnum) {
        if (valEnum != null) {
            List c = Arrays.asList(valEnum);
            this.valEnum.addAll(c);
        }
    }
    
    /**
     * Gets the display name propeties
     *
     * @return the display name propeties
     */
    public String getDisplayName() {
        return displayName;
    }
    
    /**
     * Sets the display name of a given content type parameter
     *
     * @param displayName the display name of a given content type parameter
     *
     */
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    
    /**
     * Gets the data type propeties
     *
     * @return the data type propeties
     */
    public String getDataType() {
        return dataType;
    }
    
    /**
     * Sets the data type of a given content type parameter
     *
     * @param dataType the data type of a given content type parameter
     *
     */
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    
    /**
     * Gets the size propeties
     *
     * @return the size propeties
     */
    public int getSize() {
        return size;
    }
    
    /**
     * Sets the size of a given content type parameter
     *
     * @param size the size of a given content type parameter
     *
     */
    public void setSize(int size) {
        this.size = size;
    }
}