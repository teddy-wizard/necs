/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;


/**
 * This class corresponds to the &ltEMI&gt element in the SyncML metainfo DTD
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: EMI.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class EMI
implements java.io.Serializable {
    // ------------------------------------------------------------ Private data
    private String value;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected EMI() {}

    /** 
     * Creates a new EMI object with the given value
     *
     * @param value the experimental Meta info value - NOT NULL
     *
     */
    public EMI(final String value) {
        setValue(value);
    }

    // ---------------------------------------------------------- Public methods
    /**
     * Gets the value of experimental meta information
     * 
     * @return the value of experimental meta information
     */
    public String getValue() {
        return value;
    }
    
    /**
     * Sets the value of experimental meta information
     *
     * @param value the value of experimental meta information
     *
     */
    public void setValue(String value) {
        if (value == null || value.trim().length() == 0) {
            throw new IllegalArgumentException("value cannot be null or empty");
        }        
        this.value = value;
    }
}