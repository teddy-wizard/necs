/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This class corresponds to the &ltCTType&gt tag in the SyncML devinf DTD
 *
 * @see CTCap
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: CTType.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class CTType
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String ctType;    

    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected CTType() {}

    /**
     * Creates a new CTType object with the given content type and an array 
     * of content type properties
     *
     * @param ctType the content type - NOT NULL
     *
     */
    public CTType(final String ctType) {
        setCTType(ctType);        
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the content type property
     *
     * @return the content type property
     */
    public String getCTType(){
        return ctType;
    }
    
    /**
     * Sets an array of CTType object
     *
     * @param ctTypes an array of CTType object
     */
    public void setCTType(String ctType) {
        if (ctType == null || ctType.length() == 0) {
            throw new IllegalArgumentException("ctType cannot be null");
        }
        this.ctType = ctType;
    }
}