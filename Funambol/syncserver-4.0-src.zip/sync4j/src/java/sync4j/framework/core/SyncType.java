/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;


/**
 * This class corresponds to &ltSyncType&gt tag in SyncML devinfo DTD
 *
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: SyncType.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public final class SyncType 
implements java.io.Serializable {
    // --------------------------------------------------------------- Constants
    
    public static final SyncType TWO_WAY             = new SyncType(1);
    public static final SyncType SLOW                = new SyncType(2);
    public static final SyncType ONE_WAY_FROM_CLIENT = new SyncType(3);
    public static final SyncType REFRESH_FROM_CLIENT = new SyncType(4);
    public static final SyncType ONE_WAY_FROM_SERVER = new SyncType(5);
    public static final SyncType REFRESH_FROM_SERVER = new SyncType(6);
    public static final SyncType SERVER_ALERTED      = new SyncType(7);
    
    public static final SyncType[] ALL_SYNC_TYPES = new SyncType[] {
        TWO_WAY, SLOW, ONE_WAY_FROM_CLIENT, REFRESH_FROM_CLIENT,
        ONE_WAY_FROM_SERVER, REFRESH_FROM_SERVER, SERVER_ALERTED
    };
    
    // ------------------------------------------------------------ Private data
    private int syncType;
    
    // ------------------------------------------------------------ Constructors

    /** For serialization purposes */
    protected SyncType() {}

    /**
     * Creates a new SyncType object with syncType value
     *
     * @param syncType the value of SyncType - NOT NULL
     *
     */
    public SyncType(final int syncType) {
        setType(syncType);
    }
    
    // ---------------------------------------------------------- Public methods

    /**
     * Gets the synchronization type
     *
     * @return syncType the synchronization type
     */
    public int getType() {
        return syncType;
    }
    
    /**
     * Sets the synchronization type
     *
     * @param syncType the synchronization type
     */
    public void setType(int syncType) {
        this.syncType = syncType;
    }

    /**
     * Gets the instance of synchronization type
     *
     * @return syncType the synchronization type
     */
    public static final SyncType getInstance(final int syncType) {
        if ((syncType < 0) || (syncType >= ALL_SYNC_TYPES.length)) {
            throw new IllegalArgumentException("unknown syncType: " + syncType);
        }
        return ALL_SYNC_TYPES[syncType-1];
    }
}