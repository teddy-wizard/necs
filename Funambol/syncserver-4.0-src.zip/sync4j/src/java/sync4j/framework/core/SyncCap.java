/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;


/**
 * This class represents the synchronization capabilities of a datastore and 
 * corresponds to the &ltSyncCap&gt tag in the SyncML devinf DTD
 *
 *  @see DataStore
 *  @author Stefano Fornari @ Funambol
 *
 *  @version $Id: SyncCap.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public final class SyncCap
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    private ArrayList syncTypes = new ArrayList();
    
    // ------------------------------------------------------------ Constructors

    /** For serialization purposes */
    protected SyncCap(){}

    /**
     * Creates a new SyncCap object that specifies the synchronization 
     * capabilities of the given datastore
     *
     * @param syncTypes an array of type of the supported 
     *                  synchronization - NOT NULL
     *
     */
    public SyncCap(final SyncType[] syncTypes) {
        setSyncType(syncTypes);
    }

    // ---------------------------------------------------------- Public methods
    
    /**
     *
     * @return The return value is guaranteed to be non-null.
     *      Also, the array's elements are guaranteed to
     *      be non-null.
     *
     */
    public ArrayList getSyncType() {
        return syncTypes;
    }

    public void setSyncType(SyncType[] syncTypes) {
        if (syncTypes == null || syncTypes.length == 0) {
            throw new IllegalArgumentException(
                                           "syncTypes cannot be null or empty");
        }        
        List c = Arrays.asList(syncTypes);
        this.syncTypes.addAll(c);
    }
}