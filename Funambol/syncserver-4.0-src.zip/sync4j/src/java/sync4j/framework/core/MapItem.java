/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * This class represents the &ltMapItem&gt tag as defined by the SyncML r
 * epresentation specifications.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: MapItem.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 *
 */
public final class MapItem
implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    
    private Target target;
    private Source source;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * This is for serialization purposes
     */
    protected MapItem() {}
    
    /**
     * Creates a MapItem object from its target and source.
     *
     *  @param target the mapping target - NOT NULL
     *  @param source the mapping source - NOT NULL
     *
     *  @throws IllegalArgumentException if any parameter is null
     *
     */
    public MapItem(final Target tartget, final Source source) {
        setTarget(target);
        setSource(source);
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the MapItem's target
     *
     * @return Tthe MapItem's target
     *
     */
    public Target getTarget() {
        return target;
    }
    
    /**
     * Sets the MapItem's target
     *
     * @param target he MapItem's target - NOT NULL
     *
     * @throws IllegalArgumentException if target is null
     */
    public void setTarget(Target target) {
        if (target == null) {
            throw new IllegalArgumentException("target cannot be null");
        }
        this.target = target;
    }
    
    /**
     * Returns the MapItem's source
     *
     * @return Tthe MapItem's source
     *
     */
    public Source getSource() {
        return source;
    }
    
    /**
     * Sets the MapItem's source
     *
     * @param source he MapItem's source - NOT NULL
     *
     * @throws IllegalArgumentException if source is null
     */
    public void setSource(Source source) {
        if (source == null) {
            throw new IllegalArgumentException("source cannot be null");
        }
        this.source = source;
    }    
}