/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * This class represents the &lt;Meta&gt; tag as defined by the SyncML 
 * representation specifications.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Meta.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 *
 */
public final class Meta implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    private String     format    ;
    private String     type      ;
    private String     mark      ;
    private Anchor     anchor    ;
    private String     version   ;
    private NextNonce  nextNonce ;
    private Long       maxMsgSize;
    private Long       maxObjSize;
    private Long       size      ;
    private ArrayList  emi = new ArrayList();
    private Mem        mem       ;

    // ------------------------------------------------------------ Constructors
    
    /**
     * For serialization purposes
     */
    public Meta() {
        set(
            null, 
            null, 
            null, 
            null, 
            null,
            null,
            null,
            null,
            null,
            null,
            null
        );
    }

    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns dateSize (in bytes)
     *
     * @return size
     */
    public Long getSize() {
        return size;
    }

    /**
     * Sets size
     *
     * @param size the new size value
     */
    public void setSize(Long size) {
        this.size = size;
    }
    
    /**
     * Returns format
     *
     * @return format
     */
    public String getFormat() {
        return format;
    }
    
    /**
     * Sets format
     *
     * @param format the new format value
     */
    public void setFormat(String format) {
        this.format = format;
    }
    
    /**
     * Returns type
     *
     * @return type
     */
    public String getType() {
        return type;
    }
    
    /**
     * Sets type
     *
     * @param type the new type value
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /**
     * Returns mark
     *
     * @return mark
     */
    public String getMark() {
        return mark;
    }
    
    /**
     * Sets mark
     *
     * @param mark the new mark value
     */
    public void setMark(String mark) {
        this.mark = mark;
    }
    
    /**
     * Returns anchor
     *
     * @return anchor
     */
    public Anchor getAnchor() {
        return anchor;
    }
    
    /**
     * Sets anchor
     *
     * @param anchor the new anchor value
     */
    public void setAnchor(Anchor anchor) {
        this.anchor = anchor;
    }
    
    /**
     * Returns version
     *
     * @return version
     */
    public String getVersion() {
        return version;
    }
    
    /**
     * Sets version
     *
     * @param version the new version value
     */
    public void setVersion(String version) {
        this.version = version;
    }
    
    /**
     * Returns nextNonce
     *
     * @return nextNonce
     */
    public NextNonce getNextNonce() {
        return nextNonce;
    }
    
    /**
     * Sets nextNonce
     *
     * @param nextNonce the new nextNonce value
     */
    public void setNextNonce(NextNonce nextNonce) {
        this.nextNonce = nextNonce;
    }
    
    /**
     * Returns maxMsgSize
     *
     * @return maxMsgSize
     */
    public Long getMaxMsgSize() {
        return maxMsgSize;
    }
    
    /**
     * Sets maxMsgSize
     *
     * @param maxMsgSize the new maxMsgSize value
     */
    public void setMaxMsgSize(Long maxMsgSize) {
        this.maxMsgSize = maxMsgSize;
    }
    
    /**
     * Returns maxObjSize
     *
     * @return maxObjSize
     */
    public Long getMaxObjSize() {
        return maxObjSize;
    }
    
    /**
     * Sets maObjSize
     *
     * @param maxObjSize the new maxObjSize value
     */
    public void setMaxObjSize(Long maxObjSize) {
        this.maxObjSize = maxObjSize;
    }
    
    /**
     * Returns emi
     *
     * @return emi
     */
    public ArrayList getEMI() {
        return emi;
    }
    
    /**
     * Sets emi
     *
     * @param emi the new emi value
     */
    public void setEMI(EMI[] emi) {        
        if (emi != null) {
            List c = Arrays.asList(emi);
            this.emi.addAll(c);
        }
    }

    /**
     * Returns mem
     *
     * @return mem
     */
    public Mem getMem() {
        return mem;
    }
    
    /**
     * Sets mem
     *
     * @param mem the new mem value
     */
    public void setMem(Mem mem) {
        this.mem = mem;
    }
    
    // --------------------------------------------------------- Private methods
    
    /**
     * Sets all properties in once.
     *
     * @param format the encoding format
     * @param type usually a MIME type
     * @param mark the mark element
     * @param sizeInBytes the data size in bytes
     * @param anchor the Anchor
     * @param version the data version
     * @param nonce the next nonce value
     * @param maxMsgSize the maximum message size in bytes
     * @param emi experimental meta info
     * @param memoryInfo memory information
     *
     */
    private void set(final String    format    ,
                     final String    type      ,
                     final String    mark      ,
                     final Long      size      , 
                     final Anchor    anchor    , 
                     final String    version   , 
                     final NextNonce nonce     , 
                     final Long      maxMsgSize, 
                     final Long      maxObjSize,
                     final EMI[]     emi       , 
                     final Mem       mem       ) {
        this.format     = format;
        this.type       = type;
        this.mark       = mark;
        this.anchor     = anchor;        
        this.size       = size;
        this.version    = version;
        this.nextNonce  = nonce;
        this.maxMsgSize = maxMsgSize;     
        this.maxObjSize = maxObjSize;
        this.mem        = mem;
        this.setEMI(emi);
    }
    
}