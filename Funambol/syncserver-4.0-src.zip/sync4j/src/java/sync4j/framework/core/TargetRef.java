/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;


/**
 * This class represents the &ltTargetRef&gt element as defined by the SyncML 
 * representation specifications 
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: TargetRef.java,v 1.1 2004/04/13 09:37:32 luigia Exp $
 */
public final class TargetRef 
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data

    private String value;
    private Target target;
    
    // ------------------------------------------------------------ Constructors

    /**
     * For serialization purposes
     */
    protected TargetRef() {}
    
    /**
     * Creates a new TargetRef object given the referenced value. A null value
     * is considered an empty string
     *
     * @param value the referenced value - NULL ALLOWED
     *
     * @throws IllegalArgumentException if value is null
     */
    public TargetRef(final String value) {
        setValue(value);
    }
    
    /**
     * Creates a new TargetRef object from an existing target.
     *
     * @param target the target to extract the reference from - NOT NULL
     *
     * @throws IllegalArgumentException if target is null
     *
     */
    public TargetRef(final Target target) {
        setTarget(target);
        value = target.getLocURI();
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the value
     *
     * @return the value
     */
    public String getValue() {
        return value;
    }
    
    /**
     * Sets the reference value. If value is null, the empty string is adopted.
     *
     * @param value the reference value - NULL
     */
    public void setValue(String value) {
        this.value = (value == null) ? "" : value;
    }
    
    /**
     * Gets the Target property
     *
     * @return target the Target property
     */
    public Target getTarget() {
        return this.target;
    }

    /**
     * Sets the Target property
     *
     * @param target the Target property
     */
    public void setTarget(Target target) {
        if (target == null) {
            throw new IllegalArgumentException("target cannot be null");
        }
        this.target = target;
    }
}