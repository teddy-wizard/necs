/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;


/**
 * Corresponds to the &ltAnchor&gt tag in the metainfo spec
 *
 * @author Stefano Fornari @ Funambol
 * @see    MetaInfo
 *
 * @version $Id: Anchor.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Anchor 
implements java.io.Serializable {

    // ------------------------------------------------------------ Private data
    private String last;
    private String next;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected Anchor() {}
    
    /**
     * Creates a new Anchor object
     *
     * @param last the synchronization anchor for the previous synchronization 
     *             session
     * @param next the synchronization anchor for the current synchronization 
     *             session - NOT NULL
     *
     */
    public Anchor(final String last, final String next) {
        setNext(next);
        setLast(last);
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the last property
     *
     * @return the last property
     */
    public String getLast() {
        return last;
    }

    /**
     * Sets the last property
     *
     * @param last the last property
     *
     */
    public void setLast(String last) {
        this.last = last;
    }
    
    /**
     * Gets the next property
     *
     * @return the next property
     */
    public String getNext() {
        return next;
    }
    
    /**
     * Sets the next property
     *
     * @param next the next property
     *
     */
    public void setNext(String next) {
        this.next = next;
    }
}