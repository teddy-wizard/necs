/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * Corresponds to the &ltCopy&gt tag in the SyncML represent DTD
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Copy.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Copy
extends ModificationCommand
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    public static String COMMAND_NAME = "Copy";
    
    // ------------------------------------------------------------ Constructors
    
    /** For serialization purposes */
    protected Copy() {}    
    
    /** 
     * Creates a new Copy object with the given command identifier, noResponse, 
     * credential, meta and array of item
     *
     * @param cmdID the command identifier - NOT NULL
     * @param noResp true if no response is required
     * @param cred the authentication credential
     * @param meta the meta data
     * @param items the array of item - NOT NULL
     *
     */
    public Copy(final CmdID cmdID,
                final boolean noResp,
                final Cred cred,
                final Meta meta,
                final Item[] items) {
        super(cmdID, meta, items);
        
        this.noResp  = (noResp) ? new Boolean(noResp) : null;
        setCred(cred);
    }

   // ----------------------------------------------------------- Public methods

    /**
     * Gets the command name property
     *
     * @return the command name property
     */    
    public String getName() {
        return Copy.COMMAND_NAME;
    }
}