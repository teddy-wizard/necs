/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

/**
 * Corresponds to the &ltDelete&gt element in the SyncML represent DTD
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version $Id: Delete.java,v 1.1 2004/04/13 09:37:30 luigia Exp $
 */
public final class Delete
extends ModificationCommand
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    /** Command name */
    public static final String COMMAND_NAME = "Delete";

    // ------------------------------------------------------------ Private data
    private Boolean archive;
    private Boolean sftDel;
    
    // ------------------------------------------------------------ Constructors
    /** For serialization purposes */
    protected Delete() {}

    /** 
     * Creates a new Delete object with the given command identifier, 
     * noResponse, archiveData, softDelete, credential, meta and array of item
     *
     * @param cmdID the command identifier - NOT NULL
     * @param noResponse true if no response is required
     * @param archive true if the deleted data should be archived
     * @param sftDel true if this is a "soft delete". If set to false, then 
     *                   this delete command is a "hard delete"
     * @param credential the authentication credential
     * @param meta the meta data
     * @param items the array of item - NOT NULL
     *
     */
    public Delete(final CmdID cmdID,
                  final boolean noResp,
                  final boolean archive,
                  final boolean sftDel,
                  final Cred cred,
                  final Meta meta,
                  final Item[] items) {
        super(cmdID, meta, items);
        
        setCred(cred);
        this.noResp  = (noResp)  ? new Boolean(noResp)  : null;
        this.archive = (archive) ? new Boolean(archive) : null;
        this.sftDel  = (sftDel)  ? new Boolean(sftDel)  : null;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Gets the command name property
     *
     * @return the command name property
     */    
    public String getName() {
        return Delete.COMMAND_NAME;
    }

    /**
     * Gets the Archive property
     *
     * @return true if the deleted data should be archived
     */
    public boolean isArchive() {
        return (archive != null);
    }

    /**
     * Gets the Boolean archive property
     *
     * @return archive the Boolean archive property
     */
    public Boolean getArchive() {
        if (!archive.booleanValue()) {
            return null;
        }
        return archive;
    }

    /**
     * Sets the archive property
     *
     * @param archive the Boolean archive object
     */
    public void setArchive(Boolean archive) {
        this.archive = archive;
    }
    
    /**
     * Gets the SftDel property
     *
     * @return <b>true</b>  if this is a "Soft delete" 
     *         <b>false</b> if this is a "hard delete"
     */
    public boolean isSftDel() {
        return (sftDel != null);
    }

    public Boolean getSftDel() {
        if (!sftDel.booleanValue()) {
            return null;
        }
        return sftDel;
    }
    

    public void setSftDel(Boolean sftDel) {
        this.sftDel = sftDel;
    }
}