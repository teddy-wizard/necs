/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.framework.core;

import java.util.*;

/**
 * Corresponds to the &ltSyncBody&gt element in the SyncML represent DTD
 *
 *  @author Stefano Fornari @ Funambol
 *  @see    SyncHdr
 *
 *  @version $Id: SyncBody.java,v 1.1 2004/04/13 09:37:31 luigia Exp $
 */
public final class SyncBody
implements java.io.Serializable {
    // --------------------------------------------------------------- Constants
    private static final String ALLOWED_COMMANDS = ":Alert:Add:Atomic:Copy:Delete:Exec:Get:Map:Put:Replace:Results:Search:Sequence:Status:Sync:";
    
    // ------------------------------------------------------------ Private data
    private ArrayList commands = new ArrayList();
    private Boolean finalMsg;

    // ------------------------------------------------------------ Constructors
    
    /** For serialization purposes */
    protected SyncBody() {}
    
    /**
     * Create a new SyncBody object. The commands in <i>commands</i>
     * must be of the allowed types.
     *
     * @param commands The array elements must be an instance of one of these 
     *                 classes: {@link Alert},  {@link Atomic}, {@link Copy},
     *                 {@link Exec}, {@link Get}, {@link Map}, {@link Put},
     *                 {@link Results}, {@link Search}, {@link Sequence},
     *                 {@link Status}, {@link Sync}
     * @param finalMsg is true if this is the final message that is being sent
     *
     */
    public SyncBody( final AbstractCommand[] commands, final boolean finalMsg) {
        
        setCommands(commands);
        this.finalMsg = (finalMsg) ? new Boolean(finalMsg) : null;
    }

    // ---------------------------------------------------------- Public methods
    
    /**
     *
     *  @return the return value is guaranteed to be non-null. Also,
     *          the elements of the array are guaranteed to be non-null.
     *
     */
    public ArrayList getCommands() {
        return this.commands;
    }
    
    
    /**
     * Sets the sequenced commands. The given commands must be of the allowed
     * types.
     *
     * @param commands the commands - NOT NULL and o the allawed types
     *
     * @throws IllegalArgumentException if the constraints are not met
     */
    public void setCommands(AbstractCommand[] commands) {
        if (commands == null) {
            throw new IllegalArgumentException("commands cannot be null");
        }
        
        for (int i = 0; i < commands.length; i++) {
            if (commands[i] == null) {
                throw new IllegalArgumentException("commands[" + i +"] cannot be null");
            } else if (   (!(commands[i] instanceof Alert))
                       && (!(commands[i] instanceof Add))                       
                       && (!(commands[i] instanceof Atomic))
                       && (!(commands[i] instanceof Copy))
                       && (!(commands[i] instanceof Delete))
                       && (!(commands[i] instanceof Exec))
                       && (!(commands[i] instanceof Get))
                       && (!(commands[i] instanceof Map))
                       && (!(commands[i] instanceof Put))
                       && (!(commands[i] instanceof Replace))
                       && (!(commands[i] instanceof Results))
                       && (!(commands[i] instanceof Search))
                       && (!(commands[i] instanceof Sequence))
                       && (!(commands[i] instanceof Status))
                       && (!(commands[i] instanceof Sync))) {
                throw new IllegalArgumentException(
                    "commands[" + i + "] cannot be a " + commands[i].getName()
                );
            }
        }
        
        List c = Arrays.asList(commands);
        this.commands.addAll(c);
    }
    
    /**
     * Sets the message as final
     * 
     * @param finalMsg the Boolean value of finalMsg property
     */
    public void setFinalMsg(Boolean finalMsg) {
        this.finalMsg = finalMsg;
    }

    /**
     * Gets the value of finalMsg property
     *
     * @return true if this is the final message being sent, otherwise false
     *
     */    
    public boolean isFinalMsg() {
        return (finalMsg != null);
    }

    /**
     * Gets the value of finalMsg property
     *
     * @return true if this is the final message being sent, otherwise null
     *
     */  
    public Boolean getFinalMsg() {
        if (!finalMsg.booleanValue()) {
            return null;
        }
        return finalMsg;
    }
}