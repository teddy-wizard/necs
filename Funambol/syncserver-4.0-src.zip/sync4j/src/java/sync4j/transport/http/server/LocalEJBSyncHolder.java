/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.transport.http.server;

import java.util.HashMap;

import javax.servlet.http.*;
import javax.naming.*;
import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.ejb.EJBException;

import sync4j.framework.transport.http.SyncHolder;
import sync4j.framework.server.SyncResponse;
import sync4j.server.syncbean.SyncLocal;
import sync4j.server.syncbean.SyncHomeLocal;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.server.error.ServerException;
import sync4j.framework.server.error.ServerFailureException;
import sync4j.framework.server.error.NotImplementedException;
import sync4j.framework.protocol.ProtocolException;

/**
 * Implementes a <i>SyncHolder</i> wrapping a local EJB.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: LocalEJBSyncHolder.java,v 1.8 2004/04/13 09:32:08 luigia Exp $
 */
public class LocalEJBSyncHolder implements SyncHolder {

    // --------------------------------------------------------------- Constants

    public static final String SYNCEJB_HOME_JNDI_NAME = "java:comp/env/ejb/LocalSyncBean";

    // ------------------------------------------------------------ Private data

    private SyncLocal     sync              = null;
    private String        sessionId         = null;
    private SyncHomeLocal home              = null;
    private long          creationTimestamp       ;

    // ------------------------------------------------------------ Constructors

    public LocalEJBSyncHolder() throws NamingException {
        InitialContext ctx = new InitialContext();
        home = (SyncHomeLocal)ctx.lookup(SYNCEJB_HOME_JNDI_NAME);
        creationTimestamp = System.currentTimeMillis();
    }

    // ---------------------------------------------------------- Public methods

    /** Processes an incoming message.
     *
     * @param requestData the SyncML request as stream of bytes
     * @param contentType the content type associated with the request
     *
     * @return the SyncML response as a <i>ISyncResponse</i> object
     *
     * @throws ServerException in case of a server error
     *
     */
    public SyncResponse processMessage(byte[] requestData, String contentType)
    throws ServerException {
        return sync.processMessage(requestData, contentType);
    }

    public void setSessionId(String sessionId) throws Sync4jException {
        try {
            sync = home.create(sessionId);
        } catch (CreateException e) {
            throw new ServerFailureException(e);
        }

        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    /** Called when the SyncHolder is not required any more. It gives the holder
     * an opportunity to do clean up and releaseing of resources.
     *
     * @throws java.lang.Exception in case of error. The real exception is stored
     * in the cause.
     *
     */
    public void close() throws Exception {
        try {
            sync.remove();
        } catch (RemoveException e) {
            throw new Exception("Error in closing the SyncHolder", e);
        } catch (EJBException e) {
            throw new Exception("Error in closing the SyncHolder", e);
        }
    }

    /**
     * Returns the creation timestamp (in milliseconds since midnight, January
     * 1, 1970 UTC).
     *
     * @see sync4j.framework.transport.http.SyncHolder
     */
    public long getCreationTimestamp() {
        return creationTimestamp;
    }
}