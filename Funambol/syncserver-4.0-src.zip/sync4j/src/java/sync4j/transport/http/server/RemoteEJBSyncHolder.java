/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.transport.http.server;

import java.io.Serializable;
import java.util.Hashtable;
import java.rmi.RemoteException;

import javax.servlet.http.*;
import javax.naming.*;
import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.ejb.EJBException;
import javax.ejb.Handle;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import sync4j.server.syncbean.SyncRemote;
import sync4j.server.syncbean.SyncHomeRemote;

import sync4j.framework.transport.http.SyncHolder;
import sync4j.framework.server.SyncResponse;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.server.error.ServerException;
import sync4j.framework.server.error.ServerFailureException;
import sync4j.framework.server.error.NotImplementedException;
import sync4j.framework.protocol.ProtocolException;

import com.funambol.commons.security.ClientLoginCallbackHandler;


/**
 * Implementes a <i>SyncHolder</i> wrapping a remote EJB.
 * <p>
 * This holder must be used in a clustered environment.
 *
 * @author Luigia Fassina
 * @author  Stefano Fornari
 *
 * @version $Id: RemoteEJBSyncHolder.java,v 1.3 2004/04/13 09:32:08 luigia Exp $
 */
public class RemoteEJBSyncHolder
implements SyncHolder, Serializable {

    // --------------------------------------------------------------- Constants

    public static final String SYNCEJB_HOME_JNDI_NAME = "java:comp/env/ejb/RemoteSyncBean";

    public static final String CONTEXT_FACTORY
        = "org.jnp.interfaces.NamingContextFactory";
    public static final String CONTEXT_URL_PREFIXES
        = "org.jboss.naming:org.jnp.interfaces";

    // ------------------------------------------------------------ Private data

    private transient SyncRemote syncBean          = null ;
    private transient boolean    newHolder         = false;
    private           Handle     syncHandle               ;
    private           String     sessionId                ;
    private           long       creationTimestamp        ;

    private String jndiAddress;

    // ------------------------------------------------------------ Constructors

    /**
     * For serialization purposes
     */
    protected RemoteEJBSyncHolder() {}

    /**
     * Creates a new SyncServerEJBSyncHolder setting the <i>newHolder</i>
     * properties to </i>newHolderFlag</i>. Please note that when the default
     * constructore is used (i.e.during deserialization), the default value
     * <i>false</i> is taken. This is wanted, because if the object is
     * deserialized, it is not new by construction. The same is true for
     * <i>creationTimestamp</i> but in this case no default value is provided
     * as it is not transient (the serialized value must be taken).
     *
     * @param newHolderFlag is this holder a new one?
     */
    public RemoteEJBSyncHolder(boolean newHolderFlag) {
        newHolder = newHolderFlag;
        if (newHolder) {
            creationTimestamp = System.currentTimeMillis();
        }
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Processes an incoming message.<br>
     *
     * @param requestData the SyncML request as stream of bytes
     * @param contentType the content type associated with the request
     *
     * @return the SyncML response as a <i>ISyncResponse</i> object
     *
     * @throws ServerException in case of a server error
     *
     */
    public SyncResponse processMessage(byte[] requestData, String contentType)
    throws ServerException {
        try {
            String username = "supersa";
            char[] password = "ass194amb".toCharArray();

            ClientLoginCallbackHandler handler =
                 new ClientLoginCallbackHandler(username, password);
            LoginContext lc = new LoginContext("client-login", handler);

            lc.login();

            return getSyncServerBeanInstance()
                   .processMessage(requestData, contentType);
        } catch (Exception e) {
            throw new ServerException(e);
        }
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setJndiAddress(String jndiAddress){
        this.jndiAddress = jndiAddress;
    }

    public String getJndiAddress() {
        return jndiAddress;
    }

    /** Called when the SyncHolder is not required any more. It gives the holder
     * an opportunity to do clean up and releaseing of resources.
     *
     * @throws java.lang.Exception in case of error. The real exception is stored
     * in the cause.
     *
     */
    public void close() throws Exception {
        try {
            if (syncBean != null) {
                syncBean.remove();
            }
        } catch (Exception e) {
            throw new Exception("Error in closing the SyncHolder", e);
        }
    }

    /**
     * Returns the creation timestamp
     *
     * @return the creation timestamp
     */
    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    /**
     * Returns the newHolder flag
     *
     * @return the newHolder flag
     */
    public boolean isNew() {
        return newHolder;
    }

    // --------------------------------------------------------- Private methods

    /**
     * Returns the SyncBean instance to use for remote calls. Note that field
     * <i>syncBean</i> can be null if the bean has never been used or this
     * instance comes from a deserialization process.<br>
     * If <i>syncBean</i> is null then if <i>syncHandle</i> is not null, it is
     * used to get the EJB instance. If also </i>syncHandle</i> is null, the
     * bean is created.
     *
     * @return the SyncServerBean EJB instance
     *
     * @throws ServerFailureException in case of error
     */
    private SyncRemote getSyncServerBeanInstance()
    throws ServerFailureException {
        if (syncBean != null) {
            return syncBean;
        }

        if (syncHandle != null) {
            try {
                return syncBean = (SyncRemote)syncHandle.getEJBObject();
            } catch (RemoteException e) {
                throw new ServerFailureException(e);
            }
        }

        //
        // Never used before.... create a new EJB instance from scratch
        // NOTE: session Id cannot be empty
        //
        if ((sessionId == null) || (sessionId.length() == 0)) {
            throw new ServerFailureException("No session id is associated to this handler");
        }

        SyncHomeRemote home;
        InitialContext ctx;

         try {
             Hashtable env = new Hashtable();

             env.put(Context.INITIAL_CONTEXT_FACTORY, CONTEXT_FACTORY     );
             env.put(Context.URL_PKG_PREFIXES,        CONTEXT_URL_PREFIXES);
             env.put(Context.PROVIDER_URL,            jndiAddress         );

             ctx        = new InitialContext(env);
             home       = (SyncHomeRemote)ctx.lookup(SYNCEJB_HOME_JNDI_NAME);;
             syncBean   = home.create(sessionId);
             syncHandle = syncBean.getHandle();
        } catch (Exception e) {
            throw new ServerFailureException(e);
        }

        return syncBean;
    }

}