/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.transport.http.server;

import sync4j.framework.transport.http.SyncHolder;
import sync4j.framework.server.SyncResponse;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.server.error.ServerException;
import sync4j.framework.server.error.ServerFailureException;
import sync4j.framework.server.error.NotImplementedException;
import sync4j.framework.protocol.ProtocolException;

import sync4j.server.engine.SyncAdapter;

/**
 * Implementes a <i>SyncHolder</i> that instance a SyncAdapter to handle a 
 * synchronization request.
 *
 * @author  Luigia Fassina @ Funambol
 * @version $Id: LocalSyncHolder.java,v 1.4 2004/04/13 17:35:01 luigia Exp $
 */
public class LocalSyncHolder implements SyncHolder {

    // ------------------------------------------------------------ Private data
    
	private String      sessionId         = null;
	private SyncAdapter syncAdapter       = null;
    private long        creationTimestamp       ;

    // ------------------------------------------------------------ Constructors
	public LocalSyncHolder() throws ServerException {
		syncAdapter = new SyncAdapter();
        creationTimestamp = System.currentTimeMillis();
	}

    // ---------------------------------------------------------- Public methods
    
    /** Processes an incoming message.
	 *
	 * @param requestData the SyncML request as stream of bytes
	 * @param contentType the content type associated with the request
	 *
	 * @return the SyncML response as a <i>ISyncResponse</i> object
	 *
	 * @throws ServerException in case of a server error
	 *
	 */
    public SyncResponse processMessage(byte[] requestData, String contentType) 
    throws ServerException {
		return syncAdapter.processMessage(requestData, contentType);
	 }    
    
    public void setSessionId(String sessionId) throws Sync4jException {
        this.sessionId = sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }
    
    /** Called when the SyncHolder is not required any more. It gives the holder
     * an opportunity to do clean up and releaseing of resources.
     *
     * @throws java.lang.Exception in case of error. The real exception is stored
     * in the cause.
     *
     */
    public void close() throws Exception {
        syncAdapter.endSync();
    }
    
    /**
     * Returns the creation timestamp (in milliseconds since midnight, January 
     * 1, 1970 UTC).
     *
     * @see sync4j.framework.transport.http.SyncHolder
     */
    public long getCreationTimestamp() {
        return creationTimestamp;
    }
}