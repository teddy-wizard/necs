/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.transport.http.server;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import sync4j.framework.core.*;
import sync4j.framework.server.*;

/**
 *
 *  @author Sean C. Sullivan
 *
 */
public final class Sync4jRequest implements sync4j.framework.server.SyncRequest
{
    private final HttpServletRequest m_httpReq;

    /**
     *
     * @param httpReq must be non-null
     *
     *
     */
    public Sync4jRequest(final HttpServletRequest httpReq)
            // throws ??? exceptions
    {

        if (httpReq == null)
        {
            throw new NullPointerException(
                    "httpReq parameter is null");
        }

        m_httpReq = httpReq;

        // todo : put real code in this constructor

    }


    public int getContentLength()
    {
        return m_httpReq.getContentLength();
    }

    public String getContentType()
    {
        return m_httpReq.getContentType();
    }

    public InputStream getInputStream()
            throws java.io.IOException
    {
        return m_httpReq.getInputStream();
    }

}