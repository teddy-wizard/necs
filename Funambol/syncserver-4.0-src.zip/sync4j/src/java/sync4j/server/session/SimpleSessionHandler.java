/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.session;

import java.util.logging.Logger;
import java.util.logging.Level;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.Arrays;
import java.util.List;

import sync4j.framework.core.*;
import sync4j.framework.core.Map;
import sync4j.framework.protocol.*;
import sync4j.framework.database.Database;
import sync4j.server.engine.Sync4jEngine;
import sync4j.framework.engine.SyncItemImpl;
import sync4j.framework.engine.SyncOperation;
import sync4j.framework.engine.SyncEngineFactory;
import sync4j.framework.engine.source.MemorySyncSource;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.security.SecurityConstants;
import sync4j.framework.security.Sync4jPrincipal;
import sync4j.framework.server.session.SessionHandler;
import sync4j.framework.server.error.ServerException;
import sync4j.framework.server.SyncTimestamp;
import sync4j.framework.server.LastTimestamp;
import sync4j.framework.server.ClientMapping;

import sync4j.framework.engine.SyncEngine;
import sync4j.framework.engine.SyncItemState;

import sync4j.framework.security.JAASOfficer;

import sync4j.framework.server.error.InvalidCredentialsException;
import sync4j.framework.server.store.NotFoundException;
import sync4j.framework.server.store.PersistentStore;
import sync4j.framework.server.store.PersistentStoreException;

import sync4j.framework.server.session.SyncState;

/**
 * This class represents the handler for a SyncML session. It coordinates and
 * handles the packages and messages as dictated by the protocol.
 * <p>
 * The entry point is <i>processMessage()</i>, which determines which message is
 * expected and what processing has to be done (depending on the value of
 * <i>currentState</i>). If an error accours, the session goes to the state
 * <i>STATE_ERROR</i>; in this state no other messages but initialization can be
 * performed.
 * <p>
 * In the current implementation separate initialization is required.
 * <p>
 * <i>SessionHandler</i> makes use of a <i>SyncEngine</i> for all
 * tasks not related to the handling of the protocol.
 * See <i>sync4j.framework.engine.SyncEngine</i> for more information.
 *
 * LOG NAME: sync4j.handler
 *
 * @see sync4j.framework.engine.SyncEngine
 *
 * @author Stefano Fornari @ Funambol
 * @author Richard Wafer
 * @author Chintan Shah
 *
 * @version $Id: SimpleSessionHandler.java,v 1.8 2004/04/13 17:35:00 luigia Exp $
 *
 */
public class SimpleSessionHandler implements SessionHandler, java.io.Serializable {

    // --------------------------------------------------------------- Constants

    public static final int STATE_START                      = 0x0000;
    public static final int STATE_END                        = 0x0001;
    public static final int STATE_ERROR                      = 0xFFFF;
    public static final int STATE_INITIALIZATION_PROCESSING  = 0x0010;
    public static final int STATE_INITIALIZATION_PROCESSED   = 0x0011;
    public static final int STATE_SYNCHRONIZATION_PROCESSING = 0x0012;
    public static final int STATE_SYNCHRONIZATION_PROCESSED  = 0x0013;
    public static final int STATE_SYNCHRONIZATION_COMPLETION = 0x0014;


    // ------------------------------------------------------------ Private data

    private int currentState = STATE_START;

    //
    // This data is true for slow sync
    //
    private boolean slow = false;

    /**
     * Gets the current state
     *
     * @return the current state
     */
    public int getCurrentState() {
        return currentState;
    }

    private long creationTimestamp = -1;

    /**
     * Gets the creation timestamp of the session
     *
     * @return the creation timestamp
     */
    public long getCreationTimestamp() {
        return creationTimestamp;
    }

    private transient Logger log = Sync4jLogger.getLogger("handler");

    /**
     * SyncTimestamp for the current synchronization
     */
    private SyncTimestamp nextTimestamp = null;

    private transient SyncInitialization syncInit = null;
    private transient ClientModifications modifications = null;

    /**
     * When action command received from client set to true
     */
    private boolean syncCommandFromClient = false;

    /**
     * This Map contains all the mapping for the databases involved in the
     * synchronization for the current logged principal.<br>
     * The database names are used as keys and the corresponding mapping
     * contains the luig-guid mapping. The map is created and initialized
     * in <i>getClientMappings()</i>
     */
    private java.util.Map clientMappings = null;

    /**
     * Contain the client device Id for the current session
     */
    private String clientDeviceId = null;

    /**
     * The databases that have to be synchronized. It is set in the initialization
     * process.
     */
    Database[] dbs = null;

    /**
     * The flag for established if credentials are valid
     */
    private boolean validCredentials = false;

    // -------------------------------------------------------------- Properties

    /**
     * The session id - read only
     */
    private String sessionId = null;

    public String getSessionId() {
        return this.sessionId;
    }

    /**
     * The command id generator (it defaults ro a <i>CommandIdGenerator</i> instance)
     */
    private CommandIdGenerator cmdIdGenerator = new CommandIdGenerator();

    public void setCommandIdGenerator(CommandIdGenerator cmdIdGenerator) {
        this.cmdIdGenerator = cmdIdGenerator;
    }

    public CommandIdGenerator getCommandIdGenerator() {
        return this.cmdIdGenerator;
    }

    /**
     * The cmdIdGenerator must be reset each time the process
     * of a message is starting
     */
    private void resetIdGenerator() {
        this.cmdIdGenerator.reset();
        syncEngine.setCommandIdGenerator(this.cmdIdGenerator);
    }

    /**
     * The message id generator (it defaults ro a <i>SimpleIdGenerator</i> instance)
     */
    private SimpleIdGenerator msgIdGenerator = new SimpleIdGenerator();

    /**
     * The Last message Id from the client
     */
    private String lastMsgIdFromClient = new String();

    /**
     * The factory for the <i>SyncEngine</i> object
     */
    private SyncEngineFactory syncEngineFactory = null;

    /**
     * The <i>SyncEngine</i>
     */
    private Sync4jEngine syncEngine = null;

    /**
     * Authenticated credential. If null no credential has authenticated.
     */
    private Cred            loggedCredential = null;
    private Sync4jPrincipal loggedPrincipal  = null;

    private boolean guestEnabled = false;

    /**
     * The SyncState for the syncronization process
     */
    private SyncState syncState = null;

    // ---------------------------------------------------------- Public methods

    /**
     * Sets the property <i> syncEngineFactory</i> and creates the instance of
     * the <i>SyncEngine</i> objects.
     *
     * @param syncEngineFactory the factory
     */
    public void setSyncEngineFactory(SyncEngineFactory syncEngineFactory) {
        this.syncEngineFactory = syncEngineFactory;
        try {
            this.syncEngine = (Sync4jEngine) syncEngineFactory.getSyncEngine();
        } catch (Sync4jException e) {
            log.throwing(getClass().getName(), "setSyncEngineFacytory", e);
        }
        if (log.isLoggable(Level.FINEST)) {
            log.finest(syncEngineFactory + " sync engine factory set");
            log.finest(syncEngine + " sync engine created");
        }
    }

    public SyncEngineFactory getSyncEngineFactory() {
        return this.syncEngineFactory;
    }

    public SyncEngine getSyncEngine() {
        return this.syncEngine;
    }

    /**
     * Indicates if the session is a new session
     */
    private boolean newSession = true;

    public void setNew(boolean newSession) {
        this.newSession = newSession;
    }

    public boolean isNew() {
        return this.newSession;
    }

    // ------------------------------------------------------------ Constructors

    /**
     * Creates a new instance of SimpleSessionHandler
     */
    public SimpleSessionHandler() {
        this.creationTimestamp = System.currentTimeMillis();
    }

    /**
     * Creates a new instance of SimpleSessionHandler with a given session id
     */
    public SimpleSessionHandler(String sessionId) {
        this();
        this.sessionId = sessionId;
    }

    // ---------------------------------------------------------- Public methods

    /**
     * Returns true if the sessione has been authenticated.
     *
     * @return true if the sessione has been authenticated, false otherwise
     */
    public boolean isAuthenticated() {
        return loggedCredential != null;
    }

    /**
     * Returns true if the session has not been authenticated because of an
     * expired account.
     *
     * @return true if the account is expired
     */
    public boolean isAccountExpired() {
        JAASOfficer officer = (JAASOfficer) syncEngine.getOfficer();

        return officer.isLoginExpired();
    }

    /**
     * Processes the given message. See the class description for more
     * information.
     *
     * @param message the message to be processed
     *
     * @return the response message
     *
     * @throws ProtocolException
     */
    public SyncML processMessage(SyncML message) throws ProtocolException, InvalidCredentialsException {
        boolean syncWithInit = false;

        SyncML response     = null;
        SyncML syncResponse = null;

        //
        // Reset the cmdIdGenerator has specified in the spec
        //
        resetIdGenerator();

        //
        // Each time a message is received for a particular session adjust the message ID
        //
        msgIdGenerator.next();

        //
        //  We maintain the message Id from client
        //
        lastMsgIdFromClient = message.getSyncHdr().getMsgID();

        //
        // Initialize the device ID from the client request
        //
        clientDeviceId = message.getSyncHdr().getSource().getLocURI();

        if (log.isLoggable(Level.FINE)) {
            log.fine("current state: " + getStateName(currentState));
        }

        try {
            switch (currentState) {
                case STATE_ERROR: // in case of error you can start a new initialization
                case STATE_START:
                    nextTimestamp = new SyncTimestamp();
                    nextTimestamp.start = System.currentTimeMillis();
                    nextTimestamp.tag   = String.valueOf(nextTimestamp.start);

                    syncState = new SyncState();

                    moveTo(STATE_INITIALIZATION_PROCESSING);

                    login(message.getSyncHdr().getCred(), clientDeviceId);

                    if (isAuthenticated()) {
                        try {
                            readPrincipal(loggedPrincipal);
                        } catch (NotFoundException e) {
                            validCredentials = false;
                            loggedCredential = null;
                            moveTo(STATE_INITIALIZATION_PROCESSING);
                        }
                    }

                case STATE_INITIALIZATION_PROCESSING:
                    response = processInitMessage(message);

                    //
                    // To sort StatusCommand
                    //
                    response = mergeResponse(response, null);

                    if (!isAuthenticated()) {
                        moveTo(STATE_START);
                        break;
                    }

                    //
                    //	Checking for message with Sync with Initialization
                    //	If yes, set CurrentState to STATE_SYNCHRONIZATION_PROCESSING
                    //	and proceed ahead for synchornization...
                    //
                    syncWithInit = checkSyncInit(message);
                    if (syncWithInit) {
                        moveTo(STATE_INITIALIZATION_PROCESSED);
                        if (log.isLoggable(Level.FINE)) {
                            log.fine("Sync message without separate initialization");
                        }
                    } else {
                        if (log.isLoggable(Level.FINE)) {
                            log.fine("Sync with separate initalization");
                        }

                        if (message.getSyncBody().isFinalMsg()) {
                            moveTo(STATE_INITIALIZATION_PROCESSED);
                        }
                        break;
                    }

                case STATE_INITIALIZATION_PROCESSED:
                    moveTo(STATE_SYNCHRONIZATION_PROCESSING);

                case STATE_SYNCHRONIZATION_PROCESSING:
                    syncResponse = processSyncMessage(message);

                    if (syncWithInit) {
                        response = mergeResponse(response, syncResponse);
                    } else {
                        response = mergeResponse(null, syncResponse);
                    }

                    storeClientMappings();
                    resetClientMappings();

                    if (message.getSyncBody().isFinalMsg()) {
                        moveTo(STATE_SYNCHRONIZATION_PROCESSED);
                        nextTimestamp.end = System.currentTimeMillis();
                        commit();
                        moveTo(STATE_SYNCHRONIZATION_COMPLETION);
                    }
                    break;

                case STATE_SYNCHRONIZATION_COMPLETION:
                    response = processCompletionMessage(message);

                    storeClientMappings();
                    resetClientMappings();
                    if (message.getSyncBody().isFinalMsg()) {
                        response.setLastMessage(true);
                        moveTo(STATE_END);
                    }
                    break;
                default:
                    logout();
                    throw new ProtocolException("Illegal state: " + currentState);
            }
        } catch (ProtocolException e) {
            log.throwing(getClass().getName(), "processMessage", e);
            moveTo(STATE_ERROR);
            throw e;
        } catch (NotFoundException e) {
            log.throwing(getClass().getName(), "processMessage", e);
            moveTo(STATE_ERROR);
            throw new InvalidCredentialsException("Invalid credential error", e);
        } catch (PersistentStoreException e) {
            log.throwing(getClass().getName(), "processMessage", e);
            moveTo(STATE_ERROR);
            throw new ProtocolException("Persistent store error", e);
        } catch (Throwable t) {
            t.printStackTrace();
            log.throwing(getClass().getName(), "processMessage", t);
            moveTo(STATE_ERROR);
        }

        if (log.isLoggable(Level.FINER)) {
            log.finer("About returning message: " + Util.toXML(response));
        }

        return response;
    }

	/**
     * Merges Initalization and Synchronization responses into a single message.
     *
	 * @param init Initialization Response Message
	 * @param sync Synchronization Response Message
     *
     * @throws sync4.framework.core.RepresentationException in case of a
     *         representation error
     *
	 *	@return the combined message
	 */
	private SyncML mergeResponse(SyncML init, SyncML sync)
    throws RepresentationException {

        SyncHdr  header = null;
        SyncBody body     = null;

        //
        // The StatusCommand Objects must be sorted for cmdRef.
        //
        TreeMap tmOtherCmd = new TreeMap();
        ArrayList alStatus = new ArrayList();
        ArrayList al = new ArrayList();

        if (init != null) {
            AbstractCommand[] initCmd =
                (AbstractCommand[])init.getSyncBody().getCommands().toArray(
                                                        new AbstractCommand[0]);
            for(int i=0; i<initCmd.length; ++i) {

                if (initCmd[i] instanceof Status) {
                    alStatus.add(initCmd[i]);
                } else {
                    String key = initCmd[i].getCmdID().getCmdID();
                    tmOtherCmd.put(new Integer(key), initCmd[i]);
                }
            }
        }

        if (sync != null) {
            AbstractCommand[] syncCmd =
                (AbstractCommand[])sync.getSyncBody().getCommands().toArray(
                                                        new AbstractCommand[0]);

            for(int i=0; i<syncCmd.length; ++i){
                if (syncCmd[i] instanceof Status) {
                    boolean isSyncHdr = false;

                    if ("0".equals(((Status)syncCmd[i]).getCmdRef()) &&
                        "SyncHdr".equals(((Status)syncCmd[i]).getCmd())) {

                        for (int a=0;a<alStatus.size();a++) {
                            Status sc = (Status)alStatus.get(a);

                            if(sc.getCmdRef().equals("0") &&
                               sc.getCmd().equals("SyncHdr")) {
                                   isSyncHdr = true;
                                   break;
                            }
                        }
                        if(!isSyncHdr)
                            alStatus.add(syncCmd[i]);
                        continue;
                    }

                    alStatus.add(syncCmd[i]);
                } else {
                    String key = syncCmd[i].getCmdID().getCmdID();
                    tmOtherCmd.put(new Integer(key), syncCmd[i]);
                }
            }
        }


        List list = Arrays.asList(sortStatusCommand(alStatus.toArray(new AbstractCommand[0])));
        al.addAll(list);

        java.util.Set set1 = tmOtherCmd.keySet();
        java.util.Iterator it1 = set1.iterator();
        while(it1.hasNext()) {
            Integer key = (Integer)it1.next();
            al.add(tmOtherCmd.get(key));
        }

        AbstractCommand[] cmds = (AbstractCommand[])al.toArray(new AbstractCommand[0]);
        if (init != null) {
            header = init.getSyncHdr();
            body = new SyncBody(cmds, init.getSyncBody().isFinalMsg());
        } else {
            header = sync.getSyncHdr();
            body = new SyncBody(cmds, sync.getSyncBody().isFinalMsg());
        }

        return (new SyncML(header, body));
	}

    public static Object[] sortStatusCommand(Object[] statusToSort) {
        StatusComparator comparator = new StatusComparator();
        Arrays.sort(statusToSort, comparator);
        return statusToSort;
    }



    /**
     * Processes an error condition. This method is called when the error is
     * is not fatal and is manageable at a protocol/session level. This results
     * in a well formed SyncML message with an appropriete error code.
     * <p>
     * Note that the offending message <i>msg</i> cannot be null, meaning that
     * at least the incoming message was a SyncML message. In this context,
     * <i>RepresentationException</i>s are excluded.
     *
     * @param the offending message - NOT NULL
     * @param the exception representing the error condition - NOT NULL
     *
     * @throws sync4j.framework.core.Sync4jException in case of unexpected errors
     *
     * @return the response message
     */
    public SyncML processError(SyncML msg, Throwable error)
    throws Sync4jException {
        SyncHdr msgHeader = msg.getSyncHdr();

        Item[] items = new Item[0];
        int status = StatusCode.SERVER_FAILURE;

        if (syncEngine.isDebug()) {
            items = new Item[1];

            items[0] = new Item(
                           null, // target
                           null, // source
                           null, // meta
                           new ComplexData(error.getMessage())
                       );
        }

        if (error instanceof ServerException) {
            status = ((ServerException)error).getStatusCode();
        }

        Status statusCommand = new Status(
                cmdIdGenerator.next()                ,
                                msgHeader.getMsgID()                ,
                "0" /* command ref */                ,
                "SyncHdr" /* see SyncML specs */     ,
                new TargetRef(msgHeader.getTarget()),
                new SourceRef(msgHeader.getSource()),
                null /* credential */                ,
                null /* challenge */                 ,
                new Data(status)         ,
                new Item[0]
            );

        String serverURI =
            syncEngine.getConfiguration().getStringValue(syncEngine.CFG_SERVER_URI);
        SyncHdr syncHeader = new SyncHdr (
                                    new VerDTD         ("1.1"       )         ,
                                    new VerProto       ("SyncML/1.1")         ,
                                    msgHeader.getSessionID()                  ,
                                    msgHeader.getMsgID()                      ,
                                    new Target(msgHeader.getSource().getLocURI()),
                                    new Source(serverURI)                     ,
                                    null  /* response URI */                  ,
                                    false                                     ,
                                    null /* credentials */                    ,
                                    null /* metadata */
                               );

        SyncBody syncBody = new SyncBody(
                                new AbstractCommand[] { statusCommand },
                                true /* final */
                            );

        moveTo(STATE_ERROR);

        return new SyncML(syncHeader, syncBody);
    }

    /**
     * Called by the <i>SessionManager</i> when the session is expired.
     * It logs out the credential and release aquired resources.
     */

    public void expire() {
        logout();
    }

    /**
     * Called to interrupt the processing in case of errors depending on
     * extenal causes (i.e. the transport). The current implementation just move
     * the session state to the error state.
     * <p>
     * NOTE that the current implementation simply moves the state of the session
     * to <i>STATE_ERROR</i>.
     *
     * @param statusCode the error code
     *
     * @see sync4j.framework.core.StatusCode for valid status codes
     *
     */
    public void abort(int statusCode) {
        moveTo(STATE_ERROR);
    }

    /**
     * Called to permanently commit the synchronization. It does the following:
     * <ul>
     *  <li>persists the <i>last</i> timestamp to the database for the sources
     *      successfully synchronized
     * </ul>
     */
    public void commit() {
        assert (loggedPrincipal != null);

        LastTimestamp last = null;

        PersistentStore ps = syncEngine.getStore();

        Database[] dbsGen = syncEngine.getDbs();

        for (int i = 0; (dbsGen != null) && (i < dbsGen.length); ++i) {
			if (dbsGen[i].getStatusCode() != StatusCode.OK) {
				//
				// This database is in error. Do not commit it.
                //
				continue;
            }
            last = new LastTimestamp(
                    loggedPrincipal.getId(),
                    dbsGen[i].getName(),
                    dbsGen[i].getAnchor().getNext(),
                    nextTimestamp.start,
                    nextTimestamp.end
            );

            if (log.isLoggable(Level.FINE)) {
                log.fine("Commiting database "
                        + dbsGen[i].getName()
                        + " ( "
                        + last
                        + " )"
                );
            }

            try {
                boolean stored = ps.store(last);
                log.fine("LastTimeStamp stored: " + stored);
            } catch (Sync4jException e) {
                log.severe("Error in saving persistent data");
                log.throwing(getClass().getName(), "commit", e);
            }
        }
    }

    // --------------------------------------------------------- Private methods

    /**
     * If property "isGuestEnabled" is true and credential is null use the
     * credential of user guest
     *
     * @return true if the property "isGuestEnabled" is true else false
     */
    private boolean isGuestEnabled() {
        return this.guestEnabled;
    }

    /**
     * If flag "isValidCredential" is true then the login and password are correct
     * else are invalid credential
     */
    private boolean isValidCredential() {
        return this.validCredentials;
    }

    /**
     * Processes the given initialization message.
     *
     * @param message the message to be processed
     *
     * @return the response message
     *
     * @throws ProtocolException
     */
    private SyncML processInitMessage(SyncML message)
    throws ProtocolException {
        syncInit = new SyncInitialization(message.getSyncHdr() ,
                                          message.getSyncBody());

        //Store the informations that will be used in the Syncronization process
        syncState.addClientCommands(syncInit.getClientCommands());
        syncState.addClientAlerts(syncInit.getClientAlerts());

        syncInit.setIdGenerator(cmdIdGenerator);
        syncInit.setFlag(Flags.FLAG_FINAL_MESSAGE);

        if (isAuthenticated()) {
            syncInit.setAuthorizedStatusCode(StatusCode.AUTHENTICATION_ACCEPTED);


            syncInit.setClientCapabilitiesRequired(false);

            //
            // Gets the databases requested for synchronization and for each of
            // them checks if the database exists on the server and if the
            // credential is allowed to synchronize it
            //
            dbs = syncInit.getDatabasesToBeSynchronized();

            //
            // This will change the status code of the elements of clientDBs to
            // reflect the availability and accessibility of the given databases
            // on the server
            //
            syncEngine.prepareDatabases(loggedPrincipal, dbs, nextTimestamp);

            if (log.isLoggable(Level.FINEST)) {
                log.finest("Requested databases: " + Arrays.asList(dbs));
            }

            boolean noDataSource = true; // there are no datasource to allowed to synchronize

            for (int i = 0; ((dbs != null) && (i < dbs.length)); ++i) {
                syncInit.setStatusCodeForCommand(
                        dbs[i].getAlertCommand(),
                        dbs[i].getStatusCode()
                );

                if (dbs[i].getStatusCode() == StatusCode.OK) {
                    noDataSource = false;
                    syncEngine.addClientSource(
                            new MemorySyncSource(
                                dbs[i].getName(),
                                null,
                                dbs[i].getSource().getLocURI())
                    );
                }
            }

            syncEngine.setDbs(dbs);

            //
            // Setting the databases to synchronize. This will force the relative
            // <Alert>s to be inserted in the response.
            //
            syncInit.setDatabases(dbs);

            //
            // Setting server capabilities
            //
            syncInit.setServerCapabilities(
                syncEngine.getServerCapabilities(syncInit.getDTDVersion())
            );
        } else {
            if (isAccountExpired()) {
                syncInit.setAuthorizedStatusCode(StatusCode.PAYMENT_REQUIRED);
            } else if (!isGuestEnabled() && isValidCredential()) {
                syncInit.setAuthorizedStatusCode(StatusCode.MISSING_CREDENTIALS);
            } else if (!isValidCredential()) {
                syncInit.setAuthorizedStatusCode(StatusCode.INVALID_CREDENTIALS);
            } else {
                syncInit.setAuthorizedStatusCode(StatusCode.FORBIDDEN);
            }
        }

        return syncInit.getResponse();
    }

    /**
     * Processes the given synchronization message.
     *
     * @param syncRequest the message to be processed
     *
     * @return the response message
     *
     * @throws ProtocolException
     */
    private SyncML processSyncMessage(SyncML syncRequest)
            throws ProtocolException {
        log.finest("client sources: " + syncEngine.getClientSources());

        try {
            modifications =
                    new ClientModifications(syncRequest.getSyncHdr() ,
                                            syncRequest.getSyncBody(),
                                            syncEngine.getDbs());

            Sync[] syncCommands = modifications.getClientSyncCommands();
            if (syncCommands == null || syncCommands.length == 0) {
                throw new ProtocolException("Sync command expected in this package but no Sync commands were found");
            }


            List responseCommands = processModifications(modifications);

            if (log.isLoggable(Level.FINEST)) {
                log.finest("responseCommands: " + responseCommands);
            }

            modifications.setIdGenerator(cmdIdGenerator);
            modifications.setFlag(Flags.FLAG_ALL_RESPONSES_REQUIRED);

            modifications.setClientModificationsStatus(
                    (Status[]) filterCommands(
                            responseCommands,
                            new String[]{ Status.COMMAND_NAME }
                    ).toArray(new Status[0])
            );

			// .setServerModifications sets all the modification commands
			// required to be send to client from Server


			// cannot block this whole code,as this code may be used
			// by other DBS within same sync but differnt alert code.
            modifications.setServerModifications(
                    (AbstractCommand[]) filterCommands(
                            responseCommands,
                            new String[]{
                                Sync.COMMAND_NAME
                            }
                    ).toArray(new AbstractCommand[0])
            );

            modifications.setFlag(Flags.FLAG_FINAL_MESSAGE);

            SyncML response = modifications.getResponse();

            return response;
        } catch (Sync4jException e) {
            throw new ProtocolException(e);
        }
    }

    /**
     * Executes the given modifications and for each of them returns a status
     * command. It forwards the execution to the synchronization engine.
     *
     * @param modifications synchronization commands containing the modifications
     *                 that the client requires
     *
     * @return an array of command objects, each containig the result of
     *         a modification or a modification itself
     * @throws Sync4jException
     */
    private List processModifications(ClientModifications modifications)
            throws Sync4jException {
        SyncHdr    header           = modifications.getSyncHeader();
        String     msgId            = header.getMsgID()            ;
        boolean    headerNoResponse = header.isNoResp()            ;

        ArrayList responseCommands = new ArrayList();

        syncEngine.setCommandIdGenerator(cmdIdGenerator);

        Sync[] syncCommands = modifications.getClientSyncCommands();

        //
        // Retrieves existing LUID-GUID mapping
        //
        getClientMappings();

        //
        // First of all prepare the memory sources with the modification commands
        // receveid by the client
        //
        prepareMemorySources(syncCommands);

        syncEngine.setClientMappings(clientMappings);

        try {
			syncEngine.sync(loggedPrincipal);
        } catch (Sync4jException e) {
            log.throwing(getClass().getName(), "processModifications", e);
        }

        //
        // Status code for commands
        //
        if (headerNoResponse == false) {
            //
            // Sync commands
            //
            responseCommands.addAll(statusForSyncs(syncCommands));

            //
            // Status for server-side executed modification commands
            //
            Status[] operationStatus =
                syncEngine.getModificationsStatusCommands(msgId);

            for (int i=0; i<operationStatus.length; ++i) {
                responseCommands.add(operationStatus[i]);
            }
        }

        //
        // SyncCommands sent back to the client
        // No sync sent to client if ONE_WAY_FROM_CLIENT
        //

        Alert[] alertCommands = syncState.getClientAlerts();

        Item[] alertItems = null;
        ItemizedCommand[] commands = null;
        String uri = null;
        for (int k = 0; ((alertCommands != null) && (k < alertCommands.length)); ++k) {
            //
            // If the alert represents a client only action, just ignore it
            //
            if (AlertCode.isClientOnlyCode(alertCommands[k].getData())) {
                continue;
            }

            alertItems = (Item[])alertCommands[k].getItems().toArray(new Item[0]);

            for (int i=0; ((alertItems != null) && (i < alertItems.length)); ++i) {
                uri = alertItems[i].getTarget().getLocURI();

                for (int s=0; ((syncCommands != null) && s<syncCommands.length); s++) {
                    if ((syncCommands[s].getTarget() != null) && !uri.equals(syncCommands[s].getTarget().getLocURI())) {
						continue;
                    }
                    for (int j = 0; ((syncEngine.getDbs() != null) && (j < syncEngine.getDbs().length)); ++j) {
                        if ((syncEngine.getDbs())[j].getName().equals(uri)){
                            SyncOperation[] operations = syncEngine.getSyncOperations(uri);
                            commands = syncEngine.operationsToCommands(
                                           (ClientMapping)clientMappings.get(uri),
                                           operations,
                                           uri
                                       );
                            responseCommands.add(
                                    new Sync(
                                            cmdIdGenerator.next(),
                                            false,
                                            null,
                                            ProtocolUtil.source2Target(alertItems[i].getSource()),
                                            ProtocolUtil.target2Source(alertItems[i].getTarget()),
                                            null,
                                            commands
                                    )
                            );

                            //
                            // Now we can update the client-side LUID-GUID mappings
                            //
                            syncEngine.updateClientMappings(clientMappings, operations, slow);
                        }
                    }  // next j
                }
            } // next i
        } // next k

        //
        // Resets client alerts so that they are considered processed
        //
        syncState.resetClientAlerts();

        //
        // And here we can update the server-side LUID-GUID mappings
        //
        syncEngine.updateServerMappings(clientMappings, slow);

        return responseCommands;
    }

    /**
     * Process the completion message from the client check status for sync
     * command and update client mapping
     * @param message
     * @return the response message
     * @throws ProtocolException
     */
    private SyncML processCompletionMessage(SyncML message)
            throws ProtocolException {
        log.finest("processCompletionMessage");
        SyncML ret = null;

        try {
            ClientCompletion clientCompletion = new ClientCompletion(
                    message.getSyncHdr() ,
                    message.getSyncBody()
            );

            clientCompletion.setIdGenerator(cmdIdGenerator);
            clientCompletion.setFlag(Flags.FLAG_FINAL_MESSAGE);

            //
            // IF the client completion request contains MapCommand
            //
            if (clientCompletion.isMapCommandFind()) {
                String uri = null;

                ClientMapping mapping = null;
                Map[] mapCommands = clientCompletion.getMapCommands();
                MapItem[]    mapItems    = null                             ;
                for (int j=0; ((mapCommands != null) && (j<mapCommands.length)); ++j) {
                    uri = mapCommands[j].getTarget().getLocURI();
                    mapItems =
                        (MapItem[])mapCommands[j].getMapItems().toArray(
                                                                new MapItem[0]);

                    mapping = (ClientMapping)clientMappings.get(uri);
                    if (mapping == null) {
                        mapping = new ClientMapping(loggedPrincipal, uri);
                        clientMappings.put(uri, mapping);
                    }

                    for (int i = 0; i < mapItems.length; i++) {
                        MapItem mapItem = mapItems[i];

                        //Adding item properties to the persistent mapping
                        String GUID = mapItem.getTarget().getLocURI();
                        String LUID = mapItem.getSource().getLocURI();
                        mapping.updateMapping(LUID, GUID);
                    }
                }
            }

            ret = clientCompletion.getResponse();
        } catch (Sync4jException e) {
            log.severe("Error in process completion");
            throw new ProtocolException(e);
        }
        return ret;
    }

    /**
     * Makes a state transition. Very simple implementation at the moment: it
     * changes the value of <i>currentState</i> to the given value.
     *
     * @param state the new state
     */
    private void moveTo(int state) {
        if (log.isLoggable(Level.FINE)) {
            log.fine("moving to state " + getStateName(state));
        }
        currentState = state;
    }

    /**
     * Prepares the memory sources with the modification commands receveid
     * by the client.
     * <p>
     * Note that if the requested synchronization is a slow sync, the items are
     * inserted as "existing" items, regardless the command they belong to.
     * (maybe this will change as soon as the specification becomes clearer)
     *
     * @param syncCommands the commands used to prepare the source
     *
     */
    private void prepareMemorySources(Sync[] syncCommands) {

        List sources = syncEngine.getClientSources();

        //
        // For efficiency: put the databases in a HashMap
        //
        HashMap dbMap = new HashMap();
        for (int i=0; ((syncEngine.getDbs() != null) && (i<syncEngine.getDbs().length)); ++i) {
            dbMap.put((syncEngine.getDbs())[i].getName(), (syncEngine.getDbs())[i]);
        }

        //
        // First of all prepare the memory sources with the modification commands
        // receveid by the client
        //
        int method;
        slow = false;
        Target target = null;
        MemorySyncSource mss = null;
        AbstractCommand[] modifications = null;
        for (int i = sources.size(); i > 0; --i) {
            if (log.isLoggable(Level.FINE)) {
                log.fine("Preparing "
                        + syncEngine.getClientSources().get(i - 1)
                        + " with "
                        + Arrays.asList(syncCommands)
                );
            }

            mss = (MemorySyncSource) sources.get(i - 1);

            String  uri = mss.getSourceURI();

            modifications = new AbstractCommand[0];
            for (int j = 0; ((syncCommands != null) && (j < syncCommands.length)); ++j) {
                target = syncCommands[j].getTarget();
                if ((target != null) && (uri.equals(target.getLocURI()))) {
                    if (syncCommands[j].getCommands() != null) {
                       modifications =
                       (AbstractCommand[])syncCommands[j].getCommands().toArray(
                                                        new AbstractCommand[0]);
                    }

                    break;
                }
            }

            method = ((Database)dbMap.get(uri)).getMethod();
            slow = ((method == AlertCode.SLOW) || (method == AlertCode.REFRESH_FROM_SERVER));

            prepareMemorySource(mss, modifications, slow);
        }
    }

    /**
     * Prepares a source that represents the image of the client database. This
     * is done combining the existing client mapping with the modifications sent
     * by the client. Than this source can be compared with the server view of
     * the database.
     *
     * @param source the e source to prepare
     * @param commands the client modifications
     * @param slowSync true if the preparation is for a slow sync, false
     *                    otherwise
     *
     */
    private void prepareMemorySource(MemorySyncSource  source  ,
                                     AbstractCommand[] commands,
                                     boolean           slowSync) {
        ArrayList existing = new ArrayList();
        ArrayList deleted  = new ArrayList();
        ArrayList created  = new ArrayList();
        ArrayList updated  = new ArrayList();

        ClientMapping guidluid = null;

        //
        // First of all, in the case of fast sync, the items already mapped are
        // added as existing items. Note that server ids are used.
        // In the case of slow sync, the mappinngs are cleared so that they
        // won't generate conflicts.
        //
        guidluid = (ClientMapping)clientMappings.get(source.getSourceURI());
        if (slowSync) {
            if (guidluid != null) {
                guidluid.clearMappings();
            }
        } else {
            if (guidluid != null) {
                java.util.Map map = guidluid.getMapping();

                Iterator i = map.keySet().iterator();
                while (i.hasNext()) {
                    existing.add(
                        new SyncItemImpl(source, map.get(i.next()), SyncItemState.SYNCHRONIZED)
                    );
                }
            }
        }

        String name = null;
        for (int i = 0; ((commands != null) && (i < commands.length)); ++i) {
            name = commands[i].getName();
            if (slowSync && !Delete.COMMAND_NAME.equals(name)) {
                existing.addAll(
                    Arrays.asList(
                            syncEngine.itemsToSyncItems(
                                (ClientMapping)clientMappings.get(source.getSourceURI()),
                                source,
                                (ModificationCommand)commands[i],
                                SyncItemState.SYNCHRONIZED,
                                nextTimestamp.start
                            )
                    )
                );
                continue;
            }
            if (Add.COMMAND_NAME.equals(commands[i].getName())) {
                created.addAll(
                        Arrays.asList(
                                syncEngine.itemsToSyncItems(
                                    (ClientMapping)clientMappings.get(source.getSourceURI()),
                                    source,
                                    (ModificationCommand)commands[i],
                                    SyncItemState.NEW,
                                    nextTimestamp.start
                                )
                        )
                );
                continue;
            }

            if (Delete.COMMAND_NAME.equals(commands[i].getName())) {
                deleted.addAll(
                        Arrays.asList(
                                syncEngine.itemsToSyncItems(
                                    (ClientMapping)clientMappings.get(source.getSourceURI()),
                                    source,
                                    (ModificationCommand)commands[i],
                                    SyncItemState.DELETED,
                                    nextTimestamp.start
                                )
                        )
                );
                continue;
            }

            if (Replace.COMMAND_NAME.equals(commands[i].getName())) {
                updated.addAll(
                        Arrays.asList(
                                syncEngine.itemsToSyncItems(
                                    (ClientMapping)clientMappings.get(source.getSourceURI()),
                                    source,
                                    (ModificationCommand)commands[i],
                                    SyncItemState.UPDATED,
                                    nextTimestamp.start
                                )
                        )
                );
                continue;
            }
        }

        source.initialize(existing, deleted, created, updated);
    }


    /**
     * Filters a list of commands extracting the ones of the given types.
     *
     * @param commands the list of command to be filtered
     * @param types the command types to extract
     *
     * @return an array of the selected commmands
     */
    private List filterCommands(List commands, String[] types) {
        StringBuffer sb = new StringBuffer(",");

        for (int i = 0; ((types != null) && (i < types.length)); ++i) {
            sb.append(types[i]).append(',');
        }

        ArrayList selectedCommands = new ArrayList();
        AbstractCommand command = null;
        Iterator i = commands.iterator();
        while (i.hasNext()) {
            command = (AbstractCommand) i.next();

            if (sb.indexOf(',' + command.getName() + ',') >= 0) {
                selectedCommands.add(command);
            }
        }

        return selectedCommands;
    }

    /**
     * Create and return the status commands for the executed &lt;Sync&gt;s.
     *
     * @param syncCommands the Sync commands
     *
     * @return the status commands in a List collection
     */
    private List statusForSyncs(Sync[] syncCommands) {
        ArrayList ret = new ArrayList();

        String uri = null;
        Target target = null;
        Source source = null;
        TargetRef targetRef = null;
        SourceRef sourceRef = null;
        int statusCode = StatusCode.OK;
        for (int i = 0; (  (syncCommands     != null )
                        && (i < syncCommands.length)); ++i) {

            target = syncCommands[i].getTarget();
            source = syncCommands[i].getSource();

            //
            // A Sync command can be empty....
            //
            uri = (target==null) ? null : target.getLocURI();
            if ((uri == null) || (syncEngine.getClientSource(uri) != null)) {
                statusCode = StatusCode.OK;
            } else {
                statusCode = StatusCode.NOT_FOUND;
            }

            targetRef = (target == null) ? null : new TargetRef(uri);

            sourceRef = (source == null) ? null : new SourceRef(syncCommands[i].getSource());
            ret.add(
                new Status(
                        cmdIdGenerator.next(),
                        lastMsgIdFromClient,
                        syncCommands[i].getCmdID().getCmdID(),
                        syncCommands[i].COMMAND_NAME,
                        targetRef,
                        sourceRef,
                        null,
                        null,
                        new Data(statusCode),
                        new Item[0]
                )
            );
        } // next i

        return ret;
    }


    /**
     * Checks that the credentials of the given message are allowed to start a
     * session.
     *
     * @param credential the message
     * @param deviceId the deviceId
     */
    private boolean login(Cred credential, String deviceId) {
        //
        // May be the credential is already logged in...
        //
        logout();

        //
        // If the credential is not specified, create a new "guest" credential
        // but only if the property isGuestEnabled is true
        //
        if (credential == null) {

            if (syncEngine.isGuestEnabled()) {
                credential = Cred.getGuestCredential();
            } else {
                validCredentials = true;
                guestEnabled = false;
                return false;
            }
        }

        Sync4jPrincipal p = Sync4jPrincipal.fromCredential(credential.getData(),
                                                           credential.getType(),
                                                           deviceId            );

        if (syncEngine.login(credential)
                && syncEngine.authorize(p, SecurityConstants.RESOURCE_SESSION)) {

            loggedCredential = credential;
            loggedPrincipal  = p         ;

            validCredentials = true;

            return true;
        }

        return false;
    }

    /**
     * Logs out the logged in credential
     */
    private void logout() {
        if (isAuthenticated()) {
            syncEngine.logout(loggedCredential);
        }
        loggedCredential = null;
        loggedPrincipal  = null;
    }

    /**
     * Called by the <i>SyncBean</i> when the container release the session.
     * It commit the change to the DB, logs out the credential and
     * release aquired resources.
     */
    public void endSession() {
        commit();
        logout();
    }


    /**
     *	Checks if the message uses a separate initialization or not.
     *  If it contains &gt;Alert&lt; and &gt;Sync&lt; tag, it implies Sync with
     *  Initialization..
     *
     *	@param message Message to be checked for Sync with Initialization.
     *	@return TRUE (if syncWithInitialization) / FALSE (if not Sync with Init)
     *	@throws ProtocolException
    */
    private boolean checkSyncInit(SyncML message)
    throws ProtocolException{

		// check for the message of the SyncPackage
		// if it contains <alert> & <sync> tag, it implies Sync with Initialization..
		// As the Initialization process is completed, only <sync> package is needed
		// to be checked, but <alert> tag is also checked for Cross Verification.

    	AbstractCommand[] clientCommands =
            (AbstractCommand[])message.getSyncBody().getCommands().toArray(
                                                        new AbstractCommand[0]);

        List syncs  = ProtocolUtil.filterCommands(clientCommands    ,
                                                  Sync.class);
		List alerts = ProtocolUtil.filterCommands(clientCommands	,
                                                  Alert.class);

        return ((syncs.size() != 0) && (alerts.size() != 0));
	}

    /**
     * Checks if a message require a response from the client.<p>
     * A message requires a response if its body contains no commands other than
     * status commands.
     *
     * @param msg the message to check - NOT NULL and properly constructed
     *
     * @return true if the message requires a response, false otherwise
     *
     */
    private boolean noMoreResponse(SyncML msg) {
        AbstractCommand[] commands =
            (AbstractCommand[])msg.getSyncBody().getCommands().toArray(
                                                        new AbstractCommand[0]);

        for(int i=0; ((commands != null) && (i<commands.length)); ++i) {
            if (!Status.COMMAND_NAME.equals(commands[i].getName())) {
        	return false;
        }
	}

        return true;
    }

    /**
     * Resets the clientMappings map.
     */
    private void resetClientMappings() {
        clientMappings = new HashMap();
    }

    /**
     * Retrieves the existing LUID-GUID mappings for the logged in principal.
     * The mappings for all the databases involved in the synchronization are
     * loaded.
     *
     * @return a new <i>ClientMapping</i> object containing the mapping for the
     *         given client id
     *
     * @throws Sync4jException in case of error reading the mapping from the
     *         persistent store.
     */
    private void getClientMappings()
    throws Sync4jException {

        resetClientMappings();

        ClientMapping clientMapping = null;
        String uri = null;
        try {
            PersistentStore ps = syncEngine.getStore();

            for (int i = 0; ((syncEngine.getDbs() != null) && (i<syncEngine.getDbs().length)); ++i) {

                uri = (syncEngine.getDbs())[i].getName();

                clientMapping = new ClientMapping(loggedPrincipal, uri);

                ps.read(clientMapping);

                clientMappings.put(uri, clientMapping);
            }
        } catch (PersistentStoreException e) {
            log.severe("Unable to read clientMappings from the persistent store");
            throw new Sync4jException(e);
        }
    }

    /**
     * Stores the LUIG-GUID mappings into the database
     *
     * @throws Sync4jException in case of database error
     */
    private void storeClientMappings() throws Sync4jException {
        if (clientMappings == null) {
            return;
        }

        try {
            PersistentStore ps = syncEngine.getStore();

            ClientMapping cm = null;
            Iterator i = clientMappings.keySet().iterator();
            while (i.hasNext()) {
                cm = (ClientMapping)clientMappings.get(i.next());
                if (log.isLoggable(Level.FINE)) {
                    log.fine("Saving client mapping: " + cm);
                }
                ps.store(cm);
            }
        } catch (PersistentStoreException e) {
            log.severe("Unable to save clientMappings to the persistent store");
            throw new Sync4jException(e);
        }
    }

    /**
     * Read the given principal from the store. The principal must be
     * already configured with username and device. The current implementation
     * reads the following additional informatioin:
     * <ul>
     *  <li>principal id
     * </ul>
     *
     * @param principal the principal to be read
     *
     * @throws sync4j.framework.server.store.PersistentStoreException
     */
    private void readPrincipal(Sync4jPrincipal principal)
    throws PersistentStoreException {
        assert(principal               != null);
        assert(principal.getUsername() != null);
        assert(principal.getDeviceId() != null);

        PersistentStore ps = syncEngine.getStore();

        ps.read(principal);
    }

    private void readObject(java.io.ObjectInputStream in)
            throws java.io.IOException, ClassNotFoundException {
        in.defaultReadObject();
        log = Sync4jLogger.getLogger();
    }

    private String getStateName(int state) {
        String stateName = "STATE_UNKNOWN";

        switch (state) {
            case STATE_START                      : stateName = "STATE_START"                     ; break;
            case STATE_END                        : stateName = "STATE_END"                       ; break;
            case STATE_ERROR                      : stateName = "STATE_ERROR"                     ; break;
            case STATE_INITIALIZATION_PROCESSING  : stateName = "STATE_INITIALIZATION_PROCESSING" ; break;
            case STATE_INITIALIZATION_PROCESSED   : stateName = "STATE_INITIALIZATION_PROCESSED"  ; break;
            case STATE_SYNCHRONIZATION_PROCESSING : stateName = "STATE_SYNCHRONIZATION_PROCESSING"; break;
            case STATE_SYNCHRONIZATION_PROCESSED  : stateName = "STATE_SYNCHRONIZATION_PROCESSED" ; break;
            case STATE_SYNCHRONIZATION_COMPLETION : stateName = "STATE_SYNCHRONIZATION_COMPLETION"; break;
        }

        return stateName;
    }

    public SyncState getSyncState() {
        return this.syncState;
    }

    /**
     * This class compare two StatusCommand object in according to
     * the cmdRef
     */
    private static class StatusComparator implements java.util.Comparator {
        private StatusComparator() {
        }

        public int compare(Object o1, Object o2) {
            Object value1 = null;
            Object value2 = null;

            value1 = new Integer(((Status)o1).getCmdRef());
            value2 = new Integer(((Status)o2).getCmdRef());

            return ( (Integer)value1).compareTo((Integer)value2);
        }
    }
}