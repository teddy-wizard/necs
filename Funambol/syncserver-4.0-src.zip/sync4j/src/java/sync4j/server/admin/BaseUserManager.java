/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.admin;

import sync4j.framework.server.SyncUser;
import sync4j.framework.server.store.Clause;
import sync4j.framework.server.store.PersistentStoreException;

/**
 * This is a base class for <i>UserManager</i> objects. It does not manager
 * any object, but it provides services common to concrete implementations.
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: BaseUserManager.java,v 1.6 2004/04/13 09:35:28 luigia Exp $
 *
 */
public class BaseUserManager implements UserManager {

    // --------------------------------------------------------------- Constants

    // -------------------------------------------------------------- Properties

    // ------------------------------------------------------------ Private data

    // ------------------------------------------------------------ Constructors

    // ---------------------------------------------------------- Public methods

    public String[] getRoles() throws PersistentStoreException {
        return null;
    }

    public SyncUser[] getUsers(Clause clause) throws PersistentStoreException {
        return null;
    }

    public void setUser(SyncUser user) throws PersistentStoreException {
    }

    public void insertUser(SyncUser user) throws PersistentStoreException {
    }

    public void deleteUser(SyncUser user) throws PersistentStoreException {
    }

    public void getUserRoles(SyncUser user) throws PersistentStoreException {
    }

    public int countUsers(Clause clause) throws PersistentStoreException {
        return 0;
    }

}