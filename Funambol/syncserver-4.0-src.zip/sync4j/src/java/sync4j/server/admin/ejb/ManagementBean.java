/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.admin.ejb;

import javax.ejb.*;
import javax.naming.InitialContext;

import java.util.HashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Vector;

import java.sql.*;
import java.io.*;
import java.lang.reflect.Method;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.net.URL;
import java.net.MalformedURLException;

import org.kxml.wap.SyncMLWriter;
import org.kxml.parser.XmlParser;
import org.kxml.parser.ParseEvent;
import org.kxml.Xml;

import sync4j.framework.core.*;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.config.Configuration;
import sync4j.framework.config.ConfigClassLoader;
import sync4j.framework.config.ConfigurationException;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.server.error.*;
import sync4j.framework.tools.WBXMLTools;

import sync4j.framework.tools.beans.BeanFactory;
import sync4j.framework.tools.beans.BeanException;

import sync4j.framework.tools.DBTools;

import sync4j.server.admin.DBUserManager;
import sync4j.server.engine.Sync4jSource;

import sync4j.framework.engine.source.SyncSource;
import sync4j.framework.engine.source.SyncSourceException;

import sync4j.framework.security.Sync4jPrincipal;

import sync4j.framework.server.SyncUser;
import sync4j.framework.server.Sync4jDevice;
import sync4j.framework.server.Sync4jModule;
import sync4j.framework.server.Sync4jSourceType;
import sync4j.framework.server.Sync4jConnector;

import sync4j.framework.server.error.ServerException;

import sync4j.framework.server.store.Clause;
import sync4j.framework.server.store.WhereClause;
import sync4j.framework.server.store.LogicalClause;
import sync4j.framework.server.store.BasePersistentStore;
import sync4j.framework.server.store.PersistentStore;
import sync4j.framework.server.store.PersistentStoreException;
import sync4j.framework.server.store.NotFoundException;
import sync4j.framework.server.store.ConfigPersistentStoreException;

import java.beans.XMLEncoder;

import sync4j.server.admin.ManagementException;

/**
 *  This is the session enterprise java bean that handles the administration
 * console. It is designed to be a stateless session bean.
 *  <p>
 *  This server accepts the requests addressed to the hostname
 *  indicated by the configuration property pointed by {CONFIG_SERVER_URI} (see
 *  Sync4j.properties).
 *  <p>
 *  ManagementBean uses two environment properties:
 *  <ul>
 *    <li><i>{ENV_SERVER_CONFIG_URI}</i> contains the URI of the server
 *        configuration. It can be a file or any other kind of URI that returns
 *        a stream readable from the <i>java.util.Properties</i> class.
 *  </ul>
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: ManagementBean.java,v 1.2 2004/04/13 09:35:28 luigia Exp $
 *
 */
public class ManagementBean
        implements javax.ejb.SessionBean
{
    // ------------------------------------------------------- Private constants

    private static final String ENV_SERVER_CONFIG_URI
        = "java:comp/env/server/config_uri";
    private static final String ENV_SERVER_CONFIG_PATH
        = "java:comp/env/server/config_path";

    private static final String CFG_PERSISTENT_STORE = "engine.store";
    private static final String CONFIG_USER_MANAGER  = "user.manager";

    private static final String OPT_INSERT     = "INSERT";
    private static final String OPT_UPDATE     = "UPDATE";

    private static final String SEARCH_COUNT_DEVICES    = "SCD";
    private static final String SEARCH_COUNT_PRINCIPALS = "SCP";

    //This role is used only for authentication
    private static final String ROLE_SPECIAL = "special_sync_admin";

    // ------------------------------------------------------------ Private data

    private transient Logger log = null;

    private SessionContext sessionContext       = null;

    private Configuration config                = null;

    private PersistentStore ps					= null;

    private DBUserManager dbUserManager         = null;

    private URL configURI = null, configPath    = null;

    // ------------------------------------------------------------- EJB methods
    public void ejbCreate()
            throws CreateException {

        log = Sync4jLogger.getLogger("server");

        loadConfiguration();

        //
        // Set the underlying persistent store
        //
        HashMap psConfig = new HashMap(1);
        psConfig.put("class-loader", config.getClassLoader());
        ps = (PersistentStore)config.getBeanInstance(CFG_PERSISTENT_STORE);
        try {
            ps.configure(psConfig);
        } catch (ConfigPersistentStoreException e) {
            log.severe("Error configuring the persistent store: " + e);
            log.throwing(getClass().getName(), "<init>", e);

            throw new CreateException( "Error "
                                     + e.getClass().getName()
                                     + " creating the SyncBean: "
                                     + e.getMessage()
                                     );
        }

        dbUserManager = (DBUserManager)config.getBeanInstance(CONFIG_USER_MANAGER);
    }

    public Configuration getConfig() {
        return config;
    }

    public void ejbRemove() {
        log = null;
    }

    public void ejbActivate() {
        log = Sync4jLogger.getLogger();
    }

    public void ejbPassivate() {
        log = null;
    }

    public void setSessionContext (SessionContext sessionContext)
    throws EJBException {
        this.sessionContext = sessionContext;
    }

    /**
     * Read the list of roles available.
     *
     * @return names of roles available
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public String[] getRoles()
    throws ServerException, ManagementException {
        log.fine("ManagementBean method getRoles");
        String[] roles = null;

		try {

            roles = dbUserManager.getRoles();

            if (roles != null) {
                List l = Arrays.asList(roles);
                Vector v = new Vector(l);
                int size = v.size();
                for (int i=0; i<size; i++) {
                    String role = (String)v.get(i);
                    if (role.startsWith(ROLE_SPECIAL)) {
                        v.remove(i);
                        size = v.size();
					}
                }
                roles = (String[])v.toArray(new String[0]);
            }

		} catch (PersistentStoreException e) {
            String msg = "Error reading roles: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}
			log.throwing(getClass().getName(), "getRoles", e);

            throw new ServerException(msg, e);
		}
        return roles;
    }

    /**
     * Read all users that satisfy the parameter of search.
     *
     * @param clause array of conditions for the query
     *
     * @return array of SyncUser
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public SyncUser[] getUsers(Clause clause)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method getUsers");

        SyncUser[] users = null;
		try {

            users = dbUserManager.getUsers(clause);

            for (int i=0; (users != null) && i<users.length; i++) {
                dbUserManager.getUserRoles(users[i]);
            }

		} catch (PersistentStoreException e) {
            String msg = "Error reading Users: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}
			log.throwing(getClass().getName(), "getUsers", e);

            throw new ServerException(msg, e);
		}

		return users;
	}

    /**
     * Insert a new user and the assigned role to it
     *
     * @param user the user to insert
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void insertUser(SyncUser user)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method insertUser");

		try {

            dbUserManager.insertUser(user);

		} catch (PersistentStoreException e) {
            String msg = "Error inserting User: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}
			log.throwing(getClass().getName(), "insertUser", e);

            throw new ServerException(msg, e);
		}
	}

    /**
     * Update the information of the specific user
     *
     * @param user the user with informations updated
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void setUser(SyncUser user)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method setUser");

		try {

            dbUserManager.setUser(user);

		} catch (PersistentStoreException e) {
            String msg = "Error updating User: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}
			log.throwing(getClass().getName(), "setUser", e);

            throw new ServerException(msg, e);
		}
	}

    /**
     * Delete the user
     *
     * @param userName the name of user to delete
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void deleteUser(String userName)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method deleteUser");

		try {
            SyncUser user = new SyncUser(userName,null,null,null,null,null);
            dbUserManager.deleteUser(user);

		} catch (PersistentStoreException e) {
            String msg = "Error deleting User: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}
			log.throwing(getClass().getName(), "deleteUser", e);

            throw new ServerException(msg, e);
		}
	}

    public void importUser(SyncUser user)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method importUser");
        throw new ManagementException("Not implemented yet");
    }

    /**
     * Count the number of users that satisfy the specif clauses.
     *
     * @param clause the conditions of the search
     *
     * @return number of users
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public int countUsers(Clause clause)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method countUsers");
        int n = 0;

		try {

            n = dbUserManager.countUsers(clause);

		} catch (PersistentStoreException e) {
            String msg = "Error counting users: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "countUsers", e);

            throw new ServerException(msg, e);
		}
        return n;
    }

    /**
     * Read a list of device that satisfy the specific conditions.
     *
     * @param clauses the conditions foe search informations.
     *
     * @return array of device
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public Sync4jDevice[] getDevices(Clause clauses)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method getDevices");
        Sync4jDevice[] devices = null;

		try {

            devices = (Sync4jDevice[])ps.read(new Sync4jDevice(), clauses);

		} catch (PersistentStoreException e) {
            String msg = "Error reading devices: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "getDevices", e);

            throw new ServerException(msg, e);
		}
		return devices;
	}

    /**
     * Insert a new device.
     *
     * @param d the new device
     *
     * @return the device id
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public String insertDevice(Sync4jDevice d)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method insertDevice");
		try {

			ps.store(d);

		} catch (PersistentStoreException e) {
            String msg = "Error adding device: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertDevice", e);

            throw new ServerException(msg, e);
		}
        return d.getDeviceId();
	}

    /**
     * Update the information of specific device.
     *
     * @param d the device to update
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void setDevice(Sync4jDevice d)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method setDevice");
		try {

			ps.store(d);

		} catch (PersistentStoreException e) {
            String msg = "Error updating device: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "setDevice", e);

            throw new ServerException(msg, e);
		}
	}

    /**
     * Delete the specific device.
     *
     * @param deviceId the device id that identifies the device
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void deleteDevice(String deviceId)
    throws ServerException, ManagementException{
        log.fine("ManagementBean method deleteDevice");
		try {
            Sync4jDevice sd = new Sync4jDevice(deviceId, null, null);
            ps.delete(sd);

		} catch (PersistentStoreException e) {
            String msg = "Error deleting device: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "deleteDevice", e);

            throw new ServerException(msg, e);
		}
    }

    /**
     * Count the number of device that satisfy the specific clauses.
     *
     * @param clauses the specific conditions for search device
     *
     * @return the number of device finds
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public int countDevices(Clause clauses)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method countDevices");
        int n = 0;

		try {

            String[] obj = (String[])ps.read(SEARCH_COUNT_DEVICES, clauses);
            n = Integer.parseInt(obj[0]);

		} catch (PersistentStoreException e) {
            String msg = "Error counting devices: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "countDevices", e);

            throw new ServerException(msg, e);
		}
		return n;
	}

    /**
     * Read all principal that satisfy the clauses.
     *
     * @param clauses the specific conditions for search principal
     *
     * @return array of principal
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public Sync4jPrincipal[] getPrincipals(Clause clauses)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method getPrincipals");

        Sync4jPrincipal[] principals = null;

		try {

			principals = (Sync4jPrincipal[])ps.read(new Sync4jPrincipal(null,null,null), clauses);

		} catch (PersistentStoreException e) {
            String msg = "Error reading principals: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "getPrincipals", e);

            throw new ServerException(msg, e);
		}
		return principals;
	}

    /**
     * Insert a new principal.
     *
     * @param p the new principal
     *
     * @return the principal id
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public String insertPrincipal(Sync4jPrincipal p)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method insertPrincipal");
		try {

			ps.store(p);

		} catch (PersistentStoreException e) {
            String msg = "Error adding rincipal: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertPrincipal", e);

            throw new ServerException(msg, e);
		}
        return p.getId();
	}

    /**
     * Delete the specific principal.
     *
     * @param principalId the principal id that identifies the principal
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void deletePrincipal(String principalId)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method deletePrincipal");
		try {
            Sync4jPrincipal sp = new Sync4jPrincipal(principalId, null, null);
            ps.delete(sp);

		} catch (PersistentStoreException e) {
            String msg = "Error deleting principal: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "deletePrincipal", e);

            throw new ServerException(msg, e);
		}
	}

    /**
     * Count the number of principal that satisfy the specific clauses.
     *
     * @param clauses the specific conditions for search principal
     *
     * @return the number of principal finds
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public int countPrincipals(Clause clauses)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method countPrincipals");
        int n = 0;

		try {

            String[] obj = (String[])ps.read(SEARCH_COUNT_PRINCIPALS, clauses);
            n = Integer.parseInt(obj[0]);

		} catch (PersistentStoreException e) {
            String msg = "Error counting principals: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "countPrincipals", e);

            throw new ServerException(msg, e);
		}
		return n;
	}

    /**
     * Read all modules information
     *
     * @return an array with the modules information (empty if no objects are found)
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public Sync4jModule[] getModulesName()
    throws ServerException, ManagementException {
        log.fine("ManagementBean method getModulesName");

        Sync4jModule[] module = null;

		try {

			module = (Sync4jModule[])ps.read(Sync4jModule.class);

		} catch (PersistentStoreException e) {
            String msg = "Error reading modules: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "getPrincipals", e);

            throw new ServerException(msg, e);
		}

        return module;
    }

    /**
     * Read the information of the specific module
     *
     * @param moduleId the module id that identifies the module to search
     *
     * @return the relative information to the module
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public Sync4jModule getModule(String moduleId)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method getModule");

        Sync4jModule module = null;

        Sync4jConnector[] sc0 = null;
        Sync4jSourceType[] sst0 = null; Sync4jSourceType[] sst1 = null;
        SyncSource[] ss0 = null;

		try {

            module = new Sync4jModule(moduleId, null, null);
            ps.read(module);

            //for each SyncConnector read the SyncSourceType and
            //for each SyncSourceType read the SyncSource
            Sync4jConnector[] syncConnectors = module.getConnectors();
            for (int i=0; (syncConnectors != null) && i<syncConnectors.length; i++) {
                Sync4jConnector sc = syncConnectors[i];
                Sync4jSourceType[] syncSourceTypes = sc.getSourceTypes();

                for (int y=0; (syncSourceTypes != null) && y<syncSourceTypes.length; y++) {
                    Sync4jSource[] sync4jSources = (Sync4jSource[])ps.read(syncSourceTypes[y], null);

                    ArrayList syncSources = new ArrayList();
                    ArrayList syncSourcesFailed = new ArrayList();

                    for (int z=0; z<sync4jSources.length; z++) {

                        try {
                            SyncSource syncSource = (SyncSource)BeanFactory.getNoInitBeanInstance(
                                                 config.getClassLoader(),
                                                 sync4jSources[z].getConfig()
                                           );
                            syncSources.add(syncSource);

                        } catch (BeanException e) {
                            Throwable t = e.getCause();

                            String msg = "Error creating SyncSource "
                                       + module.getModuleName()
                                       + "/"
                                       + sc.getConnectorName()
                                       + "/"
                                       + syncSourceTypes[y].getDescription()
                                       + "/"
                                       + sync4jSources[z].getUri();

                            if ( t != null)
                                msg += ": " + t.getMessage();

                            log.throwing(getClass().getName(), "getModule", t);

                            syncSourcesFailed.add(
                                new SyncSourceException(
                                    sync4jSources[z].getUri(),
                                    sync4jSources[z].getConfig(),
                                    t)
                                );
                        }
                    }

                    SyncSource[] syncSourcesOK = (SyncSource[])syncSources.toArray(new SyncSource[syncSources.size()]);
                    syncSourceTypes[y].setSyncSources(syncSourcesOK);

                    SyncSourceException[] syncSourcesNO = (SyncSourceException[])syncSourcesFailed.toArray(new SyncSourceException[syncSourcesFailed.size()]);
                    syncSourceTypes[y].setSyncSourcesFailed(syncSourcesNO);
                }
            }

        } catch (PersistentStoreException e) {
            String msg = "Error getting module: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe("Error getting Module: " + e.getMessage());
			}
			log.throwing(getClass().getName(), "getModule", e);

            throw new ServerException(msg, e);
        }

        return module;
    }

    public void insertModule(Sync4jModule module, byte[] filess4j)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method insertModule");
        throw new ManagementException("Not implemented yet");
    }

    public void deleteModule(String moduleId)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method deleteModule");
        throw new ManagementException("Not implemented yet");
    }

    /**
     * Insert a new source into datastore and create a relative file xml with configuration.
     * The source must have a defined source type.
     * The source type must refer to a connector.
     * The connector must refer to a module.
     *
     * @param moduleId the module id
     * @param connectorId the connector id
     * @param sourceTypeId the source type id
     * @param source the information of the new source
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void insertSource(String moduleId, String connectorId, String sourceTypeId, SyncSource source)
    throws ServerException, ManagementException {
        log.fine("ManagementBean method insertSource");

        String uri = source.getSourceURI();
        String sourceName = source.getName();

        String config = moduleId+File.separator+connectorId+File.separator+sourceTypeId;

        Sync4jSource s4j = new Sync4jSource(uri,config+File.separator+sourceName+".xml",sourceTypeId,sourceName);

        //
        //checking for the existance of the source before inserting
        //
        Sync4jSource existSource[] = null;
        try {

            WhereClause[] wc = new WhereClause[2];
            String value[] = new String[1];
            value[0] = uri;
            wc[0] = new WhereClause("uri",value, WhereClause.OPT_EQ, false);

            value[0] = sourceName;
            wc[1] = new WhereClause("name",value, WhereClause.OPT_EQ, false);
            LogicalClause lc = new LogicalClause(LogicalClause.OPT_OR, wc);

            existSource = (Sync4jSource[])ps.read(s4j, lc);

        } catch (PersistentStoreException e) {
            String msg = "Error reading sources existing: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertSource", e);

            throw new ServerException(msg, e);
        }

        if (existSource == null || existSource.length == 0) {
            try {

                ps.store(sourceTypeId, s4j, OPT_INSERT);

            } catch (PersistentStoreException e) {
                String msg = "Error adding the SyncSource: " + e.getMessage();
                if (log.isLoggable(Level.SEVERE)) {
                    log.severe(msg);
                }

                log.throwing(getClass().getName(), "insertSource", e);

                throw new ServerException(msg, e);
            }
        } else {
            String msg = "A SyncSource with URI "
                        + uri + " or with Name " + sourceName
                        + " is already present.";

            throw new ManagementException(msg);
        }

        try {

            String path = configPath + config;
            if (path.startsWith("file:")) path = path.substring(6);

            File f = new File(path);
            f.mkdirs();

            XMLEncoder encoder = null;
            encoder = new XMLEncoder(new FileOutputStream(path+File.separator+sourceName+".xml"));
            encoder.writeObject((Object)source);
            encoder.flush();
            encoder.close();

        } catch(FileNotFoundException e) {
            String msg = "Error storing the SyncSource on file system: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertSource", e);

            throw new ServerException(msg, e);
        }
	}

    /**
     * Update a specific source into datastore and create a relative file xml with configuration.
     * The source must have a defined source type.
     * The source type must refer to a connector.
     * The connector must refer to a module.
     *
     * @param moduleId the module id
     * @param connectorId the connector id
     * @param sourceTypeId the source type id
     * @param source the information of the new source
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void setSource(String moduleId, String connectorId, String sourceTypeId, SyncSource source)
    throws ServerException, ManagementException{
        log.fine("ManagementBean method setSource");

        String uri = source.getSourceURI();
        String sourceName = source.getName();

        String config = moduleId
                      + File.separator
                      + connectorId
                      + File.separator
                      + sourceTypeId
                      ;

        Sync4jSource s4j = new Sync4jSource(uri,null,sourceTypeId,null);

        try {

            ps.read(s4j);

        } catch (PersistentStoreException e) {
            String msg = "Error reading sources existing: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertSource", e);

            throw new ServerException(msg, e);
        }

        s4j.setSourceName(sourceName);

        String nameFileXml = s4j.getConfig().substring(config.length() + 1);

		try {

            ps.store(sourceTypeId, s4j, OPT_UPDATE);

		} catch (PersistentStoreException e) {
            String msg = "Error storing SyncSource: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertSource", e);

            throw new ServerException(msg, e);
		}

        try {

            String path = configPath + config;
            if (path.startsWith("file:")) path = path.substring(6);

            File f = new File(path);
            f.mkdirs();

            XMLEncoder encoder = null;
            encoder = new XMLEncoder(new FileOutputStream(path+File.separator+nameFileXml));
            encoder.writeObject((Object)source);
            encoder.flush();
            encoder.close();

        } catch(FileNotFoundException e) {
            String msg = "Error storing SyncSource: " + e.getMessage();
			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "insertSource", e);

            throw new ServerException(msg, e);
        }
	}

    /**
     * Delete a specific source and the relative file of configuration.
     *
     * @param sourceUri the uri that identifies the source
     *
     * @throws ServerException
     * @throws ManagementException
     */
    public void deleteSource(String sourceUri)
    throws ServerException, ManagementException{
        log.fine("ManagementBean method deleteSource");

        Sync4jSource s4j = new Sync4jSource(sourceUri,null,null,null);
		try {

			ps.read(s4j);

		} catch (PersistentStoreException e) {
            String msg = "Error reading source: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "deleteSource", e);

            throw new ServerException(msg, e);
		}

		try {
            ps.delete(s4j);

		} catch (PersistentStoreException e) {
            String msg = "Error deleting SyncSource: " + e.getMessage();

			if (log.isLoggable(Level.SEVERE)) {
				log.severe(msg);
			}

			log.throwing(getClass().getName(), "deleteSource", e);

            throw new ServerException(msg, e);
		}

        String path = configPath + s4j.getConfig();
        if (path.startsWith("file:")) path = path.substring(6);

        File f = new File(path);
        f.delete();
	}

    // --------------------------------------------------------- private methods

    /**
     * Loads the configuration for the server. The URI from which the configuration
     * is must be set as the envirnoment property named as <i>ENV_SERVER_CONFIG_URI</i>.
     *
     * @throws ConfigurationException in case of errors.
     */
    private void loadConfiguration()
    throws ConfigurationException {

        config = new Configuration();

        try {
            InitialContext ctx = new InitialContext();

            //
            // The following two entries should be two URIs, but in the case
            // they are not (they do not start with http://, https:// or file://,
            // they are considered simple files
            //
            configURI  = fixURI((String)ctx.lookup(ENV_SERVER_CONFIG_URI ));
            configPath = fixURI((String)ctx.lookup(ENV_SERVER_CONFIG_PATH));

            config.setClassLoader(
                new ConfigClassLoader(
                    new URL[] { configPath },
                    getClass().getClassLoader()
                )
            );

            config.load(configURI.toString());

            if (log.isLoggable(Level.FINEST)) {
                log.finest("Configuration: " + config);
            }
        } catch (ConfigurationException e) {
            e.printStackTrace();
            throw e;
        } catch (Exception e) {
            throw new ConfigurationException("Error loading configuration from " + configURI, e);
        }
    }

    /**
     * Checks if the given string is an accepted URL (starting with http://,
     * https:// or file://). If yes, a new URL object representing the given
     * url is returned; otherwise, the given string is considered a file name
     * and a new URL is obtained calling File.toURL().
     *
     * @param s the string to check
     *
     * @return the corresponding URL if the string represents a URL or the
     *         fixed URL if the string is a pathname/filename
     *
     * @throws MalformedURLException
     */
    private URL fixURI(final String s)
    throws MalformedURLException {
        String minS = s.toLowerCase();

        try {
            return new URL(s);
        } catch (MalformedURLException e) {
            //
            // This is not a URL, let's consider it just a file
        }

        try {
            return new File(new File(s).getCanonicalPath()).toURL();

        } catch (IOException e) {
            throw new MalformedURLException("Unable to convert" + s + " to a URL");
        }
    }

}