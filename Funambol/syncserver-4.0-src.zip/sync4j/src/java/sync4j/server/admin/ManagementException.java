/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.admin;

/**
 * This exception class represents an error condition in the management domain.
 * Note this is not the case of low level server errors such as database errors,
 * but it is for high level errors like "user already present" or "you can't
 * do this if you do not do that first".
 *
 * Note also, that the message exception should be a human, final user readeable
 * message (it must be meaningfull for the end user). 
 *
 * @author  Stefano Fornari
 */
public class ManagementException extends Exception {
    
    /** Creates a new instance of ManagementException */
    public ManagementException() {
        super();
    }
    
    /** Creates a new instance of ManagementException */
    public ManagementException(String msg) {
        super(msg);
    }
    
    /** Creates a new instance of ManagementException */
    public ManagementException(String msg, Throwable cause) {
        super(msg, cause);
    }
}