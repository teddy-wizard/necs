/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.server.admin.ejb;

import javax.ejb.*;

import java.util.Hashtable;

import sync4j.framework.server.SyncUser;
import sync4j.framework.server.Sync4jDevice;
import sync4j.framework.server.store.Clause;

import sync4j.framework.config.Configuration;
import sync4j.framework.security.Sync4jPrincipal;
import sync4j.framework.engine.source.SyncSource;

import sync4j.framework.server.error.ServerException;

import sync4j.server.admin.ManagementException;
import sync4j.framework.server.Sync4jModule;

/**
 *
 * @author Luigia Fassina @ Funambol
 *
 * @version $Id: ManagementLocal.java,v 1.2 2004/04/13 09:35:28 luigia Exp $
 *
 */
public interface ManagementLocal extends EJBLocalObject {

    /**
     * CONFIGURATION
     */
    public Configuration getConfig();

    /**
     * USER
     */
    public String[] getRoles()
    throws ServerException, ManagementException;

    public SyncUser[] getUsers(Clause clause)
    throws ServerException, ManagementException;

    public void insertUser(SyncUser u)
    throws ServerException, ManagementException;

    public void setUser(SyncUser u)
    throws ServerException, ManagementException;

    public void deleteUser(String userName)
    throws ServerException, ManagementException;

    public void importUser(SyncUser u)
    throws ServerException, ManagementException;
    
    public int countUsers(Clause clause)
    throws ServerException, ManagementException;


	/**
	 * DEVICE
	 */
    public Sync4jDevice[] getDevices(Clause clause)
    throws ServerException, ManagementException;

    public String insertDevice(Sync4jDevice d)
    throws ServerException, ManagementException;

    public void setDevice(Sync4jDevice d)
    throws ServerException, ManagementException;

    public void deleteDevice(String deviceId)
    throws ServerException, ManagementException;
    
    public int countDevices(Clause clause)
    throws ServerException, ManagementException;


	/**
	 * PRINCIPAL
	 */
    public Sync4jPrincipal[] getPrincipals(Clause clause)
    throws ServerException, ManagementException;

    public String insertPrincipal(Sync4jPrincipal p)
    throws ServerException, ManagementException;

    public void deletePrincipal(String principalId)
    throws ServerException, ManagementException;
    
    public int countPrincipals(Clause clause)
    throws ServerException, ManagementException;
    

	/**
	 * MODULE
	 */
    public Sync4jModule[] getModulesName()
    throws ServerException, ManagementException;

    public Sync4jModule getModule(String moduleId)
    throws ServerException, ManagementException;

    public void insertModule(Sync4jModule syncModule, byte[] filess4j)
    throws ServerException, ManagementException;

    public void deleteModule(String moduleId)
    throws ServerException, ManagementException;

    /**
     * SOURCE
     */
    public void insertSource(String moduleId, String connectorId, String sourceTypeId, SyncSource source)
    throws ServerException, ManagementException;

    public void setSource(String moduleId, String connectorId, String sourceTypeId, SyncSource source)
    throws ServerException, ManagementException;

    public void deleteSource(String sourceUri)
    throws ServerException, ManagementException;

}