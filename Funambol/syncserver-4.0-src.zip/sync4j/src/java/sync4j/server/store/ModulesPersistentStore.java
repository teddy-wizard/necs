/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.store;

import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Set;
import java.util.Iterator;

import java.sql.*;

import sync4j.server.store.EnginePersistentStore;

import sync4j.server.engine.Sync4jSource;

import sync4j.framework.tools.DBTools;
import sync4j.framework.engine.source.SyncSource;
import sync4j.framework.server.Sync4jSourceType;
import sync4j.framework.server.store.*;
import sync4j.framework.server.store.PersistentStoreException;
import sync4j.framework.security.Sync4jPrincipal;

import org.apache.commons.lang.StringUtils;

import sync4j.framework.server.Sync4jModule;
import sync4j.framework.server.Sync4jConnector;

/**
 *
 * @author  Luigia Fassina @ Funambol
 *
 * @version $Id: ModulesPersistentStore.java,v 1.3 2004/04/13 09:35:29 luigia Exp $
 *
 */
public class ModulesPersistentStore
extends BasePersistentStore
implements PersistentStore, java.io.Serializable {

    // --------------------------------------------------------------- Constants
    public static final int SQL_SELECT_ALL_MODULES_NAME          = 0;
    public static final int SQL_GET_MODULE                       = 1;
    public static final int SQL_SELECT_MODULE_CONNECTOR          = 2;
    public static final int SQL_SELECT_CONNECTOR_SYNCSOURCETYPE  = 3;
    public static final int SQL_SELECT_SYNCSOURCETYPE_SYNCSOURCE = 4;

    // -------------------------------------------------------------- Properties

    private String[] sql = null;

    public void setSql(String[] sql) {
        this.sql = sql;
    }

    public String[] getSql() {
        return this.sql;
    }

    // ------------------------------------------------------------ Private data
    // ------------------------------------------------------------ Constructors
    // ---------------------------------------------------------- Public methods

    public boolean delete(Object o)
    throws PersistentStoreException {
        return false;
    }

    public Object[] delete(Class objClass) throws PersistentStoreException
    {
        return new Object[0];
    }

    public boolean store(String id, Object o, String operation) throws PersistentStoreException {
        return false;
    }

    public boolean store(Object o)
    throws PersistentStoreException {
        return false;
    }

    public boolean read(Object o)
    throws PersistentStoreException {
        if (o instanceof Sync4jModule) {
            readModule((Sync4jModule) o);
            return true;
        }

        return false;
    }

    public Object[] read(Class objClass) throws PersistentStoreException {
        if (objClass.equals(Sync4jModule.class)) {
            return readModulesName();
        }
        return null;
    }

    /**
     * Read all informations
     * @param object whichever object Sync
     * @param clause condition where for select - NOT USED
     *
     * @return Object[] array of object
     */
    public Object[] read(Object o, Clause clause) throws PersistentStoreException {
        if (o instanceof Sync4jSourceType) {
            return readSyncSource((Sync4jSourceType) o);
        }

        return null;
    }

    // --------------------------------------------------------- Private methods
    private Object[] readModulesName()
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        ArrayList ret = new ArrayList();

        try {
            conn = dataSource.getConnection();

            stmt = conn.prepareStatement(sql[SQL_SELECT_ALL_MODULES_NAME]);

            rs = stmt.executeQuery();

            while (rs.next()) {
                ret.add(
                    new Sync4jModule(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3)
                    )
                );
            }

            return ret.toArray(new Sync4jModule[ret.size()]);
        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading modules name", e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
    }

    private void readModule(Sync4jModule module)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = dataSource.getConnection();

            stmt = conn.prepareStatement(sql[SQL_GET_MODULE]);
            stmt.setString(1, module.getModuleId());

            rs = stmt.executeQuery();

            if (rs.next() == false) {
                throw new NotFoundException("Module not found for "
                + module.getModuleId()
                );
            }
            module.setModuleId(rs.getString(1));
            module.setModuleName(rs.getString(2));
            module.setDescription(rs.getString(3));

            //get all connectors for this module
            Sync4jConnector[] syncConnectors = (Sync4jConnector[])this.readModuleConnectors(module);
            module.setConnectors(syncConnectors);

            //for each SyncConnector select the SyncSourceType
            for (int i=0; (syncConnectors != null) && i<syncConnectors.length; i++) {
                Sync4jConnector sc = syncConnectors[i];
                Sync4jSourceType[] sst = (Sync4jSourceType[])this.readSyncSourceType(sc);

                sc.setSourceTypes(sst);
            }

        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading the module " + module, e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
    }

    private Object[] readModuleConnectors(Sync4jModule module)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList ret = new ArrayList();

        try {
            conn = dataSource.getConnection();

            stmt = conn.prepareStatement(sql[SQL_SELECT_MODULE_CONNECTOR]);
            stmt.setString(1, module.getModuleId());

            rs = stmt.executeQuery();

            while (rs.next()) {
                ret.add(
                    new Sync4jConnector(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                    )
                );
            }

            return ret.toArray(new Sync4jConnector[ret.size()]);

        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading the connectors ", e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
    }

    private Object[] readSyncSourceType(Sync4jConnector sc)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList ret = new ArrayList();

        try {
            conn = dataSource.getConnection();

            stmt = conn.prepareStatement(sql[SQL_SELECT_CONNECTOR_SYNCSOURCETYPE]);
            stmt.setString(1, sc.getConnectorId());

            rs = stmt.executeQuery();

            while (rs.next()) {
                ret.add(
                    new Sync4jSourceType(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                    )
                );
            }

            return ret.toArray(new Sync4jSourceType[ret.size()]);

        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading the SyncSourceType ", e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
    }

    private Object[] readSyncSource(Sync4jSourceType sst)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        ArrayList ret = new ArrayList();

        try {
            conn = dataSource.getConnection();

            stmt = conn.prepareStatement(sql[SQL_SELECT_SYNCSOURCETYPE_SYNCSOURCE]);
            stmt.setString(1, sst.getSourceTypeId());

            rs = stmt.executeQuery();

            while (rs.next()) {
                ret.add(
                    new Sync4jSource(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                    )
                );
            }

            return ret.toArray(new Sync4jSource[ret.size()]);

        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading the SyncSource ", e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
    }
}