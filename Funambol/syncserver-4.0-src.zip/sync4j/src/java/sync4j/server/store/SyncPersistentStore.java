/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.store;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Logger;
import java.util.logging.Level;

import java.sql.*;

import sync4j.framework.tools.DBTools;
import sync4j.framework.logging.Sync4jLogger;

import sync4j.framework.server.LastTimestamp;
import sync4j.framework.server.ClientMapping;
import sync4j.framework.server.store.Clause;
import sync4j.framework.server.store.PersistentStore;
import sync4j.framework.server.store.BasePersistentStore;
import sync4j.framework.server.store.NotFoundException;
import sync4j.framework.server.store.PersistentStoreException;

/**
 * This is the store for information regarding the synchronization process and
 * status. It persists the following classes:
 *
 * <ul>
 * <li>sync4j.framework.server.LastTimestamp</li>
 * <li>sync4j.framework.server.ClientMapping</li>
 * </ul>
 *
 * This <i>PersistentStore</i> is configured with the following map key:
 * <ul>
 *  <li>jndiDataSourceName</li>
 * </ul>
 *
 * @author Stefano Fornari @ Funambol
 * @author Richard Wafer
 *
 * @version $Id: SyncPersistentStore.java,v 1.17 2004/04/13 09:35:29 luigia Exp $
 */
public class SyncPersistentStore 
extends    BasePersistentStore
implements PersistentStore, java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    // -------------------------------------------------------------- Properties
    
    // ------------------------------------------------------------ Private data
    
    // ------------------------------------------------------------ Constructors
    
    // ---------------------------------------------------------- Public methods
    
    public boolean store(Object o)
    throws PersistentStoreException {
        if (o instanceof LastTimestamp) {
            storeLastTimestamp((LastTimestamp) o);
            return true;
        } else if (o instanceof ClientMapping) {
            storeClientMapping((ClientMapping) o);
            return true;
        }
        
        return false;
    }
    
    public boolean read(Object o)
    throws PersistentStoreException {
        if (o instanceof LastTimestamp) {
            readLastTimestamp((LastTimestamp) o);
            return true;
        } else if (o instanceof ClientMapping) {
            readClientMapping((ClientMapping) o);
            return true;
        }
        
        return false;
    }
    
    /** Read all objects stored the persistent media.
     *
     * @param objClass the object class handled by the persistent store
     *
     * @return an array containing the objects read. If no objects are found an
     *         empty array is returned. If the persistent store has not
     *         processed the quest, null is returned.
     *
     * @throws PersistentStoreException
     *
     */
    public Object[] read(Class objClass) throws PersistentStoreException {
        //
        // TO DO (not used yet)
        //
        return null;
    }

    
    // ------------------------------------------------------- Protected methods
    // --------------------------------------------------------- Private methods
    private void storeLastTimestamp(LastTimestamp l)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = dataSource.getConnection();
                        
            stmt = conn.prepareStatement(sqlUpdateLastTimestamp);
            
            stmt.setString   (1, l.tag                );
            stmt.setTimestamp(2, new Timestamp(l.start));
            stmt.setTimestamp(3, new Timestamp(l.end)  );
            stmt.setString   (4, l.principal           );
            stmt.setString   (5, l.database            );
            
            int n = stmt.executeUpdate();
            
            if (n == 0) {
                //
                // The first time!!!
                //
                stmt.close();

                stmt = conn.prepareStatement(sqlInsertLastTimestamp);
                
                stmt.setString   (1, l.principal           );
                stmt.setString   (2, l.database            );
                stmt.setString   (3, l.tag                 );
                stmt.setTimestamp(4, new Timestamp(l.start));
                stmt.setTimestamp(5, new Timestamp(l.end)  );
                
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            throw new PersistentStoreException("Error storing last timestamp", e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
    }
    
    protected void readLastTimestamp(LastTimestamp l)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = dataSource.getConnection();
                        
            stmt = conn.prepareStatement(sqlSelectLastTimestamp);
            
            stmt.setString(1, l.principal);
            stmt.setString(2, l.database);
            
            rs = stmt.executeQuery();
            
            if (rs.next() == false) {
                throw new NotFoundException("Last timestamp not found for "
                + l.toString()
                );
            }
            
            l.tag   = rs.getString   (1)          ;
            l.start = rs.getTimestamp(2).getTime();
            l.end   = rs.getTimestamp(3).getTime();
        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading last timestamp", e);
        } finally {
            DBTools.close(conn, stmt, rs);
        }
    }
    
    private void readClientMapping(ClientMapping clientMapping)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = dataSource.getConnection();
                        
            stmt = conn.prepareStatement(sqlSelectClientMapping);
            stmt.setString(1, clientMapping.getPrincipal().getId());
            stmt.setString(2, clientMapping.getDbURI()            );
            rs = stmt.executeQuery();
            HashMap mapping = new HashMap();
            while (rs.next()) {
                mapping.put(rs.getString("luid"), rs.getString("guid"));
            }
            clientMapping.initializeFromMapping(mapping);
        } catch (SQLException e) {
            throw new PersistentStoreException("Error reading mapping", e);
        } finally {
            DBTools.close(conn, stmt, rs);
        }
    }
    
    private void storeClientMapping(ClientMapping clientMapping)
    throws PersistentStoreException {
        Connection conn = null;
        PreparedStatement stmt = null, stmtIns = null;
        
        String principal = clientMapping.getPrincipal().getId();
        String dbURI     = clientMapping.getDbURI()            ;
        
        assert ((principal != null) && (dbURI != null));
        
        try {
            conn = dataSource.getConnection();
            
            if (clientMapping.isDeleted()) {
                stmt = conn.prepareStatement(sqlDeleteClientMapping);
                stmt.setString(1, principal);
                stmt.setString(2, dbURI    );
                Map clientMap = clientMapping.getDeletedEntries();
                Iterator i = clientMap.keySet().iterator();
                while (i.hasNext()) {
                    String key = (String) i.next();
                    stmt.setString(3, key);
                    stmt.executeUpdate();
                }
            }
            
            if (clientMapping.isModified()) {
                stmt = conn.prepareStatement(sqlUpdateClientMapping);
                stmt.setString(2, principal);
                stmt.setString(3, dbURI    );
                Map clientMap = clientMapping.getModifiedEntries();
                Iterator i = clientMap.keySet().iterator();
                while (i.hasNext()) {
                    int n = -1;
                    
                    String key = (String) i.next();
                    stmt.setString(4, key);
                    stmt.setString(1, (String) clientMap.get(key));
                    n = stmt.executeUpdate();
                    
                    if (n == 0) {
                        //
                        // insert new mapping
                        //
                        stmtIns = conn.prepareStatement(sqlInsertClientMapping);
                        stmtIns.setString(1, principal);
                        stmtIns.setString(2, dbURI    );
                        
                        stmtIns.setString(3, key);
                        stmtIns.setString(4, (String) clientMap.get(key));
                        stmtIns.executeUpdate();
                        stmtIns.close();
                    }
                    
                }
            }
            
        } catch (SQLException e) {
            throw new PersistentStoreException("Error storing client mapping", e);
        } finally {
            DBTools.close(conn, stmt, null);
        }
        
    }

    // ---------------------------------------------------------- SQL properties
    
    /**
     * The SQL query to insert the last timestamp
     */
    private String sqlInsertLastTimestamp =
    "insert into sync4j_last_sync (principal, sync_source, last_anchor, start_sync, end_sync) values(?, ?, ?, ?, ?)";
    
    /** Getter for property sqlInsertLastTimestamp.
     * @return Value of property sqlInsertLastTimestamp.
     *
     */
    public String getSqlInsertLastTimestamp() {
        return sqlInsertLastTimestamp;
    }
    
    /** Setter for property sqlInsertLastTimestamp.
     * @param sqlInsertLastTimestamp New value of property sqlInsertLastTimestamp.
     *
     */
    public void setSqlInsertLastTimestamp(String sqlInsertLastTimestamp) {
        this.sqlInsertLastTimestamp = sqlInsertLastTimestamp;
    }
    
    /**
     * The SQL query to update the last timestamp
     */
    private String sqlUpdateLastTimestamp =
    "update sync4j_last_sync set last_anchor=?,start_sync=?,end_sync=? where principal=? and sync_source=?";
    
    /** Getter for property sqlUpdateLastTimestamp.
     * @return Value of property sqlUpdateLastTimestamp.
     *
     */
    public String getSqlUpdateLastTimestamp() {
        return sqlUpdateLastTimestamp;
    }
    
    /** Setter for property sqlUpdateLastTimestamp.
     * @param sqlUpdateLastTimestamp New value of property sqlUpdateLastTimestamp.
     *
     */
    public void setSqlUpdateLastTimestamp(String sqlUpdateLastTimestamp) {
        this.sqlUpdateLastTimestamp = sqlUpdateLastTimestamp;
    }
    
    /**
     * The SQL query to select the last timestamp
     */
    private String sqlSelectLastTimestamp =
    "select last_anchor,start_sync,end_sync from sync4j_last_sync where principal=? and sync_source=?";
    
    /** Getter for property sqlUpdateLastTimestamp.
     * @return Value of property sqlUpdateLastTimestamp.
     *
     */
    public String getSqlSelectLastTimestamp() {
        return sqlSelectLastTimestamp;
    }
    
    /** Setter for property sqlUpdateLastTimestamp.
     * @param sqlSelectLastTimestamp New value of property sqlUpdateLastTimestamp.
     *
     */
    public void setSqlSelectLastTimestamp(String sqlSelectLastTimestamp) {
        this.sqlSelectLastTimestamp = sqlSelectLastTimestamp;
    }
    
    // Configurable SQL queries for Client Mapping persistence
    private String sqlInsertClientMapping =
    "insert into sync4j_client_mapping (principal, sync_source, luid, guid) values(?, ?, ?, ?)";
    private String sqlDeleteClientMapping =
    "delete from sync4j_client_mapping where principal=? and sync_source=? and luid=?";
    private String sqlUpdateClientMapping =
    "update sync4j_client_mapping set guid=? where principal=? and sync_source=? and luid=?";
    private String sqlSelectClientMapping =
    "select luid,guid from sync4j_client_mapping where principal=? and sync_source=?";
    
    /** Getter for property sqlInsertClientMapping.
     * @return Value of property sqlInsertClientMapping.
     *
     */
    public String getSqlInsertClientMapping() {
        return sqlInsertClientMapping;
    }
    
    /** Setter for property sqlInsertClientMapping.
     * @param sqlInsertClientMapping New value of property sqlInsertClientMapping.
     *
     */
    public void setSqlInsertClientMapping(String sqlInsertClientMapping) {
        this.sqlInsertClientMapping = sqlInsertClientMapping;
    }
    
    /** Getter for property sqlDeleteClientMapping.
     * @return Value of property sqlDeleteClientMapping.
     *
     */
    public String getSqlDeleteClientMapping() {
        return sqlDeleteClientMapping;
    }
    
    /** Setter for property sqlDeleteClientMapping.
     * @param sqlDeleteClientMapping New value of property sqlDeleteClientMapping.
     *
     */
    public void setSqlDeleteClientMapping(String sqlDeleteClientMapping) {
        this.sqlDeleteClientMapping = sqlDeleteClientMapping;
    }
    
    /** Getter for property sqlUpdateClientMapping.
     * @return Value of property sqlUpdateClientMapping.
     *
     */
    public String getSqlUpdateClientMapping() {
        return sqlUpdateClientMapping;
    }
    
    /** Setter for property sqlUpdateClientMapping.
     * @param sqlUpdateClientMapping New value of property sqlUpdateClientMapping.
     *
     */
    public void setSqlUpdateClientMapping(String sqlUpdateClientMapping) {
        this.sqlUpdateClientMapping = sqlUpdateClientMapping;
    }
    
    /** Getter for property sqlSelectClientMapping.
     * @return Value of property sqlSelectClientMapping.
     *
     */
    public String getSqlSelectClientMapping() {
        return sqlSelectClientMapping;
    }
    
    /** Setter for property sqlSelectClientMapping.
     * @param sqlSelectClientMapping New value of property sqlSelectClientMapping.
     *
     */
    public void setSqlSelectClientMapping(String sqlSelectClientMapping) {
        this.sqlSelectClientMapping = sqlSelectClientMapping;
    }    
        
    public boolean delete(Object o) throws PersistentStoreException
    {
        return false;
    }
    
    public Object[] read(Object o, Clause clause) throws PersistentStoreException
    {
        return null;
    }
    
    public boolean store(String id, Object o, String operation) throws PersistentStoreException
    {
        return false;
    }
    
}