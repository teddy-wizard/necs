/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.engine;

import sync4j.framework.engine.SyncItem;
import sync4j.framework.engine.SyncItemKey;
import sync4j.framework.engine.SyncItemImpl;

import sync4j.framework.core.Item;
import sync4j.framework.core.ComplexData;
import sync4j.framework.core.Target;
import sync4j.framework.core.Source;

/**
 * Helper class to convert <i>SyncItem</i>s into <i>Item</i>s and vice versa.
 *
 * @author Stefano Fornari @ Funambol
 *
 * @version  $Id: SyncItemHelper.java,v 1.6 2004/04/13 09:35:29 luigia Exp $
 * 
 */
public class SyncItemHelper {
    // ---------------------------------------------------------------- Costants
    
    public static final String PROPERTY_COMMAND = "SYNC4J_COMMAND";

    // ---------------------------------------------------------- Public methods
    
    /**
     * Converts a generic <i>SyncItem</i> into an <i>Item</i> object.
     *
     * @param key the key the item is known by the client agent
     * @param syncItam the <i>SyncItem</i>
     * @param includeTarget <i>true</i> if the target must be included
     * @param includeSource <i>true</i> if the source must be included
     * @param includeData <i>true</i> if data must be included
     *
     * @return the <i>Item</i> object
     */
    public static Item toItem(String   key          ,
                              SyncItem syncItem     ,
                              boolean  includeTarget,
                              boolean  includeSource,
                              boolean  includeData  ) {
        ComplexData data = null;

        if (includeData) {
            data = new ComplexData(
                       new String((byte[])syncItem.getPropertyValue(SyncItem.PROPERTY_BINARY_CONTENT))
                   );
        }
        
        Target target = null;
        Source source = null;
        
        if (includeTarget) {
            target = new Target(key);
        }
        
        if (includeSource) {
            source = new Source(key);
        }

        return new Item(target,
                        source,
                        null  , // meta
                        data  );
    }
    
    /**
     * Create a new <i>SyncItem</i> with the content of an existing one. The 
     * old SyncItem's key becomes the mappedKey of the new SyncItem.
     *
     * @param key
     * @param fromSyncItem
     */
    public static SyncItem newMappedSyncItem(SyncItemKey key, SyncItem fromSyncItem) {
        SyncItemImpl syncItem 
            = new SyncItemImpl(fromSyncItem.getSyncSource()          ,
                               key.getKeyAsString()                  ,
                               fromSyncItem.getKey().getKeyAsString(),
                               fromSyncItem.getState()               );
        
        syncItem.setProperties(fromSyncItem.getProperties());
        
        return syncItem;       
    }
}