/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.engine;

import sync4j.framework.engine.*;

import sync4j.server.pdi.*;

/**
 * This class implements a <i>SyncItem</i> that represents a vCard 2.1/3.0 
 * contact object. Each vCard proporty is represented by a proper <i>SyncProperty</i>.
 *
 * @author  Stefano Fornari @ Funambol
 */
public class ContactSyncItem extends SyncItemImpl implements SyncItem {
    // --------------------------------------------------------------- Constants
    
    public final static String PROPERTY_VCARD_CONTENT = "VCARD_CONTENT";
    
    // ------------------------------------------------------------ Private data
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * Constructs a <i>ContactSyncItem</i> from another <i>SyncItem</i>. The
     * binary content is translated into a String object, which is parsed 
     * occordingly to vCard v 2.1/3.0 specifications (RFCs 2425-26).
     *
     * @param fromSyncItem the <i>SyncItem</i> to convert
     *
     * @throws PDIException in case of errors in parsing the content
     *
     */
    public ContactSyncItem(SyncItem fromSyncItem) 
    throws PDIException {
        byte[] content = (byte[])fromSyncItem.getPropertyValue(PROPERTY_BINARY_CONTENT);
        
        if (content == null) {
            throw new PDIException("No " + PROPERTY_BINARY_CONTENT + " property found!");
        }
        
        Contact vCard = new Contact(new String(content));
        
        //
        // Copy fromSyncItem's data
        //
        setSyncSource(fromSyncItem.getSyncSource());
        setState(fromSyncItem.getState());
        setProperties(fromSyncItem.getProperties());
        
        //
        // Store the vCard and the vCard fields as properties
        //
        setPropertiesFromVCard(vCard);
    }
        
    // --------------------------------------------------------- Private methods
     
    /**
     * The given vCard object is used to create the following SyncItem's 
     * properties:
     * <table>
     * <tr><td><i>property</i></td><td><i>mandatory</i></td><td><i>description</i></td><tr>
     * <tr>
     * <td> VCARD_CONTENT </td>
     * <td> Y </td>
     * <td> The vCard object itself </td>
     * </tr>
     * <tr>
     * <td> FN </td>
     * <td> Y </td>
     * <td> vCard's FN </td>
     * </tr>
     * <tr>
     * <td> N </td>
     * <td> Y </td>
     * <td> vCard's N </td>
     * </tr>
     * <tr>
     * <td> NICKNAME </td>
     * <td> N </td>
     * <td> vCard's NICKNAME </td>
     * </tr>
     * <tr>
     * <td> PHOTO </td>
     * <td> N </td>
     * <td> vCard's PHOTO </td>
     * </tr>
     * <tr>
     * <td> BDAY </td>
     * <td> N </td>
     * <td> vCard's BDAY </td>
     * </tr>
     * <tr>
     * <td> ADR </td>
     * <td> N </td>
     * <td> vCard's ADR </td>
     * </tr>
     * <tr>
     * <td> LABEL </td>
     * <td> N </td>
     * <td> vCard's LABEL </td>
     * </tr>
     * <tr>
     * <td> TEL </td>
     * <td> N </td>
     * <td> vCard's TEL </td>
     * </tr>
     * <tr>
     * <td> EMAIL </td>
     * <td> N </td>
     * <td> vCard's EMAIL </td>
     * </tr>
     * <tr>
     * <td> MAILER </td>
     * <td> N </td>
     * <td> vCard's MAILER </td>
     * </tr>
     * <tr>
     * <td> TZ </td>
     * <td> N </td>
     * <td> vCard's TZ </td>
     * </tr>
     * <tr>
     * <td> GEO </td>
     * <td> N </td>
     * <td> vCard's GEO </td>
     * </tr>
     * <tr>
     * <td> TITLE </td>
     * <td> N </td>
     * <td> vCard's TITLE </td>
     * </tr>
     * <tr>
     * <td> ROLE </td>
     * <td> N </td>
     * <td> vCard's ROLE </td>
     * </tr>
     * <tr>
     * <td> LOGO </td>
     * <td> N </td>
     * <td> vCard's LOGO </td>
     * </tr>
     * <tr>
     * <td> AGENT </td>
     * <td> N </td>
     * <td> vCard's AGENT </td>
     * </tr>
     * <tr>
     * <td> ORG </td>
     * <td> N </td>
     * <td> vCard's ORG </td>
     * </tr>
     * <tr>
     * <td> VATEGORIES </td>
     * <td> N </td>
     * <td> vCard's CATEGORIES </td>
     * </tr>
     * <tr>
     * <td> NOTE </td>
     * <td> N </td>
     * <td> vCard's NOTE </td>
     * </tr>
     * <tr>
     * <td> PRODID </td>
     * <td> N </td>
     * <td> vCard's PRODID </td>
     * </tr>
     * <tr>
     * <td> REV </td>
     * <td> N </td>
     * <td> vCard's REV </td>
     * </tr>
     * <tr>
     * <td> SORT-STRING </td>
     * <td> N </td>
     * <td> vCard's SORT-STRING </td>
     * </tr>
     * <tr>
     * <td> SOUND </td>
     * <td> N </td>
     * <td> vCard's SOUND </td>
     * </tr>
     * <tr>
     * <td> UID </td>
     * <td> N </td>
     * <td> vCard's UID </td>
     * </tr>
     * <tr>
     * <td> URL </td>
     * <td> N </td>
     * <td> vCard's URL </td>
     * </tr>
     * <tr>
     * <td> VERSION </td>
     * <td> N </td>
     * <td> vCard's VERSION </td>
     * </tr>
     * <tr>
     * <td> CLASS </td>
     * <td> N </td>
     * <td> vCard's CLASS </td>
     * </tr>
     * <tr>
     * <td> KEY </td>
     * <td> N </td>
     * <td> vCard's KEY </td>
     * </tr>
     * </table>
     *
     * @param vCard the vCard object
     */
    private void setPropertiesFromVCard(Contact vCard) {
    }
}