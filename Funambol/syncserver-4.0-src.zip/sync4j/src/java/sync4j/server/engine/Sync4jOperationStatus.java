/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.server.engine;

import sync4j.framework.core.ModificationCommand;
import sync4j.framework.engine.SyncOperationStatusImpl;
import sync4j.framework.engine.SyncOperation;
import sync4j.framework.engine.source.SyncSource;

/**
 * This class represents a SyncOperation excecuted by Sync4j. The main 
 * difference between this and a normal <i>SyncOperationStatusImpl</i> is that
 * a <i>Sync4jOperationStatus</i> is associated to a SyncML command (such as
 * &lt;Add&gt;, &lt;Delete&gt;, ecc).
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: Sync4jOperationStatus.java,v 1.3 2004/04/13 09:35:29 luigia Exp $
 */
public abstract class Sync4jOperationStatus extends SyncOperationStatusImpl {
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The command this status related to
     */
    protected ModificationCommand cmd = null;
    
    /** Getter for property cmd.
     * @return Value of property cmd.
     *
     */
    public ModificationCommand getCmd() {
        return cmd;
    }
    
    /**
     * Setter for property  cmd.
     *
     * @param cmd the cmd
     */
    public void setCommand(ModificationCommand cmd) {
        this.cmd = cmd;
    }
    
    /** Creates a new instance of Sync4jOperationStatus */
    public Sync4jOperationStatus(SyncOperation       operation , 
                                 SyncSource          syncSource,
                                 ModificationCommand cmd       ) {
        super(operation, syncSource);
        this.cmd = cmd;
    }
    
    /** Creates a new instance of Sync4jOperationStatus */
    public Sync4jOperationStatus(SyncOperation operation , 
                                 SyncSource    syncSource) {
        this(operation, syncSource, null);
    }
}