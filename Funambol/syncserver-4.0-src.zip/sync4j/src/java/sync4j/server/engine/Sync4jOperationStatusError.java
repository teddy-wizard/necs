/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.engine;

import sync4j.framework.core.ModificationCommand;
import sync4j.framework.core.StatusCode;
import sync4j.framework.engine.SyncOperation;
import sync4j.framework.engine.source.SyncSource;
import sync4j.framework.server.error.ServerException;

import org.apache.commons.lang.builder.ToStringBuilder;


/**
 * This class represents the status of the execution of a <i>SyncOperation</i>
 * that has failed.
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: Sync4jOperationStatusError.java,v 1.4 2004/04/13 09:35:29 luigia Exp $
 
 * @see sync4j.framework.engine.SyncOperation
 *
 */
public class Sync4jOperationStatusError extends Sync4jOperationStatus{
    
    // -------------------------------------------------------------- Properties
    
    /**
     * The error condition if caused by an exception
     */
    private Throwable error = null;
    
    /** Getter for property error.
     * @return Value of property error.
     *
     */
    public Throwable getError() {
        return error;
    }
        
    // ------------------------------------------------------------- Contructors
    
    /** 
     * Creates a new instance of SyncOperationStatusError
     * 
     * @param operation the operation - NOT NULL
     * @param syncSource the source the operation was performed on - NOT NULL
     * @param cmd the command this status relates to - NULL
     * @param error the error condition - NULL
     *
     * @throws IllegalArgumentException in case operation is null
     */
    public Sync4jOperationStatusError(SyncOperation       operation ,
                                      SyncSource          syncSource,
                                      ModificationCommand cmd       ,
                                      Throwable           error     ) { 
        super(operation, syncSource, cmd);
        
        this.error = error;
    }
       
    // ---------------------------------------------------------- Public methods

    public String toString() {
        ToStringBuilder builder = new ToStringBuilder(this);
        
        builder.append("operation" , getOperation().toString() );
        builder.append("syncSource", getSyncSource().toString());
        if (error != null) {
            builder.append("error", error.getMessage());
        } else {
            builder.append("error", (String)null);
        }
        
        return builder.toString();
    }
    
    /** Which SyncML status code this condition corresponds to?
     *
     */
    public int getStatusCode() {
        Throwable cause = error.getCause();
        
        if (cause instanceof ServerException) {
            return ((ServerException)cause).getStatusCode();
        } else {
            return StatusCode.COMMAND_FAILED;
        }
    }
    
}