/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package sync4j.server.engine;

import java.io.*;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.engine.SyncEngine;
import sync4j.framework.engine.SyncEngineFactory;
import sync4j.framework.config.Configuration;

/**
 * This is the factory of the <i>SyncEngine</i> object that will be used by the
 * Sync4j server.
 * <p>
 * For now the class of the SyncEngine is hardcoded in the factory and a 
 * <i>Sync4jEngine</i> is created. Future enhanchements will make this class 
 * more flexible and useful.
 * 
 * @author  Stefano Fornari @ Funambol
 */
public class Sync4jEngineFactory  
implements SyncEngineFactory, Serializable {
    // ------------------------------------------------------------ Private data
    
    private Configuration configuration;
    
    // -------------------------------------------------------------- Properties
    
    private String syncStrategyName = null;
    
    public String getSyncStrategyName() {
        return syncStrategyName;
    }
    
    public void setSyncStrategyName(String syncStrategyName) {
        this.syncStrategyName = syncStrategyName;
    }
    // ---------------------------------------------------------- Public methods
    
    /**
     * Returns the <i>SyncEngine</i> object to be used, creating it if necessary.
     *
     * @return the <i>SyncEngine</i> used by the Syn4j server
     *
     * @throws Sync4jException
     */
    public synchronized SyncEngine getSyncEngine() throws Sync4jException {
        return new Sync4jEngine(configuration);
    }
    
    /** 
     * Configure the factory with a <i>Configuration</i> object. This can
     * eventually be passed to the created sync engine.
     *
     * @param configuration the configuration object
     *
     */
    public void setConfiguration(Configuration configuration) {
        this.configuration = configuration;
    }

    // -------------------------------------------------------------------- main
}