/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */
package  sync4j.server.engine;

import java.io.*;
import java.lang.reflect.Method;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.beans.XMLDecoder;
import java.net.URL;
import java.net.MalformedURLException;
import javax.naming.*;

import org.kxml.wap.SyncMLWriter;
import org.kxml.parser.XmlParser;
import org.kxml.parser.ParseEvent;
import org.kxml.Xml;

import sync4j.framework.core.*;
import sync4j.framework.server.SyncResponse;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.engine.SyncEngineFactory;
import sync4j.framework.config.Configuration;
import sync4j.framework.config.ConfigClassLoader;
import sync4j.framework.config.ConfigurationException;
import sync4j.framework.server.session.SessionHandler;
import sync4j.server.session.SimpleSessionHandler;
import sync4j.framework.protocol.ProtocolException;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.core.RepresentationException;
import sync4j.framework.server.session.*;
import sync4j.framework.server.error.*;
import sync4j.framework.tools.WBXMLTools;
import sync4j.framework.tools.beans.*;

import sync4j.framework.engine.pipeline.PipelineManager;
import sync4j.framework.engine.pipeline.MessageProcessingContext;

import org.jibx.runtime.*;
import org.jibx.runtime.impl.*;

/**
 *  This class handles a synchronization request.
 *  <p>
 *  This server accepts synchronization requests addressed to the hostname
 *  indicated by the configuration property pointed by {CONFIG_SERVER_URI} (see
 *  Sync4j.properties).
 *  <p>
 *  SyncAdapter uses an environment property:
 *  <ul>
 *    <li><i>{ENV_ENGINE_FACTORY_NAME}</i> points to the bean to be used as a
 *        factory for the synchronization engine</li>
 *  </ul>
 *
 *  LOG NAME: sync4j.server
 *
 *  @author Luigia Fassina @ Funambol
 *
 *  @version $Id: SyncAdapter.java,v 1.5 2004/04/14 15:46:03 luigia Exp $
 *
 */
public class SyncAdapter {

    // ------------------------------------------------------- Private constants
	protected static final String ENV_ENGINE_FACTORY_NAME
		= "java:comp/env/syncengine/factory/bean";    
	protected static final String ENV_SERVER_CONFIG_URI
		= "java:comp/env/server/config_uri";
	protected static final String ENV_SERVER_CONFIG_PATH
		= "java:comp/env/server/config_path";
    
	protected static final String CONFIG_SERVER_URI      = "server.uri";
    protected static final String CONFIG_ENGINE_PIPELINE = "engine.pipeline";

	// ------------------------------------------------------------ Private data

	protected transient Logger log = null;

	protected SyncEngineFactory syncEngineFactory = null;

	protected SimpleSessionHandler sessionHandler = null;

	protected Configuration config                = null;

	protected String sessionId                    = null;

    protected PipelineManager pipelineManager     = null;

    protected MessageProcessingContext mpc        = null;
        
    protected SyncML messageInput                 = null;

    // ------------------------------------------------------------ Constructors
	public SyncAdapter() {
		super();

		log = Sync4jLogger.getLogger("server");
        
		try {
            loadConfiguration();
			getSyncEngineFactory();
            
		} catch (Sync4jException e) {
			log.throwing("SyncAdapter", "constructor", e);
			new Sync4jException( "Error "
                                 + e.getClass().getName()
								 + " creating the SyncAdapter: "
								 + e.getMessage()
							   ).printStackTrace();
		}

		sessionHandler = new SimpleSessionHandler();
		sessionHandler.setSyncEngineFactory(syncEngineFactory);

        pipelineManager = (PipelineManager)config.getBeanInstance(CONFIG_ENGINE_PIPELINE);
        mpc = new MessageProcessingContext();
    }

	public void endSync() {
        int currentState = sessionHandler.getCurrentState();

		switch (currentState) {
			case SimpleSessionHandler.STATE_END:
				sessionHandler.commit();
				break;

			case SimpleSessionHandler.STATE_ERROR:
				sessionHandler.abort(StatusCode.PROCESSING_ERROR);
				break;

			default:
				sessionHandler.abort(StatusCode.SESSION_EXPIRED);
				break;
		}
		log = null;
	}

	/**
	 * process the incoming sync message
	 *
	 * @param msg must be non-null
	 * @param mimeType may be null.
	 *
	 */
	public SyncResponse processMessage( final byte[] msg, final String mimeType)
	throws ServerException {
        Sync4jResponse response = null;
        String inMessage = null;
        SyncML outMessage = null;
        
		if (msg == null) {
			String err = "msg is null!";
			log.severe(err);
			throw new ServerException(err);
		}

		if (mimeType == null) {
			String err = "mimeType is null!";
			log.severe(err);
			throw new ServerException(err);
		}

        if (log.isLoggable(Level.FINE)) {
            log.fine("mimeType: " + mimeType);
        }
        
        try {
            if (Constants.MIMETYPE_SYNCML_WBXML.equals(mimeType)) {
                // convert WBXML to XML, and then pass to processXMLMessage
                // todo: change this so that it mirrors processXMLMessage
                //  instead of converting to XML then calling processXMLMessage
			
                if (log.isLoggable(Level.FINEST)) {
                   log.finest("Convert message from wbxml to xml");
                }
				inMessage = WBXMLTools.wbxmlToXml(msg);

            } else if (Constants.MIMETYPE_SYNCML_XML.equals(mimeType)) {                
                
                inMessage = new String(msg);
                
            } else {
                //
                // its an unsupported MIME type
                //
                String err = "Unknown mime type:  " + mimeType;
                log.severe(err);
                throw new NotImplementedException(err);
    		}

        } catch (Sync4jException e) {
            String err = "Error processing message: " + e.getMessage();
            log.severe(err);
            throw new ServerException(err);
        }
        
        try {
            
            if (log.isLoggable(Level.INFO)) {
               log.info("Message for creating SyncML object\n" + inMessage);
            }
            
            IBindingFactory f = BindingDirectory.getFactory(SyncML.class);
            IUnmarshallingContext c = f.createUnmarshallingContext();
            
            Object h = c.unmarshalDocument(
                          new ByteArrayInputStream(inMessage.getBytes()), null
                          );
            
            if (h instanceof SyncML) {
                messageInput = (SyncML)h;
            }
        } catch(org.jibx.runtime.JiBXException e) {
            e.printStackTrace();
            throw new ServerException(e);
        }
  
        try {
            
            if (log.isLoggable(Level.FINE)) {
               log.fine("Calling input pipeline");
            }            
            pipelineManager.preProcessMessage(mpc, messageInput);
            
            if (log.isLoggable(Level.FINE)) {
               log.fine("Calling process message");
            }         
            outMessage = processXMLMessage(inMessage);            
            
            final String resultMimeType = mimeType;
            
            if (log.isLoggable(Level.FINE)) {
                log.fine("Calling output pipeline");
            }
            
            pipelineManager.postProcessMessage(mpc, outMessage);

            if (log.isLoggable(Level.FINE)) {
                log.fine( "The synchronization is "
                        + ((outMessage.isLastMessage()) ? "" : "not ")
                        + "complete"
                        );
            }

            response =
                new Sync4jResponse(outMessage, resultMimeType);
            
        } catch (Sync4jException e) {
            String err = "Error processing return message: " + e.getMessage();
			log.severe(err);
            throw new ServerException(err);
        }

		return (SyncResponse) response;
	}

	/**
	 * Used to process a status information as needed by the client object (i.e.
	 * errors or success).
	 *
	 * @param statusCode the status code
	 * @param statusMessage additional descriptive message
	 *
	 * @see sync4j.framework.core.StatusCode for valid status codes.
	 */
	public SyncResponse processStatusCode(int statusCode, String info){
		if (statusCode != StatusCode.OK) {
			sessionHandler.abort(statusCode);
		}
		return null;
	}

	// --------------------------------------------------------- private methods

	/**
	 * Processes the given SyncML XML message. See the class description for
	 * more information.
	 *
	 * @param message the message to be processed
	 *
	 * @return the response message
	 *
	 * @throws ProtocolException
	 */
	private SyncML processXMLMessage(String msg) throws ServerException {
		try {
            try {
                checkMessage(messageInput);
                return sessionHandler.processMessage(messageInput);
            } catch (InvalidCredentialsException e) {
                return sessionHandler.processError(messageInput, e);
            } catch (ServerException e) {
                return sessionHandler.processError(messageInput, e);
            } catch (ProtocolException e) {
                return sessionHandler.processError(messageInput, new BadRequestException(e.getMessage()));
            }

		} catch (Sync4jException e1) {
			//
			// This can be due only to processError
			//
			throw new ServerException(e1);
		}
	}
    
     /**
     * Checks if the given string is an accepted URL (starting with http://,
     * https:// or file://). If yes, a new URL object representing the given
     * url is returned; otherwise, the given string is considered a file name
     * and a new URL is obtained calling File.toURL().
     *
     * @param s the string to check
     *
     * @return the corresponding URL if the string represents a URL or the
     *         fixed URL if the string is a pathname/filename
     *
     * @throws MalformedURLException
     */
    private URL fixURI(final String s)
    throws MalformedURLException {

        try {
            return new URL(s);
        } catch (MalformedURLException e) {
            //
            // This is not a URL, let's consider it just a file
        }

        try {
            return new File(new File(s).getCanonicalPath()).toURL();

        } catch (IOException e) {
            throw new MalformedURLException("Unable to convert" + s + " to a URL");
        }
    }

	/**
	 * Checks if the given message can be processed by this server implementation.<br>
	 * In detail, it checks:
	 * <ul>
	 *  <li> if server_uri (as specified by the configuration parameter
	 *       CONFIG_SERVER_URI) is a URL, the taget uri hostname and the server
	 *       uri hostname must match.
	 *  <li> if the server uri is not a valid url, server uri and target uri
	 *       must match as strings.
	 * </ul>
	 *
	 * @param msg the message to be checked
	 *
	 * @throws ServerException in case the message is wrong
	 */
	private void checkMessage(SyncML msg)
	throws ServerException {
		String serverURI = null;
		String targetURI = null;

		serverURI = config.getStringValue(CONFIG_SERVER_URI);
		targetURI = msg.getSyncHdr().getTarget().getLocURI();

		try {
			URL serverURL = new URL(serverURI);
			URL targetURL = new URL(targetURI);

			serverURI = serverURL.getHost();
			targetURI = targetURL.getHost();
		} catch (MalformedURLException e) {
			//
			// The server uri is not a valid URL. Simple string comparison
			// will be performed
			//
		}

		if (log.isLoggable(Level.FINE)) {
			log.fine("serverURI: " + serverURI);
			log.fine("targetURI: " + targetURI);
		}

		if (!serverURI.equals(targetURI)) {
			throw new BadRequestException( "The message is addressed to "
										 + targetURI
										 + " not to "
										 + serverURI
										 );
		}
	}

	/**
	 * Returns the <i>Sync4jEngineFactory</i> object that a <i>SessionHandler</i>
	 * should use to create a <i>SyncEngine</i>. The method dynamically loads the
	 * <i>SyncEngineFactory</i> specified by the environment key
	 * <i>syncengine/factory/bean</i>.
	 *
	 * @return the <i>Sync4jEngineFactory</i> object
	 *
	 * @throws Sync4jException
	 */
	protected void getSyncEngineFactory() throws Sync4jException {
		if (syncEngineFactory != null) {
			return;
		}

		String factoryName = null;
		try {
			InitialContext ctx = new InitialContext();

			factoryName = (String)ctx.lookup(ENV_ENGINE_FACTORY_NAME);

			if (log.isLoggable(Level.FINE)) {
				log.fine("factory name: " + factoryName);
				log.fine("Getting a new syncEngineFactory...");
			}

			if ((factoryName == null) || (factoryName.length() == 0)) {
				throw new Sync4jException( ENV_ENGINE_FACTORY_NAME
										 + " must be specified"    );
			}

			syncEngineFactory = (SyncEngineFactory)BeanFactory.getBeanInstance(getClass().getClassLoader(), factoryName);

		} catch (Exception e) {
			log.throwing(getClass().getName(), "getSyncEngineFactory", e);
			throw new Sync4jException( "Error in loading "
									 + factoryName
									 , e
									 );
		}
		//
		// The engine factory is configured with the server configuration so
		// that the engine  object has the opportunity to access to the server
		// configuration
		//
		syncEngineFactory.setConfiguration(config);
	}

	/**
	 * Loads the configuration for the server. The URI from which the configuration
	 * is must be set as the envirnoment property named as <i>ENV_SERVER_CONFIG_URI</i>.
	 *
	 * @throws ConfigurationException in case of errors.
	 */
    protected void loadConfiguration()
    throws ConfigurationException {
        URL configURI = null, configPath = null;

        config = new Configuration();

        try {
            InitialContext ctx = new InitialContext();

            configURI  = fixURI((String)ctx.lookup(ENV_SERVER_CONFIG_URI ));
            configPath = fixURI((String)ctx.lookup(ENV_SERVER_CONFIG_PATH));
            log.finest("configURI=" + configURI);
			log.finest("configPath=" + configPath);
            config.setClassLoader(
                new ConfigClassLoader(
                    new URL[] { configPath },
                    getClass().getClassLoader()
                )
            );
            log.finest("config.load(" + configURI+")");
            config.load(configURI.toString());

            if (log.isLoggable(Level.FINEST)) {
                log.finest("Configuration: " + config);
            }
        } catch (ConfigurationException e) {
            throw e;
        } catch (Exception e) {
            throw new ConfigurationException("Error loading configuration from " + configURI, e);
        }
    }
    
	private static class Sync4jResponse
			implements SyncResponse
	{
		private SyncML msg;
		private String  resultMimeType;

		private Sync4jResponse(
				final SyncML msg           ,
				final String  resultMimeType) {
            this.msg = msg;
			this.resultMimeType = resultMimeType;
		}

		public SyncML getMessage() {
			return this.msg;
		}

		public String getMessageString() {
            return Util.toXML(msg);
		}

		public String getMimeType() {
			return resultMimeType;
		}

		/**
		 * Is this message the last message allowed for the current session?
		 *
		 * @return true if yes, false otherwise
		 *
		 */
		public boolean isCompleted() {
			return msg.isLastMessage();
		}
	}
}