/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.engine;

import java.util.*;
import java.util.Map;
import java.util.logging.Logger;
import java.util.logging.Level;

import java.security.Principal;
import java.sql.Timestamp;

import sync4j.framework.engine.*;
import sync4j.framework.engine.source.SyncSource;
import sync4j.framework.engine.source.SyncSourceInfo;
import sync4j.framework.security.Officer;
import sync4j.framework.security.Sync4jPrincipal;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.tools.beans.BeanFactory;
import sync4j.framework.core.*;
import sync4j.framework.database.Database;
import sync4j.framework.protocol.CommandIdGenerator;
import sync4j.framework.config.Configuration;
import sync4j.framework.server.*;
import sync4j.framework.server.store.*;
import sync4j.server.engine.Sync4jSource;

/**
 * This is the Sync4j implementation of the synchronization engine.
 *
 * LOG NAME: sync4j.engine
 *
 * @author  Stefano Fornari @ Funambol
 * @version $Id: Sync4jEngine.java,v 1.50 2004/04/13 09:35:29 luigia Exp $
 */
public class Sync4jEngine 
extends AbstractSyncEngine 
implements java.io.Serializable {
    
    // --------------------------------------------------------------- Constants
    
    public static final String CFG_SECURITY_OFFICER      = "security.officer"      ;
    public static final String CFG_STRATEGY_CLASS        = "engine.strategy"       ;
    public static final String CFG_SYNCML_DTDVERSION     = "syncml.dtdversion"     ;
    public static final String CFG_ENGINE_MANIFACTURER   = "engine.manifacturer"   ;
    public static final String CFG_ENGINE_MODELNAME      = "engine.modelname"      ;
    public static final String CFG_ENGINE_OEM            = "engine.oem"            ;
    public static final String CFG_ENGINE_FWVERSION      = "engine.firmwareversion";
    public static final String CFG_ENGINE_SWVERSION      = "engine.softwareversion";
    public static final String CFG_ENGINE_HWVERSION      = "engine.hardwareversion";
    public static final String CFG_ENGINE_DEVICEID       = "engine.deviceid"       ;
    public static final String CFG_ENGINE_DEVICETYPE     = "engine.devicetype"     ;
    public static final String CFG_PERSISTENT_STORE      = "engine.store"          ;
    public static final String CFG_SERVER_URI            = "server.uri"            ;
    public static final String CFG_SERVER_DEBUG          = "server.debug"          ;
        
    public static final int SERVER = 0;
    public static final int CLIENT = 1;
    
    public static final String LOG_NAME = "engine";
    
    // ------------------------------------------------------------ Private data
    
    /**
     * The configuration properties
     */
    private Configuration configuration = null;
    
    public Configuration getConfiguration() {
        return configuration;
    }
    
    /**
     * The security officer
     */
    private Officer officer = null;
    
    public Officer getOfficer() {
        return this.officer;
    }
    
    /**
     * The underlying persistent store
     */
    private PersistentStore store = null;
    
    /** Getter for property store.
     * @return Value of property store.
     *
     */
    public PersistentStore getStore() {
        return store;
    }
    
    /** Setter for property store.
     * @param store New value of property store.
     *
     */
    public void setStore(PersistentStore store) {
        this.store = store;
    }

    /**
     * The sources this engine deals with
     */
    private ArrayList serverSources = new ArrayList();
    private ArrayList clientSources = new ArrayList();
    
    /**
     * The modification objects of the last synchronization
     */
    private HashMap operations = null;
    
    /**
     * The modification objects of the last synchronization
     */
    private SyncOperationStatus[] operationStatus = null;
   
    /**
     * Logger
     */
    //protected transient Logger log = Sync4jLogger.getLogger();
    protected transient Logger log = null;
    
    // ------------------------------------------------------------ Constructors
    
    /**
     * To allow deserializazion of subclasses.
     */
    protected  Sync4jEngine() {        
    }
    
    /** 
     * Creates a new instance of Sync4jEngine. <p>
     * NOTE: This is a sample implementation that deals with a single source on 
     * the file system.
     *
     * @throws ConfigurationException a runtime exception in case of misconfiguration
     */
    public Sync4jEngine(Configuration configuration) {
        log = Sync4jLogger.getLogger(LOG_NAME);
        
        this.configuration = configuration;
       
        //
        // Set the underlying persistent store
        //
        HashMap psConfig = new HashMap(1);
        psConfig.put("class-loader", configuration.getClassLoader());
        store = (PersistentStore)configuration.getBeanInstance(CFG_PERSISTENT_STORE);
        try {
            store.configure(psConfig);
        } catch (ConfigPersistentStoreException e) {
            log.severe("Error configuring the persistent store: " + e);
            log.throwing(getClass().getName(), "<init>", e);
        }
        
        //
        // Set the security officer
        //
        officer = (Officer)configuration.getBeanInstance(CFG_SECURITY_OFFICER);
        
        //
        // Set SyncSources
        //
        Sync4jSource[] sources = null;
        
        try {
            sources = (Sync4jSource[])store.read(Sync4jSource.class);
        } catch (PersistentStoreException e) {
            if (log.isLoggable(Level.SEVERE)) {
                log.severe("Error reading registered sources: " + e.getMessage());
            }
            
            log.throwing(getClass().getName(), "<init>", e);
        }
        
        for (int i=0; ((sources != null) && (i<sources.length)); ++i) {
            if (log.isLoggable(Level.FINE)) {
                log.fine("sources[" + i + "]: " + sources[i]);
            }
            
            try {
                serverSources.add(
                    BeanFactory.getBeanInstance(configuration.getClassLoader(),  sources[i].getConfig())
                );
            } catch (Exception e){
                String msg = "Unable to create sync source "
                           + sources[i]
                           + ": "
                           + e.getMessage();
                
                log.severe(msg);
                log.throwing(getClass().getName(), "<init>", e);
            }
        }
        
        
        //
        // Set the SyncStrategy object to use for comparisons
        //
        SyncStrategy strategy = 
           (SyncStrategy)configuration.getClassInstance(CFG_STRATEGY_CLASS);
     
        setStrategy(strategy);
        
        if (log.isLoggable(Level.INFO)) {
            log.info("Engine configuration:");
            log.info("store: "    + store   );
            log.info("officer: "  + officer );
            log.info("strategy: " + strategy);
        }
    }
    
    // ------------------------------------------------ Configuration properties
    
     /**
     * The id generator
     */
    private CommandIdGenerator cmdIdGenerator = null;
    
    /**
     * Set the id generator for commands
     * 
     * @param cmdIdGenerator the id generator
     */
    public void setCommandIdGenerator(CommandIdGenerator cmdIdGenerator) {
        this.cmdIdGenerator = cmdIdGenerator;
    }
    
    
    /**
     * Return the id generator
     * 
     * @return the id generator
     */
    public CommandIdGenerator getCommandIdGenerator() {
        return cmdIdGenerator;
    }
    
    // ------------------------------------------------------ Runtime properties
    
    /**
     * The database to be synchronized
     */
    private HashMap dbs = new HashMap();
    
    public void setDbs(HashMap dbs) {
        if (this.dbs != null) {
            this.dbs.clear();
        } else {
            this.dbs = new HashMap(dbs.size());
        }
        this.dbs.putAll(dbs);
    }
    
    public void setDbs(Database[] dbs) {
        if (this.dbs == null) {
            this.dbs = new HashMap(dbs.length);
        }
        
        for (int i=0; ((dbs != null) && (i<dbs.length)); ++i) {
            this.dbs.put(dbs[i].getName(), dbs[i]);
        }
    }
    
    public Database[] getDbs() {
        if (this.dbs == null) {
            return new Database[0];
        }
        
        Iterator i = this.dbs.values().iterator();
        
        Database[] ret = new Database[this.dbs.size()];
        
        int j = 0;
        while(i.hasNext()) {
            ret[j++] = (Database)i.next();
        }
        
        return ret;
    }
    
    /**
     * The existing LUID-GUID mapping. It is used and modify by sync()
     */
    private Map clientMappings = new HashMap();
    
    public void setClientMappings(Map clientMappings) {
        this.clientMappings = clientMappings;
    }
    
    // ---------------------------------------------------------- Public methods
    
    /**
     * Fires and manages the synchronization process.
     *
     * @param principal the principal who is requesting the sync
     *
     * @throws Sync4jException in case of error
     */
    public void sync(Sync4jPrincipal principal)
    throws Sync4jException {
        log.info("Starting synchronization ...");
        
        SyncStrategy syncStrategy = getStrategy();
        
        SyncSource clientSource = null, serverSource = null;
        Database   db           = null;
        
        ArrayList status = new ArrayList();
        
        //
        // Create maps for server sources so that they can be accessed throught
        // their name
        //
        HashMap sourceMap = new HashMap(serverSources.size());
        
        Iterator s = serverSources.iterator();
        while(s.hasNext()) {
            serverSource = (SyncSource)s.next();
            sourceMap.put(serverSource.getSourceURI(), serverSource);
        }                
        
        //
        // Now process clientSources
        //
        
        operations = new HashMap();
                
        String   uri = null;
        Iterator c = clientSources.iterator();
        while(c.hasNext()) {
            clientSource = (SyncSource)c.next();
            uri          = clientSource.getSourceURI();
           
            serverSource = (SyncSource)sourceMap.get(uri);
            db           = (Database)dbs.get(clientSource.getSourceURI());
                      
            SyncSource[] sources = new SyncSource[] {
                serverSource, clientSource
            };

            try {
                Sync4jPrincipal p = (Sync4jPrincipal)db.getPrincipal();
                p.setId(principal.getId());
                
                //
                // Call beginSync()
                //
                serverSource.beginSync(p, db.getMethod());
                
                if (   (db.getMethod() == AlertCode.SLOW) 
                    || (db.getMethod() == AlertCode.REFRESH_FROM_SERVER)) {
                    operations.put(uri, syncStrategy.prepareSlowSync(sources, p));
                } else {
                    //
                    // Read the last timestamp from the persistent store, than
                    // prepare for fast synchronization
                    //
                    LastTimestamp last = new LastTimestamp(
                                             p.getId()    ,
                                             db.getName()
                                         );
                    try {
                        store.read(last);
                    } catch (PersistentStoreException e) {
                        throw new SyncException("Error reading last timestamp", e);
                    }
                    Timestamp since = new Timestamp(last.start);
                    
                    operations.put(uri, syncStrategy.prepareFastSync(sources, p, since));
                }

                //
                // Now synchronize the sources
                //
                status.addAll(
                    Arrays.asList(
                        syncStrategy.sync((SyncOperation[])operations.get(uri))
                    )
                );
                
                operationStatus = (SyncOperationStatus[])status.toArray(new SyncOperationStatus[0]);
                
                //
                // Call endSync()
                //
                serverSource.endSync(p);
                
                log.info("Ending synchronization ...");

                syncStrategy.endSync();
            } catch (SyncException e) {
                log.throwing(getClass().getName(), "sync", e);
                throw new Sync4jException(e.getMessage(), e);
            }
        }  // next i (client source)     
    }
    
    /**
     * Returns the operations of the last synchronization
     *
     * @param uri the URI of the source the operations are applied to
     *
     * @return the operations of the last synchronization
     */
    public SyncOperation[] getSyncOperations(String uri) {
        return (SyncOperation[])operations.get(uri);
    }
    
    /**
     * Returns the operation status of the operations executed in the last
     * synchronization
     *
     * @param msgId the id of the SyncML message 
     *
     * @return the operations status of the operations executed in the last 
               synchronization
     */
    public Status[] getModificationsStatusCommands(String msgId) {
               
        if ((operationStatus == null) || (operationStatus.length == 0)) {
            return new Status[0];
        }
                
        return EngineHelper.generateStatusCommands(
            operationStatus, 
            msgId, 
            cmdIdGenerator
        );
    }
    
    /**
     * Adds a new client source to the list of the sources the engine deals with.
     * 
     * @param source the source to be added
     */
    public void addClientSource(SyncSource source) {
        log.finest("adding " + source);
        
        clientSources.add(source);
    }
    
    /**
     * Returns the client sources
     * 
     * @return the client sources
     */
    public List getClientSources() {
        return clientSources;
    }
    
    /**
     * Returns the client source with the given name if there is any.
     *
     * @param name the source name
     *
     * @return the client source with the given name if there is any, null otherwise
     */
    public SyncSource getClientSource(String name) {
        Iterator i = clientSources.iterator();
        
        SyncSource s = null;
        while (i.hasNext()) {
            s = (SyncSource)i.next();
            
            if (s.getSourceURI().equals(name)) {
                return s;
            }
        }
        
        return null;
    }
    
    /**
     * Returns the server source with the given name if there is any.
     *
     * @param name the source name
     *
     * @return the server source with the given name if there is any, null otherwise
     */
    public SyncSource getServerSource(String name) {
        Iterator i = serverSources.iterator();
        
        SyncSource s = null;
        while (i.hasNext()) {
            s = (SyncSource)i.next();
            
            if (s.getSourceURI().equals(name)) {
                return s;
            }
        }
        
        return null;
    }
            
    /**
     * Return the <i>DataStore</i> object corresponding to the given 
     * <i>Database</i> object.
     * 
     * @param database the database to convert
     * 
     * @return the <i>DataStore</i> object corresponding to the given 
     *         <i>Database</i> object.
     *
     */
    public DataStore databaseToDataStore(Database db) {
        ContentTypeInfo contentTypeInfo 
            = new ContentTypeInfo(db.getType(), "-" /* version */);
        
        return new DataStore(
            new SourceRef(db.getSource())                          ,
            null                                                   ,
            -1                                                     ,
            contentTypeInfo                                        ,
            new ContentTypeInfo[] { contentTypeInfo }              ,
            contentTypeInfo                                        ,
            new ContentTypeInfo[] { contentTypeInfo }              ,
            new DSMem(false, -1, -1)                     ,
            new SyncCap(new SyncType[] { SyncType.SLOW })
        );
    }
    
    /**
     * Returns the content type capabilities of this sync engine.
     *
     * @return the content type capabilities of this sync engine.
     */
    public CTCap[] getContentTypeCapabilities() {
        return new CTCap[0];
    }
    
    /**
     * Returns the extensions of this sync engine.
     *
     * @return the extensions of this sync engine.
     */
    public Ext[] getExtensions() {
        return new Ext[0];
    }
            
    /**
     * Returns the data store capabilities of the sync sources to synchronize.
     *
     * @return the data store capabilities of the sync sources to synchronize.
     */
    public DataStore[] getDatastores() {
        DataStore[] ds = null;
        ArrayList al = new ArrayList();
                
        Database db  = null;
        String   uri = null;
        Iterator i = dbs.values().iterator();
        while(i.hasNext()) {
            db = (Database)i.next();
            uri = db.getName();
            
            SyncSource ss = getServerSource(uri);
           
            if ( ss != null) {
                al.add(EngineHelper.toDataStore(uri, ss.getInfo()));                
            }
        }
        
        int size = al.size();
        if (size == 0) {
            ds = new DataStore[0];
        } else {
        ds = (DataStore[])al.toArray(new DataStore[size]);
        }
        
                
        return ds;
    }

    
    /**
     * Creates and returns a <i>DeviceInfo</i> object with the information 
     * extracted from the configuration object.
     *
     * @param verDTD the version of the DTD to use to encode the capabilities
     *
     * @return the engine capabilities
     *
     * @throws ConfigurationException a runtime exception in case of misconfiguration
     */
    public DevInf getServerCapabilities(VerDTD verDTD) {
        DevInf devInf = 
        new DevInf(
            verDTD,
            configuration.getStringValue(CFG_ENGINE_MANIFACTURER, "Sync4j"),
            configuration.getStringValue(CFG_ENGINE_MODELNAME, "Sync4j"),
            configuration.getStringValue(CFG_ENGINE_OEM,          null    ),
            configuration.getStringValue(CFG_ENGINE_FWVERSION,    null    ),
            configuration.getStringValue(CFG_ENGINE_SWVERSION,    null    ),
            configuration.getStringValue(CFG_ENGINE_HWVERSION,    null    ),
            configuration.getStringValue(CFG_ENGINE_DEVICEID, "Sync4j"),
            configuration.getStringValue(CFG_ENGINE_DEVICETYPE,   "Server"),
            getDatastores(),
            getContentTypeCapabilities(),
            getExtensions()
        );
        devInf.setUTC(false);
        devInf.setSupportLargeObjs(false);
        devInf.setSupportNumberOfChanges(false);
        return devInf;
    }
    
    /**
     * First of all, check the availablity and accessibility of the given 
     * databases. The state of the given database will change as described below
     * (and in the same order):
     * <ul>
     *   <li>The database status code is set to <i>StatusCode.OK</i> if the 
     *       database is accessible, <i>StatusCode.NOT_FOUND</i> if the database
     *       is not found and <i>StatusCode.FORBIDDEN</i> if the principal is 
     *       not allowed to access the database. 
     *   <li>If the currently set last anchor does not match the last tag 
     *       retrieved from the database (DBMS) and the requested alert code is
     *       not a refresh, the synchronization method is set to 
     *       <i>AlertCode.SLOW</i>
     *   <li>The database server sync anchor is set to the server-side sync anchor
     *
     * @param principal the principal the is requesting db preparation
     * @param dbs an array of <i>Database</i> objects - NULL
     * @param next the sync timestamp of the current synchronization
     *
     */
    public void prepareDatabases(Sync4jPrincipal principal, 
                                 Database[]      dbs      , 
                                 SyncTimestamp   next     ) {
        for (int i=0; ((dbs != null) && (i < dbs.length)); ++i) {
            int statusCode = StatusCode.OK;

            if (!checkServerDatabase(dbs[i])) {
                statusCode = StatusCode.NOT_FOUND;
            } else if (!checkDatabasePermissions(dbs[i])) {
                statusCode = StatusCode.FORBIDDEN;
            }

            dbs[i].setStatusCode(statusCode);
            
            //
            // Now retrieve the last sync anchor
            //
            if (statusCode == StatusCode.OK) {                
                LastTimestamp last = new LastTimestamp(
                    principal.getId(),
                    dbs[i].getName()
                );
                
                try {
                    store.read(last);
                    dbs[i].setServerAnchor(new Anchor(last.tag, next.tag));
                } catch (NotFoundException e) {
                    //
                    // No prev last sync! Create a new anchor that won't match
                    //
                    last.tag = next.tag;
                    dbs[i].setServerAnchor(new Anchor(next.tag, next.tag));
                } catch(PersistentStoreException e) {
                    log.severe("Unable to retrieve timestamp from store");
                    log.throwing(getClass().getName(), "prepareDatabases", e);
                }
                
                if (  !(last.tag.equals(dbs[i].getAnchor().getLast()))
                   && (dbs[i].getMethod() != AlertCode.REFRESH_FROM_SERVER)) {
                    if (log.isLoggable(Level.FINE)) {
                        log.fine( "Forcing slow sync for database " 
                                + dbs[i].getName()
                                );
                        log.fine( "Server last: "
                                + last.tag 
                                + "; client last: " 
                                + dbs[i].getAnchor().getLast()
                                );
                    }
                    dbs[i].setMethod(AlertCode.SLOW);
                }
            }
        }
    }
    
    /**
     * Authenticates the given credential using <i>officer</i>.
     *
     * @param credential the credential to be authenticated
     *
     * @return true if the credential is authenticated, false otherwise
     */
    public boolean login(Cred credential) {
        return officer.authenticate(credential);
    }
    
    public boolean isGuestEnabled() {      
        return officer.isGuestEnabled();
    }
    
    /**
     * Logs out the given credential using <i>officer</i>.
     *
     * @param credential the credential to be authenticated
     *
     * @return true if the credential is authenticated, false otherwise
     */
    public void logout(Cred credential) {
        officer.unAuthenticate(credential);
    }
    
    /**
     * Authorizes the given principal to access the given resource using 
     * <i>officer</i>.
     * 
     * @param principal the entity to be authorized
     * @param resource the name of the resource
     *
     * @return true if the principal is authorized, false otherwise
     */
    public boolean authorize(Principal principal, String resource) {
        return officer.authorize(principal, resource);
    }
    
    /**
     * Is the server in debug mode?
     *
     * @return the value of the configuration property CFG_SERVER_DEBUG
     */
    public boolean isDebug() {
        return configuration.getBoolValue(CFG_SERVER_DEBUG, false);
    }
    
    /**
     * Translates an array of <i>SyncOperation</i> objects to an array of
     * <i>(Add,Delete,Replace)Command</i> objects. Only client side operations
     * are translated.
     *
     * @param clientMapping the associated existing client mapping
     * @param operations the operations to be translated
     * @param sourceName the corresponding source name
     *
     * @return the sync4j commands corresponding to <i>operations</i>
     */
    public ItemizedCommand[] operationsToCommands(ClientMapping      clientMapping,
                                                  SyncOperation[]    operations   ,
                                                  String             sourceName   ) {
        return EngineHelper.operationsToCommands( clientMapping , 
                                                  operations    ,
                                                  sourceName    ,
                                                  cmdIdGenerator);
    } 

    /**
     * Updates the mapping given an array of operations. This is used for 
     * mappings sent by the client.
     *
     * @param clientMappings the client mappings for current synchronization
     * @param operations the operation performed
     *
     */
    public void updateClientMappings(Map             clientMappings,
                                     SyncOperation[] operations    ,
                                     boolean slowSync              ) {
        try {
            EngineHelper.updateClientMappings(clientMappings, operations, slowSync);            
        } catch (Exception e) {
          log.throwing(getClass().getName(), "updateClientMappings", e);
        }
    }
    
        
    /**
     * Updates the LUID-GUIDmapping for the client modifications (that is the
     * items directlry inserted or removed by the server).
     *
     * @param clientMappings the client mappings for current synchronization
     *
     */
    public void updateServerMappings(Map clientMappings, boolean slowSync) {
        try {
            EngineHelper.updateServerMappings(clientMappings, operationStatus, slowSync);
        } catch (Exception e) {
          log.throwing(getClass().getName(), "updateServerMappings", e);
        }
    }
    
    /**
     * Converts an array of <i>Item</i> objects belonging to the same
     * <i>SyncSource</i> into an array of <i>SyncItem</i> objects.
     * <p>
     * The <i>Item</i>s created are enriched with an additional property
     * called as in SyncItemHelper.PROPERTY_COMMAND, which is used to bound the
     * newly created object with the original command.
     *
     * @param syncSource the <i>SyncSource</i> items belong to - NOT NULL
     * @param items the <i>Item</i> objects
     * @param state the state of the item as one of the values defined in
     *              <i>SyncItemState</i>
     * @param the timestamp to assign to the last even on this item
     *
     *
     * @return an array of <i>SyncItem</i> objects
     */
    public static SyncItem[] itemsToSyncItems(ClientMapping       clientMapping,
                                              SyncSource          syncSource   ,
                                              ModificationCommand cmd          ,
                                              char                state        ,
                                              long                timestamp    ) {
        
        return EngineHelper.itemsToSyncItems(clientMapping, syncSource, cmd, state, timestamp);
    }
    
    // --------------------------------------------------------- Private methods
    
    /**
    
    /**
     * Checks if the given database is managed by this server.
     *
     * @param db the database to be checked
     *
     * @return true if the database is under control of this server, false otherwise
     *
     */
    private boolean checkServerDatabase(Database db) {
        if (log.isLoggable(Level.FINEST)) {
            log.finest( "Checking if the database "
                      + db
                      + " is in the server database list "
                      + serverSources
                      );
        }
        
        SyncSource source = null;
        Iterator i = serverSources.iterator();
        while(i.hasNext()) {
            source = (SyncSource)i.next();
            
            if (db.getName().equals(source.getSourceURI())) {
                log.finest("Yes sir!");
                return true;
            }
        }
        
        log.finest("Not found sir");
        
        //
        // not found...
        //
        return false;
    }
    
    /**
     * Checks if the principal associated to the database is allowed to synchronize.<br>
     *
     * @param db the database to be checked
     *
     * @return true if the credential is allowed to access the database, false otherwise
     */
    private boolean checkDatabasePermissions(Database db) {
        return authorize(db.getPrincipal(), db.getName());
    }
}