/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.syncbean.session;

import java.io.File;

import java.util.ArrayList;
import java.util.Collection;
import java.util.logging.Logger;
import java.util.logging.Level;

import sync4j.framework.tools.beans.BeanFactory;
import sync4j.framework.tools.beans.BeanException;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.server.session.AbstractSessionManager;
import sync4j.framework.server.session.SessionHandler;
import sync4j.framework.server.session.SessionExpiredException;
import sync4j.server.session.SimpleSessionHandler;

/**
 * This implementation of a <i>AbstractSessionManager</i> stores and retrieves
 * sessions to/from the file system. <br>
 * For each session is serialized under the directory pointed by <i>sessionsPath</i>
 * in a file called {session_id}.session . This is a very simple implementation 
 * that allows many servers to access the same session repository. In fact, in
 * a real deployment, we can have SyncML servers replicated for reliability and
 * scalability purposes. In that case they must share the directory specified
 * by <i>sessionsPath</i>.
 * <p>
 * <b>This class is not thread safe. It is supposed that an instance is not
 * shared by multiple threads</b>.
 *
 * @author  Stefano Fornari @ Funambol.com
 * @version $Id: SessionManager.java,v 1.6 2004/04/13 09:35:29 luigia Exp $
 */
public class SessionManager extends AbstractSessionManager implements java.io.Serializable {
    
    // ------------------------------------------------------------ Private data
    
    /**
     * The logger
     */
    private static final Logger log = Sync4jLogger.getLogger();
    
    // -------------------------------------------------------------- Properties
   
    private String sessionsPath = null;
    
    /** Getter for property sessionsPath.
     * @return Value of property sessionsPath.
     */
    public String getSessionsPath() {
        return sessionsPath;
    }
    
    /** Setter for property sessionsPath.
     * @param sessionsPath New value of property sessionsPath.
     */
    public void setSessionsPath(String sessionsPath) {
        this.sessionsPath = sessionsPath;
    }
    
    // ---------------------------------------------------------- Public methods
    
    
    // --------------------------------------------------------- Private methods
    protected Collection getSessionBag() {
        ArrayList sessions = new ArrayList();
        
        //
        // Get a list of the content of the sessionsPath directory. Than for 
        // each file deserialized it and add it to sessions.
        //
        File sessionsPathFile = new File(sessionsPath);
        
        if (!sessionsPathFile.exists()) {
            return sessions; // returns an empty collection
        }
        
        File[] files = sessionsPathFile.listFiles();
        
        SessionHandler handler = null;
        for (int i=0; (files != null) && (i<files.length); ++i) {
            try {
                handler = (SessionHandler)BeanFactory.getBeanInstance(files[i]);
                sessions.add(handler);
            } catch (BeanException e) {
                log.throwing(getClass().getName(), "getSessionBag", e.getCause());
            }
        }
        
        return sessions;
    }
    
    protected SessionHandler getSessionFromBag(String sessionId) throws SessionExpiredException {
        File sessionFile = new File(sessionsPath, sessionId + ".session");
        
        if (!sessionFile.exists()) {
            return null;
        }
        
        SessionHandler handler = null;
        try {
            handler = (SessionHandler)BeanFactory.getBeanInstance(sessionFile);
        } catch (BeanException e) {
            log.throwing(getClass().getName(), "getSessionFromBag", e.getCause());
        }
        
        return handler;
    }
    
    protected void putSessionInBag(String sessionId, SessionHandler handler) {
        File sessionFile = new File(sessionsPath, sessionId + ".session");
        
        try {
            BeanFactory.saveBeanInstance(handler, sessionFile);
        } catch (BeanException e) {
            log.severe("Error in serializing " + sessionFile);
            log.throwing(getClass().getName(), "putSessionInBag", e.getCause());
        }
    }
    
    protected void removeSessionFromBag(String sessionId) {
        File sessionFile = new File(sessionsPath, sessionId + ".session");
        
        if (sessionFile.exists()) {
            sessionFile.delete();
        }
    }

    protected SessionHandler createNewSession(String sessionId) {
        log.finest("Creating a new session with id " + sessionId);
        
        SimpleSessionHandler sessionHandler = new SimpleSessionHandler();
        
        putSessionInBag(sessionId, sessionHandler);
        
        return sessionHandler;
    }    
}