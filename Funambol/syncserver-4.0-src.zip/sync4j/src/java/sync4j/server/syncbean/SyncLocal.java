/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */


package sync4j.server.syncbean;

import javax.ejb.*;

import sync4j.framework.server.SyncResponse;
import sync4j.framework.server.error.ServerException;

/**
  *
  *  @author Stefano Fornari
  *
  */
public interface SyncLocal extends EJBLocalObject {
    /**
     * Used to process a SyncML message as translated by the client object.
     *
     * @param messageData the message as a stream of byes. NOT NULL
     * @param mimeType the mime type of the stream.
     *
     * @throws sync4j.framework.server.error.ServerException in case of an error
     *         in the server that the client should be aware of.
     *
     * @return the response message
     */
    public SyncResponse processMessage(byte[] messageData,
			               String mimeType) throws ServerException;
    
    /**
     * Used to process a status information as needed by the client object (i.e.
     * errors or success).
     *
     * @param statusCode the status code
     * @param statusMessage additional descriptive message
     *
     * @return the response message
     *
     * @see sync4j.framework.core.StatusCode for valid status codes.
     */
    public SyncResponse processStatusCode(int statusCode, String info);
}