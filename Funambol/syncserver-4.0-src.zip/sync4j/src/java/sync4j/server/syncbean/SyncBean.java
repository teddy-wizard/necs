/**
 * Copyright (C) 2003-2004 Funambol
 *
 *  This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 
 */

package sync4j.server.syncbean;

import javax.ejb.*;
import javax.naming.*;
import javax.naming.InitialContext;

import javax.rmi.PortableRemoteObject;

import java.io.*;
import java.util.logging.Logger;
import java.util.logging.Level;
import java.net.URL;
import java.net.MalformedURLException;

import sync4j.framework.core.*;
import sync4j.framework.server.SyncResponse;
import sync4j.framework.logging.Sync4jLogger;
import sync4j.framework.config.Configuration;
import sync4j.framework.config.ConfigClassLoader;
import sync4j.framework.config.ConfigurationException;
import sync4j.framework.engine.SyncEngineFactory;
import sync4j.framework.protocol.ProtocolException;

import sync4j.framework.core.Sync4jException;
import sync4j.framework.core.RepresentationException;
import sync4j.framework.server.session.SessionExpiredException;
import sync4j.framework.server.error.*;

import sync4j.server.engine.SyncAdapter;
import sync4j.server.session.SimpleSessionHandler;

import sync4j.server.admin.*;
import sync4j.server.admin.ejb.*;

/**
 *  This is the session enterprise java bean that handles a synchronization
 *  request. It is designed to be a stateful session bean so that the state
 *  and the session management are on charge of the application server.
 *
 *  SyncBean uses two environment properties:
 *  <ul>
 *    <li><i>{ENV_ENGINE_FACTORY_NAME}</i> points to the bean to be used as a
 *        factory for the synchronization engine</li>
 *    <li><i>{ENV_MANAGEMENT_NAME}</i> points to the bean to be used as a
 *        manager of administration's part
 *  </ul>
 *
 *  LOG NAME: sync4j.server
 *
 *  @author Stefano Fornari @ Funambol
 *  @author Luigia Fassina @ Funambol
 *
 *  @version $Id: SyncBean.java,v 1.53 2004/04/14 15:46:06 luigia Exp $
 *
 */
public class SyncBean
implements javax.ejb.SessionBean {

    // ------------------------------------------------------- Private constants
    private static final String SYNCADAPTER_CLASS
        = "sync4j.server.engine.SyncAdapter";
    private static final String ENV_MANAGEMENT_NAME
        = "java:comp/env/ejb/ManagementBean";

    // ------------------------------------------------------------ Private data

    private transient Logger log = null;

    private SessionContext sessionContext       = null;

    private SyncEngineFactory syncEngineFactory = null;

    private SimpleSessionHandler sessionHandler = null;

    private Configuration config                = null;

    private String sessionId                    = null;

    private SyncAdapter syncAdapter             = null;

    // ------------------------------------------------------------- EJB methods

    public void ejbCreate(String sessionId) throws CreateException {

        log = Sync4jLogger.getLogger("server");

        loadMB();

        try {

            Object obj = Class.forName(SYNCADAPTER_CLASS).newInstance();
            syncAdapter = (SyncAdapter)obj;

        }catch (Exception e) {
            log.throwing("SyncBean", "ejbCreate", e);
            throw new CreateException( "Error "
                                     + e.getClass().getName()
                                     + " creating the SyncBean: "
                                     + e.getMessage()
                                     );
        }
        this.sessionId = sessionId;
    }

    /**
     * Creates an instance of ManagementBean
     */
    private void loadMB() throws CreateException {

        try {

            InitialContext ctx = new InitialContext();

            Object obj = ctx.lookup(ENV_MANAGEMENT_NAME);
            ManagementHomeRemote home = (ManagementHomeRemote)PortableRemoteObject.narrow(obj,ManagementHomeRemote.class);
            ManagementRemote mr = home.create();

            config = mr.getConfig();
        } catch (NamingException e) {
            e.printStackTrace();
            log.throwing("ManagementBean", "ejbCreate", e);
            throw new CreateException( "Error "
                                     + e.getClass().getName()
                                     + " creating the ManagementBean: "
                                     + e.getMessage()
                                     );
        } catch (Exception e) {
            e.printStackTrace();
            log.throwing("ManagementBean", "ejbCreate", e);
            throw new CreateException( "Error "
                                     + e.getClass().getName()
                                     + " creating the ManagementBean: "
                                     + e.getMessage()
                                     );
        }
    }


    /**
     * When the session terminates this object is removed. This can happen
     * because the synchronization process has been completed or because the
     * session has expired. If the session completes its job, the synchro-
     * nization can be committed.
     *
     */
    public void ejbRemove() {
        syncAdapter.endSync();
    }

    public void ejbActivate() {
        log = Sync4jLogger.getLogger();
    }

    public void ejbPassivate() {
        log = null;
    }

    public void setSessionContext (SessionContext sessionContext)
    throws EJBException {
        this.sessionContext = sessionContext;
    }

    /**
     *
     * process the incoming sync message
     *
     * @param msg must be non-null
     * @param mimeType may be null.
     *
     */
    public SyncResponse processMessage( final byte[] msg, final String mimeType)
    throws ServerException {
        return (SyncResponse) syncAdapter.processMessage(msg, mimeType);
    }

    /**
     * Used to process a status information as needed by the client object (i.e.
     * errors or success).
     *
     * @param statusCode the status code
     * @param statusMessage additional descriptive message
     *
     * @see sync4j.framework.core.StatusCode for valid status codes.
     */
    public SyncResponse processStatusCode(int statusCode, String info){
        return syncAdapter.processStatusCode(statusCode, info);
    }
}