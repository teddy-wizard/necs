/**
 * @file Receiver exmple
 */
#include <stdio.h>

/* Include header files required in any SyncML session */
#include <sml.h>
#include <smldef.h>
#include <smldtd.h>

#include <xpt.h>

#include "builder_wrapper.h"

/**
 * Receive the SyncML document from the transport layer
 *
 * @param id instance ID
 * @param serviceID transport service ID
 * @see xptReceiveData
 */
void myReceiveData(InstanceID_t id, XptServiceID_t serviceID)
{
    XptCommunicationID_t conn = 0;
    MemPtr_t writeBuffer = NULL;
    MemSize_t bytesWritten = 0;
    size_t bytesReceived = 0;
    VoidPtr_t userData = NULL;
    XptCommunicationInfo_t docInfo;

    /* Lock the workspace buffer to write the received document into
       (from the transport layer) */
    smlLockWriteBuffer(id, &writeBuffer, &bytesWritten);

    C(xptOpenCommunication(serviceID, XPT_REQUEST_RECEIVER, &conn));
    C(xptBeginExchange(conn));

    C(xptGetDocumentInfo(conn, &docInfo));

    /* Receive bytes from the transport layer */
    C(xptReceiveData(conn, writeBuffer, bytesWritten, &bytesReceived));

    printf("Received Data = '%s'\n", writeBuffer);

    /* Turn the workspace buffer over to SyncML for document processing */
    smlUnlockWriteBuffer(id, bytesReceived);

    /*  Prepare the callback parameter userData here!
       userData is a void pointer handed over to every callback function
       as one of the function arguments. The Toolkit doesn't touch the
       content of this structure. For instance, this mechanism can be used 
       by the application to pass data to the callback routines. */
    C(smlSetUserData(id, &userData));

    /* --- Parse commands & invoke callback routines of the application -- */
    C(smlProcessData(id, SML_ALL_COMMANDS));

    docInfo.cbSize = sizeof(docInfo);
    docInfo.cbLength = 0;
    docInfo.auth = NULL;
    strcpy(docInfo.mimeType, "application/vnd.syncml+xml");
    strcpy(docInfo.docName, "sync");
    C(xptSetDocumentInfo(conn, &docInfo));

    /* Send zero-byte response to the transport layer */
    /* TODO: Should send real response */
    {
        char sendBuffer[10000 + 1] = "";
        size_t bytesSent = 0;

        C(xptSendData(conn, sendBuffer, strlen(sendBuffer), &bytesSent));
    }

    C(xptSendComplete(conn));

    C(xptEndExchange(conn));

    C(xptCloseCommunication(conn));
}


int main(void)
{
    /* Declare vars for instance id and for options structures */
    /* (both per-Toolkit-session and per-instance) */
    InstanceID_t id;
    XptServiceID_t serviceID;
    const struct XptProtocolInfo *xptProtocolInfo;

    /* --- Initialize SyncML Reference Toolkit --- */
    C(myInit());

    /* Initialize the SyncML instance; set up callbacks and options */
    /* and get an instance Id "id" */
    C(myInitInstance(&id));

    C(xptGetProtocol("HTTP", &xptProtocolInfo));
    C(xptSelectProtocol(xptProtocolInfo->id,
                        "SERVERPORT=8080", XPT_SERVER, &serviceID));

    while (1)
    {
        /* --- Receive the SyncML document --- */
        myReceiveData(id, serviceID);
    }

    C(xptDeselectProtocol(serviceID));

    /* --- Close SyncML instance and Toolkit session -- */
    C(myTerminateInstance(id));
    C(myTerminate());

    return 0;
}
