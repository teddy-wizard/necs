#ifndef _CALLBACK_HANDLER_H
#define _CALLBACK_HANDLER_H

#include <smlerr.h>
#include <smldtd.h>
#include <smldef.h>

Ret_t myHandleStartMessage(InstanceID_t id, VoidPtr_t userData,
                           SmlSyncHdrPtr_t pSyncHdr);
Ret_t myHandleStartSync(InstanceID_t id, VoidPtr_t userData,
                        SmlSyncPtr_t pSync);
Ret_t myHandleAdd(InstanceID_t id, VoidPtr_t userData, SmlAddPtr_t pAdd);
Ret_t myHandleEndSync(InstanceID_t id, VoidPtr_t userData);
Ret_t myHandleEndMessage(InstanceID_t id, VoidPtr_t userData,
                         Boolean_t final);

#endif /* _CALLBACK_HANDLER_H */
