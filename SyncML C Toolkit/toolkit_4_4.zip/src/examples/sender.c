/**
 * @file Sender exmple
 */
#include <stdio.h>

/* Include header files required in any SyncML session */
#include <sml.h>
#include <smldef.h>
#include <smldtd.h>

#include <xpt.h>

#include "builder_wrapper.h"

/**
 * Send the SyncML document to the transport layer
 *
 * @param id instance ID
 * @return return value of xptSendData
 * @see xptSendData
 */
Ret_t mySendData(InstanceID_t id, XptServiceID_t serviceID)
{
    XptCommunicationID_t conn = 0;
    MemPtr_t readBuffer = NULL;
    MemSize_t bytesRead = 0;
    size_t bytesSent = 0;
    XptCommunicationInfo_t docInfo;

    /* Lock the workspace for reading the assembled SyncML document */
    smlLockReadBuffer(id, &readBuffer, &bytesRead);

    C(xptOpenCommunication(serviceID, XPT_REQUEST_SENDER, &conn));

    C(xptBeginExchange(conn));

    docInfo.cbSize = sizeof(docInfo);
    docInfo.cbLength = bytesRead;
    docInfo.auth = NULL;
    docInfo.hmacInfo = NULL;
    strcpy(docInfo.mimeType, "application/vnd.syncml+xml");
    strcpy(docInfo.docName, "sync");
    C(xptSetDocumentInfo(conn, &docInfo));

    /* Pass data (the SyncML document in the buffer) to transport layer */
    C(xptSendData(conn, readBuffer, bytesRead, &bytesSent));

    C(xptSendComplete(conn));

    printf("Sent Data = '%s'\n", readBuffer);

    /* Unlock the workspace so the Toolkit controls it again */
    C(smlUnlockReadBuffer(id, bytesSent));

    C(xptGetDocumentInfo(conn, &docInfo));

    /* Receive zero-byte response from transport binding */
    {
        size_t bytesReceived = 0;
        char receiveBuf[10000 + 1] = "";

        /* NOTE: Should receive at least more than one data */
        C(xptReceiveData(conn, receiveBuf, 1, &bytesReceived));
    }

    C(xptEndExchange(conn));

    C(xptCloseCommunication(conn));

    return SML_ERR_OK;
}

int main(void)
{
    InstanceID_t id;
    XptServiceID_t serviceID;
    const struct XptProtocolInfo *xptProtocolInfo;

    /* --- Initialize SyncML reference toolkit --- */

    /* Initialize SyncML Reference Toolkit */
    C(myInit());

    /* Initialize the SyncML instance */
    C(myInitInstance(&id));

    /* --- Start building SyncML document --- */

    /* Start a new message using the syncHdr proto element */
    C(myStartMessage(id));

    /* Continue adding SyncML commands to the workspace. The proto element
       structures holding the parameters associated with each command
       need to be allocated and set to appropriate values before usage. */

    /* Start sync cmd */
    C(myStartSync(id));

    /* Start add cmd */
    C(myAddCmd(id));

    /* End the sync block */
    C(myEndSync(id));

    /* --- End message --- */
    C(myEndMessage(id));

    /* --- Send the SyncML document --- */

    C(xptGetProtocol("HTTP", &xptProtocolInfo));
    C(xptSelectProtocol(xptProtocolInfo->id,
                        "HOST=127.0.0.1:8080", XPT_CLIENT, &serviceID));

    C(mySendData(id, serviceID));

    C(xptDeselectProtocol(serviceID));

    /* --- Close SyncML instance and Toolkit session --- */

    C(myTerminateInstance(id));

    C(myTerminate());

    return 0;
}
