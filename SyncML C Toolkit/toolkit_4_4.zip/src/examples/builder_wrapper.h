#ifndef _BUILDER_WRAPPER_H
#define _BUILDER_WRAPPER_H

#include <smldef.h>

#define C(X) { \
    int rc = SML_ERR_OK; \
    rc = X; \
    if (rc != SML_ERR_OK) \
    { \
        printf("%s:%d:rc = %d, hex(rc) = %x\n", __FILE__, __LINE__, rc, rc); \
    } \
}

Ret_t myInit(void);
Ret_t myInitInstance(InstanceID_t * pID);
Ret_t myStartMessage(InstanceID_t id);
Ret_t myAlertCmd(InstanceID_t id);
Ret_t myStartSync(InstanceID_t id);
Ret_t myAddCmd(InstanceID_t id);
Ret_t myEndSync(InstanceID_t id);
Ret_t myEndMessage(InstanceID_t id);
Ret_t myTerminateInstance(InstanceID_t id);
Ret_t myTerminate(void);

#endif /* _BUILDER_WRAPPER_H */
