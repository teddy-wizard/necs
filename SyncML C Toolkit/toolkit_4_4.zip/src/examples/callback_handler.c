/**
 * @file Callback implementations
 */
#include "callback_handler.h"

#include <stdio.h>

#include <smlmetinfdtd.h>
#include <smldevinfdtd.h>
#include <mgrutil.h>

/**
 * Callback handling <SyncHdr> tag
 *
 * @param id instance ID
 * @param pSync pointer containing infomation about <SyncHdr> block
 * @return SML_ERR_OK(=0)
 * @see smlInitInstance
 */
Ret_t myHandleStartMessage(InstanceID_t id, VoidPtr_t userData,
                           SmlSyncHdrPtr_t pSyncHdr)
{
    printf("Calling %s() at %s:%d\n", __FUNCTION__, __FILE__, __LINE__);
    printf("SyncHdr.VerDTD	      = %s\n",
           (char *) smlPcdata2String(pSyncHdr->version));
    printf("SyncHdr.VerProto      = %s\n", smlPcdata2String(pSyncHdr->proto));
    printf("SyncHdr.SessionID     = %s\n",
           smlPcdata2String(pSyncHdr->sessionID));
    printf("SyncHdr.MsgID         = %s\n", smlPcdata2String(pSyncHdr->msgID));
    printf("SyncHdr.Flags         = %d\n", pSyncHdr->flags);
    printf("SyncHdr.Target.locURI = %s\n",
           smlPcdata2String(pSyncHdr->target->locURI));
    printf("SyncHdr.Source.locURI = %s\n",
           smlPcdata2String(pSyncHdr->source->locURI));
    printf("SyncHdr.RespURI       = %s\n",
           smlPcdata2String(pSyncHdr->respURI));
    /* Skipped SyncHdr.Cred */
    printf("SyncHdr.Meta          = %s\n", smlPcdata2String(pSyncHdr->meta));

    return SML_ERR_OK;
}

/**
 * Callback handling <Sync> command
 *
 * @param id instance ID
 * @param pSync pointer containing infomation about <Sync> block
 * @return SML_ERR_OK(=0)
 * @see smlInitInstance
 */
Ret_t myHandleStartSync(InstanceID_t id, VoidPtr_t userData,
                        SmlSyncPtr_t pSync)
{
    printf("Calling %s() at %s:%d\n", __FUNCTION__, __FILE__, __LINE__);
    printf("Sync.CmdID          = %s\n", smlPcdata2String(pSync->cmdID));
    printf("Sync.Target.LocURI  = %s\n",
           smlPcdata2String(pSync->target->locURI));
    printf("Sync.Source.LocURI  = %s\n",
           smlPcdata2String(pSync->source->locURI));
    printf("Sync.NumberOfChange = %s\n",
           smlPcdata2String(pSync->noc));
    return SML_ERR_OK;
}

/**
 * Callback handling <Add> command
 *
 * @param id instance ID
 * @param pSync pointer containing infomation about <Add> command
 * @return SML_ERR_OK(=0)
 * @see smlInitInstance
 */
Ret_t myHandleAdd(InstanceID_t id, VoidPtr_t userData, SmlAddPtr_t pAdd)
{
    SmlItemListPtr_t ele;

    printf("Calling %s() at %s:%d\n", __FUNCTION__, __FILE__, __LINE__);
    printf("Add.CmdID = %s\n", smlPcdata2String(pAdd->cmdID));
    printf("Add.Flags = %d\n", pAdd->flags);
    printf("Add.Meta  = %s\n", smlPcdata2String(pAdd->meta));

    ele = pAdd->itemList;
    while (ele != NULL)
    {
        printf("Add.ItemList.Item.Source.LocURI = %s\n",
               smlPcdata2String(ele->item->source->locURI));
        printf("Add.ItemList.Item.Data          = %s\n",
               smlPcdata2String(ele->item->data));
        /* putInDB(ele->item); */
        ele = ele->next;
    }
    return SML_ERR_OK;
}

Ret_t myHandleEndSync(InstanceID_t id, VoidPtr_t userData)
{
    printf("Calling %s() at %s:%d\n", __FUNCTION__, __FILE__, __LINE__);
    return SML_ERR_OK;
}

Ret_t myHandleEndMessage(InstanceID_t id, VoidPtr_t userData, Boolean_t final)
{
    printf("Calling %s() at %s:%d\n", __FUNCTION__, __FILE__, __LINE__);
    return SML_ERR_OK;
}
