/**
 * @file Command builder wrapper
 */
#include "builder_wrapper.h"

#include <stdio.h>

#include <sml.h>
#include <smldef.h>
#include <smldtd.h>

#include <smlmetinfdtd.h>
#include <smldevinfdtd.h>
#include <mgrutil.h>

#include <xpt.h>

#include "callback_handler.h"

/**
 * Initialize SyncML Reference Toolkit 
 *
 * @return return value of smlInit
 * @see smlInit
 */
Ret_t myInit(void)
{
    SmlOptions_t options;

    /* Set Toolkit options structure */
    options.defaultPrintFunc = NULL;
    options.maxWorkspaceAvailMem = 100000;

    /* Initialize SyncML Toolkit */
    return smlInit(&options);
}

/**
 * Initialize the SyncML instance
 *
 * @param pID pointer to instance ID
 * @return return value of smlInitInstance
 * @see smlInitInstance
 */
Ret_t myInitInstance(InstanceID_t * pID)
{
    SmlCallbacks_t callbacks;
    SmlInstanceOptions_t options;

    /* Set instance */
    options.encoding = SML_XML;
    options.workspaceName = "MyWorkSpace";
    options.workspaceSize = 10000;

    /* Allocate for callbacks structure */
    callbacks.startMessageFunc = myHandleStartMessage;
    callbacks.startSyncFunc = myHandleStartSync;
    callbacks.addCmdFunc = myHandleAdd;
    callbacks.endSyncFunc = myHandleEndSync;
    callbacks.endMessageFunc = myHandleEndMessage;

    /* Initialize the SyncML instance; set up callbacks and options */
    /* and get an instance Id "id" */
    return smlInitInstance(&callbacks, &options, NULL, pID);
}

/**
 * Start building SyncML document
 *
 * @param id instance ID
 * @return return value of smlStartMessage
 * @see smlStartMessage
 * @see smlStartMessageExt
 */
Ret_t myStartMessage(InstanceID_t id)
{
    SmlSyncHdr_t hdr;
    SmlSource_t source;
    SmlTarget_t target;

    /* Create SyncML proto element for message header */
    hdr.elementType = SML_PE_HEADER;
    hdr.version = smlString2Pcdata("1.1");
    hdr.proto = smlString2Pcdata("SyncML/1.1");
    hdr.sessionID = smlString2Pcdata("1");
    hdr.msgID = smlString2Pcdata("1000");
    hdr.flags = SmlNoResp_f;

    target.locURI = smlString2Pcdata("http://data.sync.server.url");
    target.locName = smlString2Pcdata("Data Sync Server");
    hdr.target = &target;

    source.locURI = smlString2Pcdata("data_sync_client");
    source.locName = smlString2Pcdata("Data Sync Client");
    hdr.source = &source;

    hdr.cred = NULL;
    hdr.meta = NULL;
    hdr.respURI = NULL;

    /* Start a new message using the SyncHdr proto element */
    return smlStartMessageExt(id, &hdr, SML_VERS_1_1);
}

/**
 * Start building Sync command
 *
 * @param id instance ID
 * @return return value of smlStartSync
 * @see smlStartSync
 */
Ret_t myStartSync(InstanceID_t id)
{
    SmlSync_t sync;
    SmlSource_t source;
    SmlTarget_t target;

    /* Start sync cmd */
    sync.elementType = SML_PE_SYNC_START;
    sync.cmdID = smlString2Pcdata("1");

    target.locURI = smlString2Pcdata("./contacts_server");
    target.locName = smlString2Pcdata("Sync Server Database");
    sync.target = &target;

    source.locURI = smlString2Pcdata("./contacts_client");
    source.locName = smlString2Pcdata("Sync Client Database");
    sync.source = &source;

    sync.cred = NULL;
    sync.noc = smlString2Pcdata("1");

    return smlStartSync(id, &sync);
}

/**
 * Start building Add command
 *
 * @param id instance ID
 * @return return value of smlAddCmd
 * @see smlAddCmd
 */
Ret_t myAddCmd(InstanceID_t id)
{
    SmlAdd_t add;
    SmlItem_t item;
    SmlItemList_t itemList;
    SmlSource_t source;
    SmlTarget_t target;

    /* Add cmd */
    add.elementType = SML_PE_ADD;
    add.cmdID = smlString2Pcdata("2");
    add.cred = NULL;
    add.meta =
        smlString2Pcdata("<Type xmlns='syncml:metinf'>text/x-vcard</Type>");
    add.flags = SmlNoResp_f;

    target.locURI = smlString2Pcdata("1");
    target.locName = smlString2Pcdata("Element ID at Target");
    item.target = &target;

    source.locURI = smlString2Pcdata("2");
    source.locName = smlString2Pcdata("Element ID at Source");
    item.source = &source;

    item.data = smlString2Pcdata("BEGIN:VCARD\n"
                                 "VERSION:2.1\n"
                                 "N:Puppy;Dusty\n"
                                 "ORG:Columbia Internet\n"
                                 "EMAIL:dusty_puppy@userfriendly.org\n"
                                 "URL:http://www.userfriendly.org\n"
                                 "TEL;WORK:+123 456 78 9012\n" "END:VCARD\n");
    item.meta = NULL;

    itemList.item = &item;
    itemList.next = NULL;
    add.itemList = &itemList;

    return smlAddCmd(id, &add);
}

/**
 * End the sync block 
 *
 * @param id instance ID
 * @return return value of smlEndSync
 * @see smlEndSync
 */
Ret_t myEndSync(InstanceID_t id)
{
    return smlEndSync(id);
}

/**
 * End the sync message
 *
 * @param id instance ID
 * @return return value of smlEndMessage
 * @see smlEndMessage
 */
Ret_t myEndMessage(InstanceID_t id)
{
    /* This ends the SyncML document ... it has been assembled */
    /* SmlFinal_f says this is the last message in the SyncML package */
    /* (since it's the only one) */

    return smlEndMessage(id, SmlFinal_f);
}

/**
 * Close SyncML instance
 *
 * @param id instance ID
 * @return return value of smlTerminateInstance
 * @see smlTerminateInstance
 */
Ret_t myTerminateInstance(InstanceID_t id)
{
    return smlTerminateInstance(id);
}

/**
 * Close SyncML Toolkit session 
 *
 * @return return value of smlTerminate
 * @see smlTerminate
 */
Ret_t myTerminate(void)
{
    return smlTerminate();
}
