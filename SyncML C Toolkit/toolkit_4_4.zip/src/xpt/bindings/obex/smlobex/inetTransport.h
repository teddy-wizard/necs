#ifndef OBEXINETTRANSPORT_H
#define OBEXINETTRANSPORT_H


/*
 * Copyright Notice
 * Copyright (c) Ericsson, IBM, Lotus, Matsushita Communication 
 * Industrial Co., Ltd., Motorola, Nokia, Openwave Systems, Inc., 
 * Palm, Inc., Psion, Starfish Software, Symbian, Ltd. (2001).
 * All Rights Reserved.
 * Implementation of all or part of any Specification may require 
 * licenses under third party intellectual property rights, 
 * including without limitation, patent rights (such a third party 
 * may or may not be a Supporter). The Sponsors of the Specification 
 * are not responsible and shall not be held responsible in any 
 * manner for identifying or failing to identify any or all such 
 * third party intellectual property rights.
 * 
 * THIS DOCUMENT AND THE INFORMATION CONTAINED HEREIN ARE PROVIDED 
 * ON AN "AS IS" BASIS WITHOUT WARRANTY OF ANY KIND AND ERICSSON, IBM, 
 * LOTUS, MATSUSHITA COMMUNICATION INDUSTRIAL CO. LTD, MOTOROLA, 
 * NOKIA, PALM INC., PSION, STARFISH SOFTWARE AND ALL OTHER SYNCML 
 * SPONSORS DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING 
 * BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE INFORMATION 
 * HEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED WARRANTIES OF 
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
 * SHALL ERICSSON, IBM, LOTUS, MATSUSHITA COMMUNICATION INDUSTRIAL CO., 
 * LTD, MOTOROLA, NOKIA, PALM INC., PSION, STARFISH SOFTWARE OR ANY 
 * OTHER SYNCML SPONSOR BE LIABLE TO ANY PARTY FOR ANY LOSS OF 
 * PROFITS, LOSS OF BUSINESS, LOSS OF USE OF DATA, INTERRUPTION OF 
 * BUSINESS, OR FOR DIRECT, INDIRECT, SPECIAL OR EXEMPLARY, INCIDENTAL, 
 * PUNITIVE OR CONSEQUENTIAL DAMAGES OF ANY KIND IN CONNECTION WITH 
 * THIS DOCUMENT OR THE INFORMATION CONTAINED HEREIN, EVEN IF ADVISED 
 * OF THE POSSIBILITY OF SUCH LOSS OR DAMAGE.
 * 
 * The above notice and this paragraph must be included on all copies 
 * of this document that are made.
 * 
 */

/*
**************************************************************************
** Inet Transport
**************************************************************************
*/
#include <iConstants.h>

#ifdef __cplusplus
extern "C" {
#endif


/*
** Defines a connection.
** This block is created by an open() call and is set as the 'connectionid' in
** the callers arg list.  It's returned on subsuquent calls to functions.
*/
typedef struct iobxInetConnectionBlock ObxInetConnectionBlock;
struct iobxInetConnectionBlock {
   int                  fd;               /* Socket FD (client)  */
   short                connected;        /* Do we have a peer?  */
   struct sockaddr_in   peer;             /* Destination         */
};


/*
** Server block
*/
typedef struct iobxInetServerBlock ObxInetServerBlock;
struct iobxInetServerBlock {
   int                  fd;               /* Server socket.             */
   struct sockaddr_in   self;             /* Destination                */
   short                active;           /* Indicates an active server.*/
};


/*
** Meta block
*/
typedef struct iobxInetMetaBlock ObxInetMetaBlock;
struct iobxInetMetaBlock {
   unsigned short    port;                // Assigned port
   char              *host;               // Host
   short             valid;               // Was meta data valid?
};


/*
** Initialize the transport.  The inbound meta data will differ for each
** transport type.  Should be called once, prior to any other calls.
*/
ObxRc iobxInetTransportInitialize( const char *meta );

/*
** Clean up all internals
*/
ObxRc iobxInetTransportTerminate( void );

/*
** Create a connection
*/
ObxRc iobxInetTransportOpen( void **connectionid );

/* ************************************** */
/* When transport is acting as server     */
/* ************************************** */

/*
** Do any preperation for accepting inbound connections (i.e. acting as a server).
** For the INET transport this would include a bind() and listen().  Other transports
** may have other needs.
*/
ObxRc iobxInetTransportListen( void **connectionid );

/*
** Accept an inbound connection from a peer transport.  This call should block until
** a connection has been established.
** When a connection has been accepted, the passed 'connectionid' is set.  This will be
** provided by the caller on all subsuquent calls made against the active connection.
*/
ObxRc iobxInetTransportAccept( void **connectionid );

/* ************************************** */
/* When transport is acting as client     */
/* ************************************** */

/*
** Initiate a connection to a remote peer transport.
** When a connection has been created, the passed 'connectionid' is set.  This will be
** provided by the caller on all subsuquent calls made against the active connection.
*/
ObxRc iobxInetTransportConnect( void **connectionid );

/* ************************************** */
/* Functions used on connected transports */
/* ************************************** */

/*
** Send 'length' bytes of data from 'buf', set the actual number
** written in 'wrote'.
** Note that the inbound 'connectionid' was created by either a connect() or accept() call.
*/
ObxRc iobxInetTransportSend( void **connectionid, const void *buf, int length, int *wrote, short allowShort );

/*
** Receive 'length' bytes of data and place into 'buf', set the actual
** number of bytes read in 'actual'.
** Note that the inbound 'connectionid' was created by either a connect() or accept() call.
*/
ObxRc iobxInetTransportRecv( void **connectionid, void *buf, int length, int *actual, short allowShort );

/*
** Clean up all internals, subsuquent use of this 'connectionid' should result in an error.
** Note that the inbound 'connectionid' was created by either a connect() or accept() call.
*/
ObxRc iobxInetTransportClose( void **connectionid );

#ifdef __cplusplus
}
#endif


#endif
