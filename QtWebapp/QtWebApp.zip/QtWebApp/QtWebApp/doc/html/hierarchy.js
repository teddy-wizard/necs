var hierarchy =
[
    [ "stefanfrings::HttpCookie", "classstefanfrings_1_1HttpCookie.html", null ],
    [ "stefanfrings::HttpRequest", "classstefanfrings_1_1HttpRequest.html", null ],
    [ "stefanfrings::HttpResponse", "classstefanfrings_1_1HttpResponse.html", null ],
    [ "stefanfrings::HttpSession", "classstefanfrings_1_1HttpSession.html", null ],
    [ "stefanfrings::LogMessage", "classstefanfrings_1_1LogMessage.html", null ],
    [ "QObject", null, [
      [ "stefanfrings::HttpConnectionHandler", "classstefanfrings_1_1HttpConnectionHandler.html", null ],
      [ "stefanfrings::HttpConnectionHandlerPool", "classstefanfrings_1_1HttpConnectionHandlerPool.html", null ],
      [ "stefanfrings::HttpRequestHandler", "classstefanfrings_1_1HttpRequestHandler.html", [
        [ "stefanfrings::StaticFileController", "classstefanfrings_1_1StaticFileController.html", null ]
      ] ],
      [ "stefanfrings::HttpSessionStore", "classstefanfrings_1_1HttpSessionStore.html", null ],
      [ "stefanfrings::Logger", "classstefanfrings_1_1Logger.html", [
        [ "stefanfrings::DualFileLogger", "classstefanfrings_1_1DualFileLogger.html", null ],
        [ "stefanfrings::FileLogger", "classstefanfrings_1_1FileLogger.html", null ]
      ] ],
      [ "stefanfrings::TemplateLoader", "classstefanfrings_1_1TemplateLoader.html", [
        [ "stefanfrings::TemplateCache", "classstefanfrings_1_1TemplateCache.html", null ]
      ] ]
    ] ],
    [ "QString", null, [
      [ "stefanfrings::Template", "classstefanfrings_1_1Template.html", null ]
    ] ],
    [ "QTcpServer", null, [
      [ "stefanfrings::HttpListener", "classstefanfrings_1_1HttpListener.html", null ]
    ] ]
];