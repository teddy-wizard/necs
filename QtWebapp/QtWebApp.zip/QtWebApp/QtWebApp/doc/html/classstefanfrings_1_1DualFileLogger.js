var classstefanfrings_1_1DualFileLogger =
[
    [ "DualFileLogger", "classstefanfrings_1_1DualFileLogger.html#a8368cfe85bbc2e56f9d1cd0593c7c925", null ],
    [ "clear", "classstefanfrings_1_1DualFileLogger.html#a4af0d2c35121b1f40dbd08b053a53ddf", null ],
    [ "log", "classstefanfrings_1_1DualFileLogger.html#a6db25d5c835b7221f0a6b7b4a035d4aa", null ]
];