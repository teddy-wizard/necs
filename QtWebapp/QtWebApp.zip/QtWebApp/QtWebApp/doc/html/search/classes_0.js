var searchData=
[
  ['dualfilelogger_153',['DualFileLogger',['../classstefanfrings_1_1DualFileLogger.html',1,'stefanfrings']]]
];
