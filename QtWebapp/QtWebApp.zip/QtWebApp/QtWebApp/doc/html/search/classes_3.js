var searchData=
[
  ['logger_164',['Logger',['../classstefanfrings_1_1Logger.html',1,'stefanfrings']]],
  ['logmessage_165',['LogMessage',['../classstefanfrings_1_1LogMessage.html',1,'stefanfrings']]]
];
