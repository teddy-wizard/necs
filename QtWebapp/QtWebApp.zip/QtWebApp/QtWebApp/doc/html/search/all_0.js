var searchData=
[
  ['buffersize_0',['bufferSize',['../classstefanfrings_1_1Logger.html#a9e6f76da976e3f09962c7613ad7aad8a',1,'stefanfrings::Logger']]]
];
