#include "httpglobal.h"

const char* getQtWebAppLibVersion()
{
    return "1.9.0";
}

