This folder contains example certificates for "localhost".

The file client.p12 has been made for your web browser. It contains
both the client certificate and key. You need to enter the password
"test" when you import it in yur web browser.
